<?php
define('INCLUDED', true);
require_once '../config.php';

header('Content-Type: application/json');

// ต้องล็อกอินก่อนทุก action
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'กรุณาเข้าสู่ระบบก่อน']);
    exit;
}

$pdo    = getDB();
$userId = $_SESSION['user_id'];
$input  = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? $_POST['action'] ?? '';

try {
    switch ($action) {

        // ─── เพิ่มสินค้าลงตะกร้า ───────────────────────────────────────────
        case 'add':
            $productId = (int)($input['product_id'] ?? 0);
            $qty       = max(1, (int)($input['quantity'] ?? 1));

            if (!$productId) {
                echo json_encode(['success' => false, 'message' => 'ไม่พบสินค้า']);
                exit;
            }

            // ตรวจสต็อก
            $stmt = $pdo->prepare("SELECT id, stock, is_active FROM products WHERE id = ?");
            $stmt->execute([$productId]);
            $product = $stmt->fetch();

            if (!$product || !$product['is_active']) {
                echo json_encode(['success' => false, 'message' => 'สินค้าไม่พร้อมจำหน่าย']);
                exit;
            }

            // ตรวจว่ามีในตะกร้าแล้วหรือยัง
            $stmt = $pdo->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?");
            $stmt->execute([$userId, $productId]);
            $existing = $stmt->fetch();

            if ($existing) {
                // มีแล้ว → เพิ่มจำนวน
                $newQty = $existing['quantity'] + $qty;
                if ($newQty > $product['stock']) {
                    echo json_encode(['success' => false, 'message' => 'สินค้าไม่เพียงพอในสต็อก (มี ' . $product['stock'] . ' ชิ้น)']);
                    exit;
                }
                $stmt = $pdo->prepare("UPDATE cart SET quantity = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$newQty, $existing['id']]);
            } else {
                // ยังไม่มี → INSERT ใหม่
                if ($qty > $product['stock']) {
                    echo json_encode(['success' => false, 'message' => 'สินค้าไม่เพียงพอในสต็อก (มี ' . $product['stock'] . ' ชิ้น)']);
                    exit;
                }
                $stmt = $pdo->prepare("INSERT INTO cart (user_id, product_id, quantity, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
                $stmt->execute([$userId, $productId, $qty]);
            }

            // นับจำนวนรายการในตะกร้า (สำหรับ badge)
            $countStmt = $pdo->prepare("SELECT SUM(quantity) FROM cart WHERE user_id = ?");
            $countStmt->execute([$userId]);
            $cartCount = (int)$countStmt->fetchColumn();

            echo json_encode([
                'success'    => true,
                'message'    => 'เพิ่มสินค้าลงตะกร้าแล้ว',
                'cart_count' => $cartCount,
            ]);
            break;

        // ─── อัปเดตจำนวน ───────────────────────────────────────────────────
        case 'update':
            $cartId = (int)($input['cart_id'] ?? 0);
            $qty    = (int)($input['quantity'] ?? 1);

            if (!$cartId) {
                echo json_encode(['success' => false, 'message' => 'ไม่พบรายการ']);
                exit;
            }

            // ตรวจว่า cart item เป็นของ user นี้จริง + ดึงสต็อก
            $stmt = $pdo->prepare("
                SELECT c.id, p.stock, p.price
                FROM cart c JOIN products p ON c.product_id = p.id
                WHERE c.id = ? AND c.user_id = ?
            ");
            $stmt->execute([$cartId, $userId]);
            $cartItem = $stmt->fetch();

            if (!$cartItem) {
                echo json_encode(['success' => false, 'message' => 'ไม่พบรายการในตะกร้า']);
                exit;
            }

            if ($qty < 1) {
                // ถ้าจำนวน < 1 ให้ลบออกเลย
                $pdo->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?")->execute([$cartId, $userId]);
                echo json_encode(['success' => true, 'removed' => true]);
                exit;
            }

            if ($qty > $cartItem['stock']) {
                echo json_encode(['success' => false, 'message' => 'สต็อกมีแค่ ' . $cartItem['stock'] . ' ชิ้น']);
                exit;
            }

            $pdo->prepare("UPDATE cart SET quantity = ?, updated_at = NOW() WHERE id = ? AND user_id = ?")
                ->execute([$qty, $cartId, $userId]);

            // คำนวณ subtotal ใหม่
            $subtotal = $cartItem['price'] * $qty;

            echo json_encode([
                'success'  => true,
                'subtotal' => number_format($subtotal, 2),
                'quantity' => $qty,
            ]);
            break;

        // ─── ลบรายการเดียว ──────────────────────────────────────────────────
        case 'remove':
            $cartId = (int)($input['cart_id'] ?? 0);

            if (!$cartId) {
                echo json_encode(['success' => false, 'message' => 'ไม่พบรายการ']);
                exit;
            }

            $pdo->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?")->execute([$cartId, $userId]);

            echo json_encode(['success' => true, 'message' => 'ลบรายการแล้ว']);
            break;

        // ─── ล้างตะกร้าทั้งหมด ──────────────────────────────────────────────
        case 'clear':
            $pdo->prepare("DELETE FROM cart WHERE user_id = ?")->execute([$userId]);
            echo json_encode(['success' => true, 'message' => 'ล้างตะกร้าแล้ว']);
            break;

        // ─── ดึงจำนวนสินค้าในตะกร้า (สำหรับ badge) ─────────────────────────
        case 'count':
            $stmt = $pdo->prepare("SELECT SUM(quantity) FROM cart WHERE user_id = ?");
            $stmt->execute([$userId]);
            $count = (int)$stmt->fetchColumn();
            echo json_encode(['success' => true, 'count' => $count]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'action ไม่ถูกต้อง']);
            break;
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'เกิดข้อผิดพลาดจากฐานข้อมูล']);
    // error_log($e->getMessage()); // เปิดเพื่อ debug
}
