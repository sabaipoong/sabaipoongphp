<?php
// api/address.php - ดึงข้อมูลที่อยู่จาก DB
require_once '../config.php';
header('Content-Type: application/json; charset=utf-8');

$pdo    = getDB();
$action = $_GET['action'] ?? '';

switch ($action) {

    // ดึงจังหวัดทั้งหมด
    case 'provinces':
        $rows = $pdo->query("SELECT id, name FROM provinces ORDER BY name")
                    ->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rows, JSON_UNESCAPED_UNICODE);
        break;

    // ดึงอำเภอตามจังหวัด
    case 'districts':
        $provinceId = (int)($_GET['province_id'] ?? 0);
        if (!$provinceId) { echo json_encode([]); break; }
        $stmt = $pdo->prepare("SELECT id, name FROM districts WHERE province_id = ? ORDER BY name");
        $stmt->execute([$provinceId]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC), JSON_UNESCAPED_UNICODE);
        break;

    // ดึงตำบลตามอำเภอ
    case 'subdistricts':
        $districtId = (int)($_GET['district_id'] ?? 0);
        if (!$districtId) { echo json_encode([]); break; }
        $stmt = $pdo->prepare("SELECT id, name, zipcode FROM subdistricts WHERE district_id = ? ORDER BY name");
        $stmt->execute([$districtId]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC), JSON_UNESCAPED_UNICODE);
        break;

    default:
        echo json_encode(['error' => 'Invalid action']);
}
