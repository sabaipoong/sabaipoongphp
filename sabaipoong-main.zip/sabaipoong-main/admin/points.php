<?php
define('INCLUDED', true);
require_once '../config.php';
requireAdmin();

$pdo = getDB();
$pageTitle = 'จัดการคะแนนสะสม';

// --- ADJUST POINTS (manual) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adjust_points'])) {
    $userId  = (int)$_POST['user_id'];
    $amount  = (int)$_POST['amount'];
    $type    = in_array($_POST['type'], ['add','deduct']) ? $_POST['type'] : 'add';
    $note    = trim($_POST['note'] ?? 'ปรับโดย Admin');

    if ($userId > 0 && $amount > 0) {
        if ($type === 'add') {
            $pdo->prepare("UPDATE users SET points = points + ? WHERE id=?")->execute([$amount, $userId]);
        } else {
            $pdo->prepare("UPDATE users SET points = GREATEST(0, points - ?) WHERE id=?")->execute([$amount, $userId]);
        }
        // Log to points_log table if exists
        try {
            $pdo->prepare("INSERT INTO points_log (user_id, amount, type, note, created_at) VALUES (?,?,?,?,NOW())")
                ->execute([$userId, $amount, $type, $note]);
        } catch (Exception $e) { /* table may not exist */ }

        $_SESSION['flash'] = ['message' => ($type === 'add' ? 'เพิ่ม' : 'หัก') . " {$amount} คะแนนแล้ว", 'type' => 'success'];
    }
    header('Location: points.php'); exit;
}

// --- SETTINGS SAVE ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    $ratePerBaht   = (float)($_POST['rate_per_baht'] ?? 1);
    $redeemRate    = (float)($_POST['redeem_rate'] ?? 100);
    $minRedeem     = (int)($_POST['min_redeem'] ?? 100);
    $expireDays    = (int)($_POST['expire_days'] ?? 0);

    // Save to settings table or config
    $settingsToSave = [
        'points_rate_per_baht' => $ratePerBaht,
        'points_redeem_rate'   => $redeemRate,
        'points_min_redeem'    => $minRedeem,
        'points_expire_days'   => $expireDays,
    ];
    foreach ($settingsToSave as $key => $val) {
        try {
            $exists = $pdo->prepare("SELECT id FROM settings WHERE setting_key=?");
            $exists->execute([$key]);
            if ($exists->fetch()) {
                $pdo->prepare("UPDATE settings SET setting_value=? WHERE setting_key=?")->execute([$val, $key]);
            } else {
                $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?,?)")->execute([$key, $val]);
            }
        } catch (Exception $e) { /* table may not exist */ }
    }
    $_SESSION['flash'] = ['message' => 'บันทึกการตั้งค่าคะแนนแล้ว', 'type' => 'success'];
    header('Location: points.php'); exit;
}

// --- LOAD SETTINGS ---
$settings = [];
try {
    $rows = $pdo->query("SELECT setting_key, setting_value FROM settings WHERE setting_key LIKE 'points_%'")->fetchAll();
    foreach ($rows as $r) $settings[$r['setting_key']] = $r['setting_value'];
} catch (Exception $e) {}

$ratePerBaht = $settings['points_rate_per_baht'] ?? 1;
$redeemRate  = $settings['points_redeem_rate']   ?? 100;
$minRedeem   = $settings['points_min_redeem']    ?? 100;
$expireDays  = $settings['points_expire_days']   ?? 0;

// --- LIST USERS WITH POINTS ---
$search    = trim($_GET['q'] ?? '');
$sortBy    = in_array($_GET['sort'] ?? '', ['points_desc','points_asc','name']) ? $_GET['sort'] : 'points_desc';
$page      = max(1, (int)($_GET['page'] ?? 1));
$perPage   = 20;
$offset    = ($page - 1) * $perPage;

$where     = $search ? "WHERE (full_name LIKE ? OR username LIKE ? OR email LIKE ?)" : '';
$params    = $search ? ["%$search%","%$search%","%$search%"] : [];

$orderSQL  = match($sortBy) {
    'points_asc' => 'ORDER BY points ASC',
    'name'       => 'ORDER BY full_name ASC',
    default      => 'ORDER BY points DESC',
};

$countSQL = "SELECT COUNT(*) FROM users $where";
$listSQL  = "SELECT id, username, full_name, email, points, profile_image FROM users $where $orderSQL LIMIT $perPage OFFSET $offset";

$stmtC = $pdo->prepare($countSQL); $stmtC->execute($params);
$totalCount = $stmtC->fetchColumn();
$stmtL = $pdo->prepare($listSQL);  $stmtL->execute($params);
$users = $stmtL->fetchAll();
$totalPages = ceil($totalCount / $perPage);

// Summary
$totalPoints     = $pdo->query("SELECT COALESCE(SUM(points),0) FROM users")->fetchColumn();
$avgPoints       = $pdo->query("SELECT COALESCE(AVG(points),0) FROM users WHERE points > 0")->fetchColumn();
$usersWithPoints = $pdo->query("SELECT COUNT(*) FROM users WHERE points > 0")->fetchColumn();
$topUser         = $pdo->query("SELECT full_name, username, points FROM users ORDER BY points DESC LIMIT 1")->fetch();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .page-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; padding-bottom:16px; border-bottom:2px solid var(--border-color,#e8f0e9); }
        .page-header h1 { font-size:22px; font-weight:700; color:var(--green-deep,#2d5a27); margin:0; }

        .layout-grid { display:grid; grid-template-columns:1fr 320px; gap:24px; align-items:start; }

        /* KPI */
        .kpi-row { display:grid; grid-template-columns:repeat(4,1fr); gap:14px; margin-bottom:24px; }
        .kpi-mini { background:#fff; border-radius:14px; padding:16px; box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid var(--border-color,#e8f0e9); }
        .kpi-mini .km-num   { font-size:22px; font-weight:700; color:var(--text-dark,#1a1a1a); }
        .kpi-mini .km-label { font-size:12px; color:var(--text-light,#888); margin-top:3px; }
        .kpi-mini .km-icon  { font-size:20px; margin-bottom:8px; }

        /* Table */
        .table-wrapper { background:#fff; border-radius:16px; box-shadow:0 2px 10px rgba(0,0,0,.06); border:1px solid var(--border-color,#e8f0e9); overflow:hidden; }
        .tw-header { display:flex; align-items:center; justify-content:space-between; padding:16px 20px; border-bottom:1px solid var(--border-color,#e8f0e9); background:var(--green-light,#f8fdf7); }
        table { width:100%; border-collapse:collapse; }
        th { padding:10px 16px; font-size:12px; font-weight:600; text-transform:uppercase; letter-spacing:.5px; color:var(--text-light,#888); background:var(--green-light,#f8fdf7); border-bottom:1px solid var(--border-color,#e8f0e9); text-align:left; }
        td { padding:11px 16px; font-size:13px; border-bottom:1px solid #f5f5f5; vertical-align:middle; }
        tr:last-child td { border-bottom:none; }
        tr:hover td { background:#fafffe; }

        .user-cell { display:flex; align-items:center; gap:10px; }
        .u-avatar  { width:34px; height:34px; border-radius:50%; background:linear-gradient(135deg,#4caf50,#2d5a27); color:#fff; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:13px; flex-shrink:0; }
        .u-avatar img { width:34px; height:34px; border-radius:50%; object-fit:cover; }

        .points-badge { display:inline-flex; align-items:center; gap:4px; background:#fff8e1; color:#f57c00; border:1px solid #ffe082; border-radius:20px; padding:3px 10px; font-size:13px; font-weight:700; }

        /* Search + Sort */
        .filters { display:flex; gap:10px; margin-bottom:18px; }
        .filters input  { flex:1; padding:9px 14px; border:1px solid var(--border-color,#ddd); border-radius:10px; font-size:14px; }
        .filters select { padding:9px 14px; border:1px solid var(--border-color,#ddd); border-radius:10px; font-size:14px; }

        /* Sidebar Panels */
        .side-panel { display:flex; flex-direction:column; gap:18px; }
        .panel-card { background:#fff; border-radius:16px; box-shadow:0 2px 10px rgba(0,0,0,.06); border:1px solid var(--border-color,#e8f0e9); overflow:hidden; }
        .panel-header { padding:14px 18px; border-bottom:1px solid var(--border-color,#e8f0e9); background:var(--green-light,#f8fdf7); font-weight:700; font-size:14px; }
        .panel-body   { padding:18px; }
        .form-group   { margin-bottom:14px; }
        .form-group label { display:block; font-size:12px; font-weight:600; color:var(--text-dark,#555); margin-bottom:5px; }
        .form-group input, .form-group select, .form-group textarea {
            width:100%; padding:9px 12px; border:1px solid var(--border-color,#ddd);
            border-radius:8px; font-size:13px; box-sizing:border-box;
        }
        .form-group textarea { resize:vertical; min-height:60px; }

        /* Pagination */
        .pagination { display:flex; gap:6px; align-items:center; justify-content:center; margin-top:20px; flex-wrap:wrap; }
        .pagination a, .pagination span { padding:6px 13px; border-radius:8px; font-size:13px; font-weight:500; border:1px solid var(--border-color,#ddd); text-decoration:none; color:var(--text-dark,#333); }
        .pagination a:hover { background:var(--green-light,#f0f7ee); }
        .pagination .active { background:var(--green-deep,#2d5a27); color:#fff; border-color:var(--green-deep,#2d5a27); }

        /* Top user highlight */
        .top-user-card { background:linear-gradient(135deg,#fff8e1,#fffde7); border:1px solid #ffe082; border-radius:12px; padding:14px; display:flex; align-items:center; gap:12px; margin-bottom:18px; }
        .top-user-card .crown { font-size:28px; }

        @media (max-width:1100px) { .layout-grid { grid-template-columns:1fr; } .kpi-row { grid-template-columns:repeat(2,1fr); } }
        @media (max-width:640px)  { .kpi-row { grid-template-columns:1fr; } }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="admin-layout">
    <?php include '../partials/sidebar.php'; ?>

    <main class="admin-main">

        <div class="page-header">
            <h1><i class="fas fa-star" style="color:#f9a825;margin-right:8px"></i><?= $pageTitle ?></h1>
        </div>

        <!-- KPI Row -->
        <div class="kpi-row">
            <div class="kpi-mini">
                <div class="km-icon">⭐</div>
                <div class="km-num"><?= number_format($totalPoints) ?></div>
                <div class="km-label">คะแนนสะสมทั้งหมด</div>
            </div>
            <div class="kpi-mini">
                <div class="km-icon">👥</div>
                <div class="km-num"><?= number_format($usersWithPoints) ?></div>
                <div class="km-label">สมาชิกที่มีคะแนน</div>
            </div>
            <div class="kpi-mini">
                <div class="km-icon">📊</div>
                <div class="km-num"><?= number_format($avgPoints, 0) ?></div>
                <div class="km-label">เฉลี่ยต่อคน</div>
            </div>
            <div class="kpi-mini">
                <div class="km-icon">🏆</div>
                <div class="km-num"><?= $topUser ? number_format($topUser['points']) : 0 ?></div>
                <div class="km-label">คะแนนสูงสุด</div>
            </div>
        </div>

        <div class="layout-grid">

            <!-- LEFT: User Table -->
            <div>
                <!-- Top user -->
                <?php if ($topUser && $topUser['points'] > 0): ?>
                <div class="top-user-card">
                    <span class="crown">👑</span>
                    <div>
                        <div style="font-weight:700;font-size:14px"><?= sanitize($topUser['full_name'] ?: $topUser['username']) ?></div>
                        <div style="font-size:12px;color:#888">ผู้นำตารางคะแนน</div>
                    </div>
                    <div style="margin-left:auto">
                        <span class="points-badge">⭐ <?= number_format($topUser['points']) ?> คะแนน</span>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Filters -->
                <form class="filters" method="GET">
                    <input type="text" name="q" placeholder="ค้นหาสมาชิก..." value="<?= sanitize($search) ?>">
                    <select name="sort" onchange="this.form.submit()">
                        <option value="points_desc" <?= $sortBy==='points_desc'?'selected':'' ?>>คะแนน: มาก → น้อย</option>
                        <option value="points_asc"  <?= $sortBy==='points_asc' ?'selected':'' ?>>คะแนน: น้อย → มาก</option>
                        <option value="name"        <?= $sortBy==='name'       ?'selected':'' ?>>ชื่อ A–Z</option>
                    </select>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
                    <?php if ($search): ?><a href="points.php" class="btn btn-outline">ล้าง</a><?php endif; ?>
                </form>

                <div class="table-wrapper">
                    <div class="tw-header">
                        <span style="font-weight:700;font-size:15px">รายการคะแนนสมาชิก
                            <span style="font-size:12px;color:#aaa;font-weight:400;margin-left:8px">(<?= number_format($totalCount) ?> คน)</span>
                        </span>
                    </div>
                    <table>
                        <thead><tr>
                            <th>#</th><th>สมาชิก</th><th>คะแนน</th><th>ปรับคะแนน</th>
                        </tr></thead>
                        <tbody>
                        <?php foreach ($users as $i => $u): ?>
                        <tr>
                            <td style="color:#aaa;font-size:12px"><?= $offset + $i + 1 ?></td>
                            <td>
                                <div class="user-cell">
                                    <div class="u-avatar">
                                        <?php if (!empty($u['profile_image'])): ?>
                                            <img src="<?= SITE_URL ?>/<?= sanitize($u['profile_image']) ?>"
                                                 onerror="this.parentElement.textContent='<?= mb_strtoupper(mb_substr($u['full_name']??$u['username'],0,1)) ?>'">
                                        <?php else: ?>
                                            <?= mb_strtoupper(mb_substr($u['full_name']??$u['username'],0,1)) ?>
                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <div style="font-weight:600"><?= sanitize($u['full_name'] ?: $u['username']) ?></div>
                                        <div style="font-size:11px;color:#aaa"><?= sanitize($u['email']) ?></div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="points-badge">
                                    <i class="fas fa-star" style="font-size:11px"></i>
                                    <?= number_format($u['points']) ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-outline btn-sm"
                                        onclick="openAdjust(<?= $u['id'] ?>, '<?= addslashes($u['full_name'] ?: $u['username']) ?>', <?= $u['points'] ?>)">
                                    <i class="fas fa-sliders-h"></i> ปรับ
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($users)): ?>
                        <tr><td colspan="4" style="text-align:center;padding:30px;color:#aaa">ไม่พบสมาชิก</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?><a href="?page=<?= $page-1 ?>&q=<?= urlencode($search) ?>&sort=<?= $sort ?>">&lsaquo;</a><?php endif; ?>
                    <?php for ($i=max(1,$page-2); $i<=min($totalPages,$page+2); $i++): ?>
                        <?php if ($i===$page): ?><span class="active"><?= $i ?></span>
                        <?php else: ?><a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&sort=<?= $sortBy ?>"><?= $i ?></a><?php endif; ?>
                    <?php endfor; ?>
                    <?php if ($page < $totalPages): ?><a href="?page=<?= $page+1 ?>&q=<?= urlencode($search) ?>&sort=<?= $sortBy ?>">&rsaquo;</a><?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- RIGHT: Panels -->
            <div class="side-panel">

                <!-- Settings -->
                <div class="panel-card">
                    <div class="panel-header"><i class="fas fa-cog" style="color:var(--green-sage,#7aa876);margin-right:6px"></i>ตั้งค่าระบบคะแนน</div>
                    <div class="panel-body">
                        <form method="POST">
                            <input type="hidden" name="save_settings" value="1">
                            <div class="form-group">
                                <label>ได้รับคะแนนทุก __ บาท</label>
                                <input type="number" name="rate_per_baht" min="0.01" step="0.01" value="<?= $ratePerBaht ?>">
                            </div>
                            <div class="form-group">
                                <label>อัตราแลก: __ คะแนน = 1 บาท</label>
                                <input type="number" name="redeem_rate" min="1" value="<?= $redeemRate ?>">
                            </div>
                            <div class="form-group">
                                <label>คะแนนขั้นต่ำที่แลกได้</label>
                                <input type="number" name="min_redeem" min="0" value="<?= $minRedeem ?>">
                            </div>
                            <div class="form-group">
                                <label>คะแนนหมดอายุใน (วัน, 0 = ไม่หมดอายุ)</label>
                                <input type="number" name="expire_days" min="0" value="<?= $expireDays ?>">
                            </div>
                            <button type="submit" class="btn btn-primary" style="width:100%">
                                <i class="fas fa-save"></i> บันทึกการตั้งค่า
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Manual Adjust -->
                <div class="panel-card" id="adjustPanel">
                    <div class="panel-header"><i class="fas fa-sliders-h" style="color:#1e88e5;margin-right:6px"></i>ปรับคะแนนสมาชิก</div>
                    <div class="panel-body">
                        <form method="POST" id="adjustForm">
                            <input type="hidden" name="adjust_points" value="1">
                            <input type="hidden" name="user_id" id="adj_user_id">
                            <div id="adj_user_info" style="background:var(--green-light,#f8fdf7);border-radius:8px;padding:10px 12px;margin-bottom:14px;font-size:13px;color:#555;display:none">
                                <i class="fas fa-user" style="margin-right:5px;color:var(--green-sage)"></i>
                                <span id="adj_user_name"></span>
                                <span style="float:right;font-weight:700">
                                    <i class="fas fa-star" style="color:#f9a825"></i> <span id="adj_current_pts"></span>
                                </span>
                            </div>
                            <div class="form-group">
                                <label>ประเภท</label>
                                <select name="type" id="adj_type">
                                    <option value="add">➕ เพิ่มคะแนน</option>
                                    <option value="deduct">➖ หักคะแนน</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>จำนวนคะแนน</label>
                                <input type="number" name="amount" id="adj_amount" min="1" placeholder="0" required>
                            </div>
                            <div class="form-group">
                                <label>หมายเหตุ</label>
                                <textarea name="note" placeholder="เหตุผลการปรับคะแนน...">ปรับโดย Admin</textarea>
                            </div>
                            <button type="submit" class="btn btn-primary" style="width:100%">
                                <i class="fas fa-check"></i> ยืนยันการปรับคะแนน
                            </button>
                        </form>
                        <p id="adj_hint" style="text-align:center;color:#bbb;font-size:13px;margin-top:12px">
                            เลือกสมาชิกจากตารางด้านซ้ายก่อน
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </main>
</div>

<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>
function openAdjust(userId, userName, currentPts) {
    document.getElementById('adj_user_id').value      = userId;
    document.getElementById('adj_user_name').textContent = userName;
    document.getElementById('adj_current_pts').textContent = currentPts.toLocaleString() + ' คะแนน';
    document.getElementById('adj_user_info').style.display = 'block';
    document.getElementById('adj_hint').style.display      = 'none';
    document.getElementById('adj_amount').focus();

    // Scroll to panel on mobile
    document.getElementById('adjustPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
}
</script>
</body>
</html>
