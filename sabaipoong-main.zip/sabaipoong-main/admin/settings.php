<?php
define('INCLUDED', true);
require_once '../config.php';
requireAdmin();

$pdo = getDB();
$pageTitle = 'ตั้งค่าเว็บไซต์';

// Helper: get/set setting
function getSetting(PDO $pdo, string $key, string $default = ''): string {
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key=?");
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        return $row ? $row['setting_value'] : $default;
    } catch (Exception $e) { return $default; }
}

function saveSetting(PDO $pdo, string $key, string $value): void {
    try {
        $exists = $pdo->prepare("SELECT id FROM settings WHERE setting_key=?");
        $exists->execute([$key]);
        if ($exists->fetch()) {
            $pdo->prepare("UPDATE settings SET setting_value=? WHERE setting_key=?")->execute([$value, $key]);
        } else {
            $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?,?)")->execute([$key, $value]);
        }
    } catch (Exception $e) {}
}

// ===== HANDLE SAVES =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $section = $_POST['section'] ?? '';

    if ($section === 'general') {
        saveSetting($pdo, 'site_name',        trim($_POST['site_name'] ?? ''));
        saveSetting($pdo, 'site_tagline',     trim($_POST['site_tagline'] ?? ''));
        saveSetting($pdo, 'site_email',       trim($_POST['site_email'] ?? ''));
        saveSetting($pdo, 'site_phone',       trim($_POST['site_phone'] ?? ''));
        saveSetting($pdo, 'site_address',     trim($_POST['site_address'] ?? ''));
        // Logo upload
        if (!empty($_FILES['logo']['name'])) {
            $ext = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg','jpeg','png','gif','webp','svg'])) {
                $newName   = 'img/Logo.' . $ext;
                $uploadDir = dirname(__DIR__) . '/' . $newName;
                move_uploaded_file($_FILES['logo']['tmp_name'], $uploadDir);
                saveSetting($pdo, 'site_logo', $newName);
            }
        }
        $_SESSION['flash'] = ['message' => 'บันทึกข้อมูลทั่วไปแล้ว', 'type' => 'success'];
    }

    elseif ($section === 'ecommerce') {
        saveSetting($pdo, 'currency',          trim($_POST['currency'] ?? '฿'));
        saveSetting($pdo, 'vat_rate',          trim($_POST['vat_rate'] ?? '0'));
        saveSetting($pdo, 'shipping_fee',      trim($_POST['shipping_fee'] ?? '0'));
        saveSetting($pdo, 'free_ship_min',     trim($_POST['free_ship_min'] ?? '0'));
        saveSetting($pdo, 'min_order',         trim($_POST['min_order'] ?? '0'));
        saveSetting($pdo, 'low_stock_alert',   trim($_POST['low_stock_alert'] ?? '5'));
        $_SESSION['flash'] = ['message' => 'บันทึกการตั้งค่าร้านค้าแล้ว', 'type' => 'success'];
    }

    elseif ($section === 'payment') {
        saveSetting($pdo, 'bank_name',         trim($_POST['bank_name'] ?? ''));
        saveSetting($pdo, 'bank_account',      trim($_POST['bank_account'] ?? ''));
        saveSetting($pdo, 'bank_account_name', trim($_POST['bank_account_name'] ?? ''));
        saveSetting($pdo, 'promptpay_number',  trim($_POST['promptpay_number'] ?? ''));
        saveSetting($pdo, 'payment_note',      trim($_POST['payment_note'] ?? ''));
        $_SESSION['flash'] = ['message' => 'บันทึกการตั้งค่าการชำระเงินแล้ว', 'type' => 'success'];
    }

    elseif ($section === 'social') {
        saveSetting($pdo, 'social_facebook',   trim($_POST['social_facebook'] ?? ''));
        saveSetting($pdo, 'social_instagram',  trim($_POST['social_instagram'] ?? ''));
        saveSetting($pdo, 'social_line',       trim($_POST['social_line'] ?? ''));
        saveSetting($pdo, 'social_youtube',    trim($_POST['social_youtube'] ?? ''));
        saveSetting($pdo, 'social_tiktok',     trim($_POST['social_tiktok'] ?? ''));
        $_SESSION['flash'] = ['message' => 'บันทึกการตั้งค่าโซเชียลแล้ว', 'type' => 'success'];
    }

    elseif ($section === 'seo') {
        saveSetting($pdo, 'meta_description',  trim($_POST['meta_description'] ?? ''));
        saveSetting($pdo, 'meta_keywords',     trim($_POST['meta_keywords'] ?? ''));
        saveSetting($pdo, 'google_analytics',  trim($_POST['google_analytics'] ?? ''));
        saveSetting($pdo, 'facebook_pixel',    trim($_POST['facebook_pixel'] ?? ''));
        $_SESSION['flash'] = ['message' => 'บันทึกการตั้งค่า SEO แล้ว', 'type' => 'success'];
    }

    elseif ($section === 'maintenance') {
        saveSetting($pdo, 'maintenance_mode',  isset($_POST['maintenance_mode']) ? '1' : '0');
        saveSetting($pdo, 'maintenance_msg',   trim($_POST['maintenance_msg'] ?? ''));
        saveSetting($pdo, 'allow_register',    isset($_POST['allow_register']) ? '1' : '0');
        saveSetting($pdo, 'items_per_page',    trim($_POST['items_per_page'] ?? '12'));
        $_SESSION['flash'] = ['message' => 'บันทึกการตั้งค่าระบบแล้ว', 'type' => 'success'];
    }

    header('Location: settings.php?tab=' . ($_POST['section'] ?? 'general')); exit;
}

// ===== LOAD ALL SETTINGS =====
$s = [];
$keys = [
    'site_name','site_tagline','site_email','site_phone','site_address','site_logo',
    'currency','vat_rate','shipping_fee','free_ship_min','min_order','low_stock_alert',
    'bank_name','bank_account','bank_account_name','promptpay_number','payment_note',
    'social_facebook','social_instagram','social_line','social_youtube','social_tiktok',
    'meta_description','meta_keywords','google_analytics','facebook_pixel',
    'maintenance_mode','maintenance_msg','allow_register','items_per_page',
];
foreach ($keys as $k) $s[$k] = getSetting($pdo, $k);

// Defaults
if ($s['currency']        === '') $s['currency']        = '฿';
if ($s['vat_rate']        === '') $s['vat_rate']        = '7';
if ($s['shipping_fee']    === '') $s['shipping_fee']    = '0';
if ($s['low_stock_alert'] === '') $s['low_stock_alert'] = '5';
if ($s['items_per_page']  === '') $s['items_per_page']  = '12';
if ($s['allow_register']  === '') $s['allow_register']  = '1';

$activeTab = $_GET['tab'] ?? 'general';
$tabs = [
    'general'     => ['icon'=>'fa-globe',          'label'=>'ทั่วไป'],
    'ecommerce'   => ['icon'=>'fa-store',           'label'=>'ร้านค้า'],
    'payment'     => ['icon'=>'fa-credit-card',     'label'=>'การชำระเงิน'],
    'social'      => ['icon'=>'fa-share-alt',       'label'=>'โซเชียล'],
    'seo'         => ['icon'=>'fa-search-plus',     'label'=>'SEO'],
    'maintenance' => ['icon'=>'fa-tools',           'label'=>'ระบบ'],
];
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .page-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; padding-bottom:16px; border-bottom:2px solid var(--border-color,#e8f0e9); }
        .page-header h1 { font-size:22px; font-weight:700; color:var(--green-deep,#2d5a27); margin:0; }

        /* Tab Layout */
        .settings-layout { display:grid; grid-template-columns:220px 1fr; gap:24px; align-items:start; }

        /* Sidebar Tabs */
        .tab-nav { background:#fff; border-radius:16px; box-shadow:0 2px 10px rgba(0,0,0,.06); border:1px solid var(--border-color,#e8f0e9); overflow:hidden; position:sticky; top:80px; }
        .tab-nav-header { padding:14px 18px; border-bottom:1px solid var(--border-color,#e8f0e9); background:var(--green-light,#f8fdf7); font-weight:700; font-size:13px; color:var(--text-light,#888); text-transform:uppercase; letter-spacing:.5px; }
        .tab-nav a { display:flex; align-items:center; gap:10px; padding:11px 18px; text-decoration:none; color:var(--text-dark,#444); font-size:14px; font-weight:500; transition:.15s; border-left:3px solid transparent; }
        .tab-nav a:hover { background:var(--green-light,#f0f7ee); color:var(--green-deep,#2d5a27); }
        .tab-nav a.active { background:linear-gradient(90deg,#e8f5e9,#f0f7ee); color:var(--green-deep,#2d5a27); font-weight:700; border-left-color:var(--green-deep,#2d5a27); }
        .tab-nav a i { width:18px; text-align:center; }

        /* Settings Panel */
        .settings-panel { background:#fff; border-radius:16px; box-shadow:0 2px 10px rgba(0,0,0,.06); border:1px solid var(--border-color,#e8f0e9); overflow:hidden; }
        .panel-header { padding:20px 24px; border-bottom:1px solid var(--border-color,#e8f0e9); background:var(--green-light,#f8fdf7); }
        .panel-header h2 { font-size:17px; font-weight:700; color:var(--green-deep,#2d5a27); margin:0; }
        .panel-header p  { font-size:13px; color:var(--text-light,#888); margin:4px 0 0; }
        .panel-body  { padding:24px; }

        /* Form */
        .form-section { margin-bottom:28px; }
        .form-section-title { font-size:13px; font-weight:700; text-transform:uppercase; letter-spacing:.5px; color:var(--text-light,#888); margin-bottom:14px; padding-bottom:8px; border-bottom:1px solid #f0f0f0; }
        .form-grid   { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
        .form-group  { margin-bottom:0; }
        .form-group.full { grid-column:1/-1; }
        .form-group label { display:block; font-size:13px; font-weight:600; color:var(--text-dark,#333); margin-bottom:6px; }
        .form-group input, .form-group select, .form-group textarea {
            width:100%; padding:10px 14px; border:1px solid var(--border-color,#ddd); border-radius:10px; font-size:14px; box-sizing:border-box; transition:border-color .15s;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { outline:none; border-color:var(--green-sage,#7aa876); box-shadow:0 0 0 3px rgba(122,168,118,.1); }
        .form-group textarea { resize:vertical; min-height:90px; }
        .form-hint  { font-size:11px; color:var(--text-light,#aaa); margin-top:5px; }
        .form-actions { padding:20px 24px; border-top:1px solid var(--border-color,#e8f0e9); background:var(--green-light,#f8fdf7); display:flex; align-items:center; gap:12px; }

        /* Toggle Switch */
        .toggle-group { display:flex; align-items:center; justify-content:space-between; padding:12px 16px; background:var(--green-light,#f8fdf7); border-radius:10px; border:1px solid var(--border-color,#e8f0e9); margin-bottom:14px; }
        .toggle-group label { font-size:14px; font-weight:600; color:var(--text-dark,#333); margin:0; display:flex; align-items:center; gap:8px; }
        .toggle-group .hint { font-size:12px; color:var(--text-light,#888); margin-top:2px; }
        .switch { position:relative; display:inline-block; width:44px; height:24px; }
        .switch input { opacity:0; width:0; height:0; }
        .slider { position:absolute; cursor:pointer; top:0; left:0; right:0; bottom:0; background:#ccc; border-radius:24px; transition:.3s; }
        .slider:before { position:absolute; content:''; height:18px; width:18px; left:3px; bottom:3px; background:#fff; border-radius:50%; transition:.3s; }
        input:checked + .slider { background:var(--green-deep,#2d5a27); }
        input:checked + .slider:before { transform:translateX(20px); }

        /* Logo Preview */
        .logo-preview { display:flex; align-items:center; gap:14px; background:#f8f8f8; border-radius:10px; padding:12px 16px; margin-bottom:10px; border:1px solid #eee; }
        .logo-preview img { height:48px; max-width:120px; object-fit:contain; }
        .logo-preview span { font-size:12px; color:#888; }

        /* Social icons */
        .social-input-wrapper { position:relative; }
        .social-input-wrapper .si-icon { position:absolute; left:12px; top:50%; transform:translateY(-50%); font-size:16px; }
        .social-input-wrapper input { padding-left:38px; }
        .si-fb   { color:#1877f2; }
        .si-ig   { color:#e1306c; }
        .si-line { color:#06c755; }
        .si-yt   { color:#ff0000; }
        .si-tt   { color:#010101; }

        /* Warning Banner */
        .maintenance-banner { background:#fff3cd; border:1px solid #ffc107; border-radius:10px; padding:12px 16px; margin-bottom:20px; font-size:13px; display:flex; align-items:center; gap:10px; color:#856404; }

        @media (max-width:900px)  { .settings-layout { grid-template-columns:1fr; } .tab-nav { position:static; } }
        @media (max-width:640px)  { .form-grid { grid-template-columns:1fr; } }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="admin-layout">
    <?php include '../partials/sidebar.php'; ?>

    <main class="admin-main">

        <div class="page-header">
            <h1><i class="fas fa-cog" style="color:var(--green-sage,#7aa876);margin-right:8px"></i><?= $pageTitle ?></h1>
        </div>

        <div class="settings-layout">

            <!-- Tab Nav -->
            <div class="tab-nav">
                <div class="tab-nav-header">เมนูตั้งค่า</div>
                <?php foreach ($tabs as $key => $tab): ?>
                <a href="?tab=<?= $key ?>" class="<?= $activeTab === $key ? 'active' : '' ?>">
                    <i class="fas <?= $tab['icon'] ?>"></i>
                    <?= $tab['label'] ?>
                </a>
                <?php endforeach; ?>
            </div>

            <!-- Settings Panel -->
            <div class="settings-panel">

                <!-- ===== GENERAL ===== -->
                <?php if ($activeTab === 'general'): ?>
                <div class="panel-header">
                    <h2><i class="fas fa-globe" style="margin-right:8px"></i>ข้อมูลทั่วไป</h2>
                    <p>ชื่อเว็บไซต์, ข้อมูลติดต่อ และโลโก้</p>
                </div>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="section" value="general">
                    <div class="panel-body">
                        <div class="form-section">
                            <div class="form-section-title">ข้อมูลเว็บไซต์</div>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label>ชื่อเว็บไซต์</label>
                                    <input type="text" name="site_name" value="<?= sanitize($s['site_name']) ?>" placeholder="ชื่อร้านค้า">
                                </div>
                                <div class="form-group">
                                    <label>คำโปรย (Tagline)</label>
                                    <input type="text" name="site_tagline" value="<?= sanitize($s['site_tagline']) ?>" placeholder="เช่น ของสดจากสวน">
                                </div>
                                <div class="form-group">
                                    <label>อีเมลติดต่อ</label>
                                    <input type="email" name="site_email" value="<?= sanitize($s['site_email']) ?>" placeholder="contact@example.com">
                                </div>
                                <div class="form-group">
                                    <label>เบอร์โทรศัพท์</label>
                                    <input type="text" name="site_phone" value="<?= sanitize($s['site_phone']) ?>" placeholder="0xx-xxx-xxxx">
                                </div>
                                <div class="form-group full">
                                    <label>ที่อยู่</label>
                                    <textarea name="site_address" placeholder="ที่อยู่ร้านค้า"><?= sanitize($s['site_address']) ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="form-section">
                            <div class="form-section-title">โลโก้เว็บไซต์</div>
                            <?php if (!empty($s['site_logo'])): ?>
                            <div class="logo-preview">
                                <img src="<?= SITE_URL ?>/<?= sanitize($s['site_logo']) ?>" alt="Logo" onerror="this.style.display='none'">
                                <span>โลโก้ปัจจุบัน</span>
                            </div>
                            <?php endif; ?>
                            <input type="file" name="logo" accept="image/*">
                            <div class="form-hint">รองรับ JPG, PNG, SVG, WebP แนะนำขนาด 200×60 px</div>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> บันทึก</button>
                    </div>
                </form>

                <!-- ===== ECOMMERCE ===== -->
                <?php elseif ($activeTab === 'ecommerce'): ?>
                <div class="panel-header">
                    <h2><i class="fas fa-store" style="margin-right:8px"></i>ตั้งค่าร้านค้า</h2>
                    <p>สกุลเงิน, ค่าจัดส่ง, VAT และการแสดงผล</p>
                </div>
                <form method="POST">
                    <input type="hidden" name="section" value="ecommerce">
                    <div class="panel-body">
                        <div class="form-section">
                            <div class="form-section-title">การเงิน</div>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label>สัญลักษณ์สกุลเงิน</label>
                                    <input type="text" name="currency" value="<?= sanitize($s['currency']) ?>" placeholder="฿">
                                </div>
                                <div class="form-group">
                                    <label>อัตรา VAT (%)</label>
                                    <input type="number" name="vat_rate" min="0" max="100" step="0.01" value="<?= $s['vat_rate'] ?>">
                                    <div class="form-hint">0 = ไม่คิด VAT</div>
                                </div>
                            </div>
                        </div>
                        <div class="form-section">
                            <div class="form-section-title">ค่าจัดส่ง</div>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label>ค่าจัดส่งมาตรฐาน (บาท)</label>
                                    <input type="number" name="shipping_fee" min="0" step="0.01" value="<?= $s['shipping_fee'] ?>">
                                </div>
                                <div class="form-group">
                                    <label>ฟรีค่าจัดส่งเมื่อสั่งซื้อครบ (บาท)</label>
                                    <input type="number" name="free_ship_min" min="0" step="0.01" value="<?= $s['free_ship_min'] ?>">
                                    <div class="form-hint">0 = ไม่มีเงื่อนไขฟรีค่าส่ง</div>
                                </div>
                            </div>
                        </div>
                        <div class="form-section">
                            <div class="form-section-title">การสั่งซื้อ</div>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label>ยอดสั่งซื้อขั้นต่ำ (บาท)</label>
                                    <input type="number" name="min_order" min="0" step="0.01" value="<?= $s['min_order'] ?>">
                                </div>
                                <div class="form-group">
                                    <label>แจ้งเตือนสต็อกต่ำเมื่อเหลือ (ชิ้น)</label>
                                    <input type="number" name="low_stock_alert" min="1" value="<?= $s['low_stock_alert'] ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> บันทึก</button>
                    </div>
                </form>

                <!-- ===== PAYMENT ===== -->
                <?php elseif ($activeTab === 'payment'): ?>
                <div class="panel-header">
                    <h2><i class="fas fa-credit-card" style="margin-right:8px"></i>ตั้งค่าการชำระเงิน</h2>
                    <p>บัญชีธนาคาร และ PromptPay</p>
                </div>
                <form method="POST">
                    <input type="hidden" name="section" value="payment">
                    <div class="panel-body">
                        <div class="form-section">
                            <div class="form-section-title">บัญชีธนาคาร</div>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label>ชื่อธนาคาร</label>
                                    <input type="text" name="bank_name" value="<?= sanitize($s['bank_name']) ?>" placeholder="เช่น กสิกรไทย, ไทยพาณิชย์">
                                </div>
                                <div class="form-group">
                                    <label>เลขที่บัญชี</label>
                                    <input type="text" name="bank_account" value="<?= sanitize($s['bank_account']) ?>" placeholder="xxx-x-xxxxx-x">
                                </div>
                                <div class="form-group full">
                                    <label>ชื่อบัญชี</label>
                                    <input type="text" name="bank_account_name" value="<?= sanitize($s['bank_account_name']) ?>" placeholder="ชื่อ-นามสกุล / บริษัท">
                                </div>
                            </div>
                        </div>
                        <div class="form-section">
                            <div class="form-section-title">PromptPay</div>
                            <div class="form-group">
                                <label>หมายเลข PromptPay (เบอร์โทร / เลขบัตรประชาชน)</label>
                                <input type="text" name="promptpay_number" value="<?= sanitize($s['promptpay_number']) ?>" placeholder="0xx-xxx-xxxx">
                            </div>
                        </div>
                        <div class="form-section">
                            <div class="form-section-title">หมายเหตุการชำระเงิน</div>
                            <div class="form-group">
                                <label>ข้อความแสดงหลังสั่งซื้อ</label>
                                <textarea name="payment_note" placeholder="เช่น กรุณาโอนเงินภายใน 24 ชั่วโมง..."><?= sanitize($s['payment_note']) ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> บันทึก</button>
                    </div>
                </form>

                <!-- ===== SOCIAL ===== -->
                <?php elseif ($activeTab === 'social'): ?>
                <div class="panel-header">
                    <h2><i class="fas fa-share-alt" style="margin-right:8px"></i>โซเชียลมีเดีย</h2>
                    <p>ลิงก์โซเชียลที่แสดงบนเว็บไซต์</p>
                </div>
                <form method="POST">
                    <input type="hidden" name="section" value="social">
                    <div class="panel-body">
                        <?php
                        $socials = [
                            ['name'=>'social_facebook',  'label'=>'Facebook',  'icon'=>'fab fa-facebook-f',  'cls'=>'si-fb',   'placeholder'=>'https://facebook.com/yourpage'],
                            ['name'=>'social_instagram', 'label'=>'Instagram', 'icon'=>'fab fa-instagram',   'cls'=>'si-ig',   'placeholder'=>'https://instagram.com/yourpage'],
                            ['name'=>'social_line',      'label'=>'LINE',      'icon'=>'fab fa-line',        'cls'=>'si-line', 'placeholder'=>'https://line.me/ti/p/~yourId'],
                            ['name'=>'social_youtube',   'label'=>'YouTube',   'icon'=>'fab fa-youtube',     'cls'=>'si-yt',   'placeholder'=>'https://youtube.com/@yourchannel'],
                            ['name'=>'social_tiktok',    'label'=>'TikTok',    'icon'=>'fab fa-tiktok',      'cls'=>'si-tt',   'placeholder'=>'https://tiktok.com/@yourpage'],
                        ];
                        foreach ($socials as $sc): ?>
                        <div class="form-group" style="margin-bottom:16px">
                            <label><?= $sc['label'] ?></label>
                            <div class="social-input-wrapper">
                                <i class="<?= $sc['icon'] ?> si-icon <?= $sc['cls'] ?>"></i>
                                <input type="url" name="<?= $sc['name'] ?>"
                                       value="<?= sanitize($s[$sc['name']]) ?>"
                                       placeholder="<?= $sc['placeholder'] ?>">
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> บันทึก</button>
                    </div>
                </form>

                <!-- ===== SEO ===== -->
                <?php elseif ($activeTab === 'seo'): ?>
                <div class="panel-header">
                    <h2><i class="fas fa-search-plus" style="margin-right:8px"></i>SEO & Analytics</h2>
                    <p>Meta tags และโค้ดติดตาม</p>
                </div>
                <form method="POST">
                    <input type="hidden" name="section" value="seo">
                    <div class="panel-body">
                        <div class="form-section">
                            <div class="form-section-title">Meta Tags</div>
                            <div class="form-group" style="margin-bottom:16px">
                                <label>Meta Description</label>
                                <textarea name="meta_description" placeholder="คำอธิบายเว็บไซต์สำหรับ Search Engine (แนะนำ 150–160 ตัวอักษร)"><?= sanitize($s['meta_description']) ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Keywords</label>
                                <input type="text" name="meta_keywords" value="<?= sanitize($s['meta_keywords']) ?>" placeholder="keyword1, keyword2, keyword3">
                                <div class="form-hint">คั่นด้วยเครื่องหมาย , (comma)</div>
                            </div>
                        </div>
                        <div class="form-section">
                            <div class="form-section-title">Analytics & Tracking</div>
                            <div class="form-group" style="margin-bottom:16px">
                                <label>Google Analytics ID</label>
                                <input type="text" name="google_analytics" value="<?= sanitize($s['google_analytics']) ?>" placeholder="G-XXXXXXXXXX หรือ UA-XXXXXXXXX-X">
                            </div>
                            <div class="form-group">
                                <label>Facebook Pixel ID</label>
                                <input type="text" name="facebook_pixel" value="<?= sanitize($s['facebook_pixel']) ?>" placeholder="ตัวเลข Pixel ID">
                            </div>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> บันทึก</button>
                    </div>
                </form>

                <!-- ===== MAINTENANCE ===== -->
                <?php elseif ($activeTab === 'maintenance'): ?>
                <div class="panel-header">
                    <h2><i class="fas fa-tools" style="margin-right:8px"></i>ตั้งค่าระบบ</h2>
                    <p>โหมดปิดปรับปรุง, การสมัครสมาชิก และการแสดงผล</p>
                </div>
                <form method="POST">
                    <input type="hidden" name="section" value="maintenance">
                    <div class="panel-body">

                        <?php if ($s['maintenance_mode'] === '1'): ?>
                        <div class="maintenance-banner">
                            <i class="fas fa-exclamation-triangle"></i>
                            <strong>เว็บไซต์อยู่ในโหมดปิดปรับปรุง</strong> — ผู้เยี่ยมชมจะไม่สามารถเข้าถึงได้
                        </div>
                        <?php endif; ?>

                        <div class="form-section">
                            <div class="form-section-title">โหมดเว็บไซต์</div>
                            <div class="toggle-group">
                                <div>
                                    <label><i class="fas fa-tools" style="color:#fb8c00"></i> โหมดปิดปรับปรุง</label>
                                    <div class="hint">ผู้เยี่ยมชมทั่วไปจะเห็นหน้าแจ้งปิดปรับปรุง</div>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" name="maintenance_mode" <?= $s['maintenance_mode']==='1' ? 'checked' : '' ?>>
                                    <span class="slider"></span>
                                </label>
                            </div>
                            <div class="form-group" style="margin-top:12px">
                                <label>ข้อความแจ้งปิดปรับปรุง</label>
                                <textarea name="maintenance_msg" placeholder="เช่น ขณะนี้เว็บไซต์กำลังปรับปรุง กรุณากลับมาใหม่เร็วๆ นี้"><?= sanitize($s['maintenance_msg']) ?></textarea>
                            </div>
                        </div>

                        <div class="form-section">
                            <div class="form-section-title">สมาชิก</div>
                            <div class="toggle-group">
                                <div>
                                    <label><i class="fas fa-user-plus" style="color:#43a047"></i> อนุญาตสมัครสมาชิกใหม่</label>
                                    <div class="hint">เปิด/ปิดการสมัครสมาชิกของผู้ใช้ทั่วไป</div>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" name="allow_register" <?= $s['allow_register']!=='0' ? 'checked' : '' ?>>
                                    <span class="slider"></span>
                                </label>
                            </div>
                        </div>

                        <div class="form-section">
                            <div class="form-section-title">การแสดงผล</div>
                            <div class="form-group">
                                <label>จำนวนสินค้าต่อหน้า</label>
                                <select name="items_per_page">
                                    <?php foreach ([8,12,16,20,24,36,48] as $n): ?>
                                    <option value="<?= $n ?>" <?= $s['items_per_page']==$n?'selected':'' ?>><?= $n ?> รายการ</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> บันทึก</button>
                        <?php if ($s['maintenance_mode'] === '1'): ?>
                        <span style="font-size:13px;color:#e53935;font-weight:600">
                            <i class="fas fa-exclamation-circle"></i> เว็บไซต์ปิดปรับปรุงอยู่
                        </span>
                        <?php endif; ?>
                    </div>
                </form>

                <?php endif; ?>
            </div><!-- /.settings-panel -->

        </div><!-- /.settings-layout -->
    </main>
</div>

<script src="<?= SITE_URL ?>/js/main.js"></script>
</body>
</html>
