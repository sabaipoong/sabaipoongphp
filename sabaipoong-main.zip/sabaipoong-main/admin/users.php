<?php
define('INCLUDED', true);
require_once '../config.php';
requireAdmin();

$pdo = getDB();
$pageTitle = 'จัดการสมาชิก';

// Handle actions
$action = $_GET['action'] ?? 'list';

// --- CSRF Token Helper ---
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

function verifyCsrf() {
    $token = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], $token)) {
        $_SESSION['flash'] = ['message' => 'คำขอไม่ถูกต้อง (CSRF)', 'type' => 'danger'];
        header('Location: users.php'); exit;
    }
}

// --- TOGGLE BAN ---
if ($action === 'toggle_ban' && isset($_GET['id'])) {
    verifyCsrf();
    $id   = (int)$_GET['id'];
    if ($id === (int)$_SESSION['user_id']) {
        $_SESSION['flash'] = ['message' => 'ไม่สามารถระงับบัญชีของตัวเองได้', 'type' => 'danger'];
        header('Location: users.php'); exit;
    }
    $stmt = $pdo->prepare("SELECT is_banned FROM users WHERE id=?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    if ($user) {
        $newBan = $user['is_banned'] ? 0 : 1;
        $pdo->prepare("UPDATE users SET is_banned=? WHERE id=?")->execute([$newBan, $id]);
        $_SESSION['flash'] = ['message' => $newBan ? 'ระงับบัญชีผู้ใช้แล้ว' : 'เปิดใช้งานบัญชีแล้ว', 'type' => 'success'];
    }
    header('Location: users.php'); exit;
}

// --- PROMOTE ADMIN ---
if ($action === 'set_role' && isset($_GET['id'], $_GET['role'])) {
    verifyCsrf();
    $id   = (int)$_GET['id'];
    if ($id === (int)$_SESSION['user_id']) {
        $_SESSION['flash'] = ['message' => 'ไม่สามารถเปลี่ยนสิทธิ์ของตัวเองได้', 'type' => 'danger'];
        header('Location: users.php'); exit;
    }
    $role = in_array($_GET['role'], ['user','admin']) ? $_GET['role'] : 'user';
    $pdo->prepare("UPDATE users SET role=? WHERE id=?")->execute([$role, $id]);
    $_SESSION['flash'] = ['message' => 'เปลี่ยนสิทธิ์ผู้ใช้เรียบร้อย', 'type' => 'success'];
    header('Location: users.php'); exit;
}

// --- LIST ---
$search      = trim($_GET['q'] ?? '');
$filterRole  = $_GET['role'] ?? '';
$page        = max(1, (int)($_GET['page'] ?? 1));
$perPage     = 20;
$offset      = ($page - 1) * $perPage;

$where     = "WHERE 1=1";
$params    = [];
if ($search) {
    $where  .= " AND (full_name LIKE ? OR username LIKE ? OR email LIKE ?)";
    $params  = array_merge($params, ["%$search%","%$search%","%$search%"]);
}
if ($filterRole) {
    $where  .= " AND role=?";
    $params[] = $filterRole;
}

$countSQL = "SELECT COUNT(*) FROM users $where";
$listSQL  = "SELECT * FROM users $where ORDER BY id DESC LIMIT $perPage OFFSET $offset";

$stmt = $pdo->prepare($countSQL);
$stmt->execute($params);
$totalCount = $stmt->fetchColumn();

$stmt = $pdo->prepare($listSQL);
$stmt->execute($params);
$users = $stmt->fetchAll();

$totalPages = ceil($totalCount / $perPage);

// Summary counts
$totalMembers = $pdo->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
$totalAdmins  = $pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
$banned       = $pdo->query("SELECT COUNT(*) FROM users WHERE is_banned=1")->fetchColumn();

?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .page-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; padding-bottom:16px; border-bottom:2px solid var(--border-color,#e8f0e9); }
        .page-header h1 { font-size:22px; font-weight:700; color:var(--green-deep,#2d5a27); margin:0; }
        .mini-stats { display:grid; grid-template-columns:repeat(3,1fr); gap:16px; margin-bottom:24px; }
        .mini-stat { background:#fff; border-radius:14px; padding:18px 20px; box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid var(--border-color,#e8f0e9); display:flex; align-items:center; gap:14px; }
        .mini-stat .ms-icon { width:44px; height:44px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:18px; flex-shrink:0; }
        .mini-stat h4 { font-size:22px; font-weight:700; margin:0; }
        .mini-stat p  { font-size:13px; color:var(--text-light,#888); margin:0; }
        .filters { display:flex; gap:10px; margin-bottom:20px; flex-wrap:wrap; }
        .filters input { flex:1; min-width:200px; padding:10px 16px; border:1px solid var(--border-color,#ddd); border-radius:10px; font-size:14px; }
        .filters select { padding:10px 14px; border:1px solid var(--border-color,#ddd); border-radius:10px; font-size:14px; }
        .table-wrapper { background:#fff; border-radius:16px; box-shadow:0 2px 12px rgba(0,0,0,.06); border:1px solid var(--border-color,#e8f0e9); overflow:hidden; }
        table { width:100%; border-collapse:collapse; }
        th { padding:10px 16px; font-size:12px; font-weight:600; text-transform:uppercase; letter-spacing:.5px; color:var(--text-light,#888); background:var(--green-light,#f8fdf7); border-bottom:1px solid var(--border-color,#e8f0e9); text-align:left; }
        td { padding:12px 16px; font-size:14px; border-bottom:1px solid #f5f5f5; vertical-align:middle; }
        tr:last-child td { border-bottom:none; }
        tr:hover td { background:#fafffe; }
        .avatar { width:38px; height:38px; border-radius:50%; object-fit:cover; border:2px solid #eee; }
        .avatar-placeholder { width:38px; height:38px; border-radius:50%; background:var(--green-light,#e8f5e9); display:flex; align-items:center; justify-content:center; font-weight:700; font-size:14px; color:var(--green-deep,#2d5a27); flex-shrink:0; }
        .actions { display:flex; gap:6px; }
        .pagination { display:flex; gap:6px; align-items:center; justify-content:center; margin-top:24px; flex-wrap:wrap; }
        .pagination a, .pagination span { padding:7px 14px; border-radius:8px; font-size:13px; font-weight:500; border:1px solid var(--border-color,#ddd); text-decoration:none; color:var(--text-dark,#333); }
        .pagination a:hover { background:var(--green-light,#f0f7ee); }
        .pagination .active { background:var(--green-deep,#2d5a27); color:#fff; border-color:var(--green-deep,#2d5a27); }
        .filter-link { padding:8px 16px; border-radius:20px; font-size:13px; font-weight:500; text-decoration:none; border:1px solid var(--border-color,#ddd); color:var(--text-dark,#333); white-space:nowrap; }
        .filter-link:hover, .filter-link.active { background:var(--green-deep,#2d5a27); color:#fff; border-color:var(--green-deep,#2d5a27); }
    </style>
</head>
<body>
<?php include __DIR__ . '/navbar.php'; ?>

<div class="admin-layout">
    <?php include '../partials/sidebar.php'; ?>

    <main class="admin-main">

        <div class="page-header">
            <h1><i class="fas fa-users" style="color:var(--green-sage,#7aa876);margin-right:8px"></i><?= $pageTitle ?></h1>
        </div>

        <!-- Mini Stats -->
        <div class="mini-stats">
            <div class="mini-stat">
                <div class="ms-icon" style="background:#e3f2fd"><i class="fas fa-users" style="color:#1e88e5"></i></div>
                <div>
                    <h4><?= number_format($totalMembers) ?></h4>
                    <p>สมาชิกทั้งหมด</p>
                </div>
            </div>
            <div class="mini-stat">
                <div class="ms-icon" style="background:#f3e5f5"><i class="fas fa-user-shield" style="color:#8e24aa"></i></div>
                <div>
                    <h4><?= number_format($totalAdmins) ?></h4>
                    <p>ผู้ดูแลระบบ</p>
                </div>
            </div>
            <div class="mini-stat">
                <div class="ms-icon" style="background:#ffebee"><i class="fas fa-user-slash" style="color:#e53935"></i></div>
                <div>
                    <h4><?= number_format($banned) ?></h4>
                    <p>ถูกระงับ</p>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <form class="filters" method="GET">
            <input type="text" name="q" placeholder="ค้นหา ชื่อ / username / อีเมล..." value="<?= sanitize($search) ?>">
            <select name="role">
    <option value="">ทุกบทบาท</option>
    <option value="user"  <?= ($filterRole === 'user' || empty($filterRole)) ? 'selected' : '' ?>>สมาชิก</option>
    <option value="admin" <?= $filterRole === 'admin' ? 'selected' : '' ?>>Admin</option>
</select>            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> ค้นหา</button>
            <?php if ($search || $filterRole): ?>
            <a href="users.php" class="btn btn-outline">ล้าง</a>
            <?php endif; ?>
        </form>

        <!-- Table -->
        <div class="table-wrapper">
            <div style="display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--border-color,#e8f0e9);background:var(--green-light,#f8fdf7)">
                <span style="font-weight:700;font-size:15px">รายการสมาชิก
                    <span style="font-size:13px;color:var(--text-light,#888);font-weight:400;margin-left:8px">(<?= number_format($totalCount) ?> คน)</span>
                </span>
            </div>
            <table>
                <thead><tr>
                    <th>#</th>
                    <th>ผู้ใช้</th>
                    <th>อีเมล</th>
                    <th>สิทธิ์</th>
                    <th>สถานะ</th>
                    <th>วันสมัคร</th>
                    <th>จัดการ</th>
                </tr></thead>
                <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td style="color:var(--text-light,#aaa);font-size:12px"><?= $u['id'] ?></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:10px">
                            <?php if (!empty($u['profile_image']) && file_exists(dirname(__DIR__).'/'.$u['profile_image'])): ?>
                                <img src="<?= SITE_URL ?>/<?= sanitize($u['profile_image']) ?>" class="avatar" alt="">
                            <?php else: ?>
                                <div class="avatar-placeholder"><?= mb_strtoupper(mb_substr($u['full_name'] ?? $u['username'], 0, 1)) ?></div>
                            <?php endif; ?>
                            <div>
                                <div style="font-weight:600"><?= sanitize($u['full_name'] ?? $u['username']) ?></div>
                                <div style="font-size:12px;color:var(--text-light,#888)">@<?= sanitize($u['username']) ?></div>
                            </div>
                        </div>
                    </td>
                    <td style="font-size:13px"><?= sanitize($u['email']) ?></td>
                    <td>
                        <?php if ($u['role'] === 'admin'): ?>
                            <span class="badge badge-info"><i class="fas fa-shield-alt" style="margin-right:3px"></i>Admin</span>
                        <?php else: ?>
                            <span class="badge" style="background:#e8f5e9;color:#2e7d32"><i class="fas fa-user" style="margin-right:3px"></i>สมาชิก</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (!empty($u['is_banned'])): ?>
                            <span class="badge badge-danger"><i class="fas fa-ban" style="margin-right:3px"></i>ระงับ</span>
                        <?php else: ?>
                            <span class="badge badge-success"><i class="fas fa-check-circle" style="margin-right:3px"></i>ปกติ</span>
                        <?php endif; ?>
                    </td>
                    <td style="font-size:13px;color:var(--text-light,#888)"><?= date('d/m/Y', strtotime($u['created_at'])) ?></td>
                    <td>
                        <div class="actions">
                            <?php if ($u['id'] != $_SESSION['user_id']): ?>
                                <!-- Ban/Unban -->
                                <a href="users.php?action=toggle_ban&id=<?= $u['id'] ?>&csrf_token=<?= $csrfToken ?>"
                                   class="btn btn-sm <?= $u['is_banned'] ? 'btn-primary' : '' ?>"
                                   style="<?= $u['is_banned'] ? '' : 'background:#fff3e0;color:#e65100;border:1px solid #ffcc80' ?>"
                                   onclick="return confirm('<?= $u['is_banned'] ? 'เปิดใช้งาน' : 'ระงับ' ?>บัญชีนี้?')">
                                    <i class="fas fa-<?= $u['is_banned'] ? 'unlock' : 'ban' ?>"></i>
                                </a>
                                <!-- Set Role -->
                                <a href="users.php?action=set_role&id=<?= $u['id'] ?>&role=<?= $u['role']==='admin'?'user':'admin' ?>&csrf_token=<?= $csrfToken ?>"
                                   class="btn btn-sm btn-outline"
                                   onclick="return confirm('เปลี่ยนสิทธิ์ผู้ใช้นี้?')">
                                    <i class="fas fa-<?= $u['role']==='admin' ? 'user-minus' : 'user-shield' ?>"></i>
                                </a>
                            <?php else: ?>
                                <span style="font-size:12px;color:var(--text-light,#aaa)">คุณ</span>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($users)): ?>
                <tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-light,#888)">
                    <i class="fas fa-users" style="font-size:32px;display:block;margin-bottom:10px;opacity:.4"></i>
                    ไม่พบข้อมูลสมาชิก
                </td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?= $page-1 ?>&q=<?= urlencode($search) ?>&role=<?= $filterRole ?>"><i class="fas fa-chevron-left"></i></a>
            <?php endif; ?>
            <?php for ($i = max(1,$page-2); $i <= min($totalPages,$page+2); $i++): ?>
                <?php if ($i === $page): ?>
                    <span class="active"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&role=<?= $filterRole ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            <?php if ($page < $totalPages): ?>
                <a href="?page=<?= $page+1 ?>&q=<?= urlencode($search) ?>&role=<?= $filterRole ?>"><i class="fas fa-chevron-right"></i></a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

    </main>
</div>

<script src="<?= SITE_URL ?>/js/main.js"></script>
</body>
</html>
