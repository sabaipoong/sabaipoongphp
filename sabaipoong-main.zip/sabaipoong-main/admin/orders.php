<?php
define('INCLUDED', true);
require_once '../config.php';
requireAdmin();

$pdo = getDB();
$pageTitle = 'จัดการออเดอร์';

// --- UPDATE STATUS ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $id     = (int)$_POST['order_id'];
    $status = $_POST['status'];
    $allowed = ['pending','confirmed','shipping','delivered','cancelled'];
    if (in_array($status, $allowed)) {
        $pdo->prepare("UPDATE orders SET status=? WHERE id=?")->execute([$status, $id]);
        $_SESSION['flash'] = ['message' => 'อัปเดตสถานะออเดอร์แล้ว', 'type' => 'success'];
    }
    header('Location: orders.php'); exit;
}

// --- FILTER ---
$search  = trim($_GET['q'] ?? '');
$status  = $_GET['status'] ?? '';
$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset  = ($page - 1) * $perPage;

$where  = "WHERE 1=1";
$params = [];
if ($search) {
    $where  .= " AND (o.order_number LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?)";
    $params  = array_merge($params, ["%$search%","%$search%","%$search%"]);
}
if ($status) {
    $where  .= " AND o.status=?";
    $params[] = $status;
}

$countSQL = "SELECT COUNT(*) FROM orders o JOIN users u ON o.user_id=u.id $where";
$listSQL  = "SELECT o.*, u.full_name, u.email, u.phone FROM orders o JOIN users u ON o.user_id=u.id $where ORDER BY o.created_at DESC LIMIT $perPage OFFSET $offset";

$stmtC = $pdo->prepare($countSQL); $stmtC->execute($params);
$totalCount = $stmtC->fetchColumn();

$stmtL = $pdo->prepare($listSQL); $stmtL->execute($params);
$orders = $stmtL->fetchAll();

$totalPages = ceil($totalCount / $perPage);

// Summary
$summaryMap = ['pending'=>0,'confirmed'=>0,'shipping'=>0,'delivered'=>0,'cancelled'=>0];
$rows = $pdo->query("SELECT status, COUNT(*) as cnt FROM orders GROUP BY status")->fetchAll();
foreach ($rows as $r) { if (isset($summaryMap[$r['status']])) $summaryMap[$r['status']] = $r['cnt']; }
$totalRevenue = $pdo->query("SELECT COALESCE(SUM(final_price),0) FROM orders WHERE payment_status='paid'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .page-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; padding-bottom:16px; border-bottom:2px solid var(--border-color,#e8f0e9); }
        .page-header h1 { font-size:22px; font-weight:700; color:var(--green-deep,#2d5a27); margin:0; }
        .status-tabs { display:flex; gap:8px; margin-bottom:20px; flex-wrap:wrap; }
        .status-tab { padding:8px 18px; border-radius:20px; font-size:13px; font-weight:500; text-decoration:none; border:1px solid var(--border-color,#ddd); color:var(--text-dark,#333); white-space:nowrap; transition:.15s; }
        .status-tab:hover, .status-tab.active { color:#fff; }
        .status-tab.all.active     { background:#2d5a27; border-color:#2d5a27; }
        .status-tab.pending.active { background:#fb8c00; border-color:#fb8c00; }
        .status-tab.confirmed.active { background:#1e88e5; border-color:#1e88e5; }
        .status-tab.shipping.active  { background:#00897b; border-color:#00897b; }
        .status-tab.delivered.active { background:#43a047; border-color:#43a047; }
        .status-tab.cancelled.active { background:#e53935; border-color:#e53935; }
        .filters { display:flex; gap:10px; margin-bottom:20px; }
        .filters input { flex:1; padding:10px 16px; border:1px solid var(--border-color,#ddd); border-radius:10px; font-size:14px; }
        .table-wrapper { background:#fff; border-radius:16px; box-shadow:0 2px 12px rgba(0,0,0,.06); border:1px solid var(--border-color,#e8f0e9); overflow:hidden; }
        table { width:100%; border-collapse:collapse; }
        th { padding:10px 16px; font-size:12px; font-weight:600; text-transform:uppercase; letter-spacing:.5px; color:var(--text-light,#888); background:var(--green-light,#f8fdf7); border-bottom:1px solid var(--border-color,#e8f0e9); text-align:left; }
        td { padding:12px 16px; font-size:14px; border-bottom:1px solid #f5f5f5; vertical-align:middle; }
        tr:last-child td { border-bottom:none; }
        tr:hover td { background:#fafffe; }
        .mini-stats { display:grid; grid-template-columns:repeat(5,1fr); gap:12px; margin-bottom:24px; }
        .mini-stat { background:#fff; border-radius:12px; padding:14px 16px; box-shadow:0 2px 8px rgba(0,0,0,.05); border:1px solid var(--border-color,#e8f0e9); text-align:center; }
        .mini-stat .ms-num { font-size:20px; font-weight:700; }
        .mini-stat .ms-label { font-size:12px; color:var(--text-light,#888); margin-top:2px; }
        .pagination { display:flex; gap:6px; align-items:center; justify-content:center; margin-top:24px; flex-wrap:wrap; }
        .pagination a, .pagination span { padding:7px 14px; border-radius:8px; font-size:13px; font-weight:500; border:1px solid var(--border-color,#ddd); text-decoration:none; color:var(--text-dark,#333); }
        .pagination a:hover { background:var(--green-light,#f0f7ee); }
        .pagination .active { background:var(--green-deep,#2d5a27); color:#fff; border-color:var(--green-deep,#2d5a27); }
        .status-select { padding:5px 10px; border-radius:8px; border:1px solid #ddd; font-size:13px; cursor:pointer; }
        .modal-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:1000; align-items:center; justify-content:center; }
        .modal-overlay.open { display:flex; }
        .modal-box { background:#fff; border-radius:20px; padding:32px; width:500px; max-width:95vw; }
        .modal-box h2 { font-size:18px; font-weight:700; margin:0 0 20px; }
        .form-group { margin-bottom:14px; }
        .form-group label { display:block; font-size:13px; font-weight:600; margin-bottom:6px; }
        .form-group select { width:100%; padding:10px 14px; border:1px solid #ddd; border-radius:10px; font-size:14px; }
        .form-actions { display:flex; gap:10px; margin-top:20px; }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="admin-layout">
    <?php include '../partials/sidebar.php'; ?>

    <main class="admin-main">

        <div class="page-header">
            <h1><i class="fas fa-receipt" style="color:var(--green-sage,#7aa876);margin-right:8px"></i><?= $pageTitle ?></h1>
            <span style="font-weight:700;color:var(--green-deep,#2d5a27);font-size:16px">
                รายได้รวม: ฿<?= number_format($totalRevenue, 0) ?>
            </span>
        </div>

        <!-- Status Summary -->
        <div class="mini-stats">
            <div class="mini-stat">
                <div class="ms-num" style="color:#fb8c00"><?= number_format($summaryMap['pending']) ?></div>
                <div class="ms-label">รอดำเนินการ</div>
            </div>
            <div class="mini-stat">
                <div class="ms-num" style="color:#1e88e5"><?= number_format($summaryMap['confirmed']) ?></div>
                <div class="ms-label">ยืนยันแล้ว</div>
            </div>
            <div class="mini-stat">
                <div class="ms-num" style="color:#00897b"><?= number_format($summaryMap['shipping']) ?></div>
                <div class="ms-label">กำลังจัดส่ง</div>
            </div>
            <div class="mini-stat">
                <div class="ms-num" style="color:#43a047"><?= number_format($summaryMap['delivered']) ?></div>
                <div class="ms-label">ส่งแล้ว</div>
            </div>
            <div class="mini-stat">
                <div class="ms-num" style="color:#e53935"><?= number_format($summaryMap['cancelled']) ?></div>
                <div class="ms-label">ยกเลิก</div>
            </div>
        </div>

        <!-- Status Tabs -->
        <div class="status-tabs">
            <a href="orders.php" class="status-tab all <?= !$status ? 'active' : '' ?>">ทั้งหมด</a>
            <a href="?status=pending"   class="status-tab pending   <?= $status==='pending'   ? 'active' : '' ?>">⏳ รอดำเนินการ</a>
            <a href="?status=confirmed" class="status-tab confirmed <?= $status==='confirmed' ? 'active' : '' ?>">✅ ยืนยันแล้ว</a>
            <a href="?status=shipping"  class="status-tab shipping  <?= $status==='shipping'  ? 'active' : '' ?>">🚚 กำลังจัดส่ง</a>
            <a href="?status=delivered" class="status-tab delivered <?= $status==='delivered' ? 'active' : '' ?>">📦 ส่งแล้ว</a>
            <a href="?status=cancelled" class="status-tab cancelled <?= $status==='cancelled' ? 'active' : '' ?>">❌ ยกเลิก</a>
        </div>

        <!-- Search -->
        <form class="filters" method="GET">
            <?php if ($status): ?><input type="hidden" name="status" value="<?= $status ?>"><?php endif; ?>
            <input type="text" name="q" placeholder="ค้นหา เลขที่ออเดอร์ / ชื่อลูกค้า / อีเมล..." value="<?= sanitize($search) ?>">
            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            <?php if ($search): ?>
            <a href="orders.php<?= $status ? '?status='.$status : '' ?>" class="btn btn-outline">ล้าง</a>
            <?php endif; ?>
        </form>

        <!-- Table -->
        <div class="table-wrapper">
            <div style="display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--border-color,#e8f0e9);background:var(--green-light,#f8fdf7)">
                <span style="font-weight:700;font-size:15px">รายการออเดอร์
                    <span style="font-size:13px;color:var(--text-light,#888);font-weight:400;margin-left:8px">(<?= number_format($totalCount) ?> รายการ)</span>
                </span>
            </div>
            <table>
                <thead><tr>
                    <th>เลขที่</th>
                    <th>ลูกค้า</th>
                    <th>ยอดสั่งซื้อ</th>
                    <th>การชำระ</th>
                    <th>สถานะ</th>
                    <th>วันที่</th>
                    <th>อัปเดต</th>
                </tr></thead>
                <tbody>
                <?php
                $statusConfig = [
                    'pending'   => ['class'=>'badge-warning', 'label'=>'รอดำเนินการ', 'icon'=>'fa-hourglass-half'],
                    'confirmed' => ['class'=>'badge-info',    'label'=>'ยืนยันแล้ว',  'icon'=>'fa-check'],
                    'shipping'  => ['class'=>'badge-info',    'label'=>'กำลังจัดส่ง', 'icon'=>'fa-truck'],
                    'delivered' => ['class'=>'badge-success', 'label'=>'ส่งแล้ว',     'icon'=>'fa-check-double'],
                    'cancelled' => ['class'=>'badge-danger',  'label'=>'ยกเลิก',      'icon'=>'fa-times'],
                ];
                $paymentConfig = [
                    'paid'    => ['class'=>'badge-success','label'=>'ชำระแล้ว'],
                    'pending' => ['class'=>'badge-warning','label'=>'รอชำระ'],
                    'failed'  => ['class'=>'badge-danger', 'label'=>'ล้มเหลว'],
                ];
                foreach ($orders as $o):
                    $sc = $statusConfig[$o['status']] ?? ['class'=>'badge-info','label'=>$o['status'],'icon'=>'fa-circle'];
                    $pc = $paymentConfig[$o['payment_status']] ?? ['class'=>'badge-info','label'=>$o['payment_status']];
                ?>
                <tr>
                    <td>
                        <span style="font-size:12px;font-weight:600;color:var(--green-deep,#2d5a27)"><?= sanitize($o['order_number']) ?></span>
                    </td>
                    <td>
                        <div style="font-weight:500"><?= sanitize($o['full_name']) ?></div>
                        <div style="font-size:12px;color:var(--text-light,#888)"><?= sanitize($o['email']) ?></div>
                    </td>
                    <td style="font-weight:700;color:var(--green-deep,#2d5a27)">฿<?= number_format($o['final_price'], 0) ?></td>
                    <td><span class="badge <?= $pc['class'] ?>"><?= $pc['label'] ?></span></td>
                    <td>
                        <span class="badge <?= $sc['class'] ?>">
                            <i class="fas <?= $sc['icon'] ?>" style="margin-right:3px"></i>
                            <?= $sc['label'] ?>
                        </span>
                    </td>
                    <td style="font-size:12px;color:var(--text-light,#888)"><?= date('d/m/Y H:i', strtotime($o['created_at'])) ?></td>
                    <td>
                        <button class="btn btn-outline btn-sm" onclick="openStatusModal(<?= $o['id'] ?>, '<?= $o['status'] ?>', '<?= addslashes($o['order_number']) ?>')">
                            <i class="fas fa-edit"></i> เปลี่ยน
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($orders)): ?>
                <tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-light,#888)">
                    <i class="fas fa-receipt" style="font-size:32px;display:block;margin-bottom:10px;opacity:.4"></i>
                    ไม่พบรายการออเดอร์
                </td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?= $page-1 ?>&q=<?= urlencode($search) ?>&status=<?= $status ?>"><i class="fas fa-chevron-left"></i></a>
            <?php endif; ?>
            <?php for ($i = max(1,$page-2); $i <= min($totalPages,$page+2); $i++): ?>
                <?php if ($i === $page): ?>
                    <span class="active"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&status=<?= $status ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            <?php if ($page < $totalPages): ?>
                <a href="?page=<?= $page+1 ?>&q=<?= urlencode($search) ?>&status=<?= $status ?>"><i class="fas fa-chevron-right"></i></a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

    </main>
</div>

<!-- Status Update Modal -->
<div class="modal-overlay" id="statusModal" onclick="closeModalOutside(event)">
    <div class="modal-box">
        <h2>🔄 อัปเดตสถานะออเดอร์</h2>
        <p id="modalOrderNum" style="color:var(--text-light,#888);font-size:13px;margin-bottom:20px"></p>
        <form method="POST">
            <input type="hidden" name="update_status" value="1">
            <input type="hidden" name="order_id" id="modal_order_id">
            <div class="form-group">
                <label>สถานะใหม่</label>
                <select name="status" id="modal_status">
                    <option value="pending">⏳ รอดำเนินการ</option>
                    <option value="confirmed">✅ ยืนยันแล้ว</option>
                    <option value="shipping">🚚 กำลังจัดส่ง</option>
                    <option value="delivered">📦 ส่งแล้ว</option>
                    <option value="cancelled">❌ ยกเลิก</option>
                </select>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> บันทึก</button>
                <button type="button" class="btn btn-outline" onclick="closeModal()">ยกเลิก</button>
            </div>
        </form>
    </div>
</div>

<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>
function openStatusModal(id, currentStatus, orderNum) {
    document.getElementById('modal_order_id').value = id;
    document.getElementById('modal_status').value   = currentStatus;
    document.getElementById('modalOrderNum').textContent = 'เลขที่: ' + orderNum;
    document.getElementById('statusModal').classList.add('open');
}
function closeModal() { document.getElementById('statusModal').classList.remove('open'); }
function closeModalOutside(e) { if (e.target.id === 'statusModal') closeModal(); }
</script>
</body>
</html>
