<?php
define('INCLUDED', true);
require_once '../config.php';
requireAdmin();

$pdo = getDB();
$pageTitle = 'จัดการสินค้า';

// Handle actions
$action  = $_GET['action'] ?? 'list';
$msg     = '';
$msgType = 'success';

// --- DELETE ---
if ($action === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $pdo->prepare("UPDATE products SET is_active=0 WHERE id=?")->execute([$id]);
    $_SESSION['flash'] = ['message' => 'ลบสินค้าเรียบร้อยแล้ว', 'type' => 'success'];
    header('Location: products.php'); exit;
}

// --- SAVE (add / edit) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id          = (int)($_POST['id'] ?? 0);
    $name        = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price       = (float)($_POST['price'] ?? 0);
    $stock       = (int)($_POST['stock'] ?? 0);
    $unit        = trim($_POST['unit'] ?? 'ชิ้น');
    $category_id = (int)($_POST['category_id'] ?? 0) ?: null;

    if ($name === '') {
        $msg = 'กรุณากรอกชื่อสินค้า'; $msgType = 'danger';
    } else {
        // Handle image upload
        $imagePath = $_POST['existing_image'] ?? '';
        if (!empty($_FILES['image']['name'])) {
            $ext       = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $allowed   = ['jpg','jpeg','png','gif','webp'];
            if (in_array($ext, $allowed)) {
                $newName   = 'img/products/' . uniqid('prod_') . '.' . $ext;
                $uploadDir = dirname(__DIR__) . '/' . $newName;
                if (!is_dir(dirname($uploadDir))) mkdir(dirname($uploadDir), 0755, true);
                move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir);
                $imagePath = $newName;
            }
        }

        if ($id > 0) {
            $pdo->prepare("UPDATE products SET name=?,description=?,price=?,stock=?,unit=?,category_id=?,image=? WHERE id=?")
                ->execute([$name, $description, $price, $stock, $unit, $category_id, $imagePath, $id]);
            $_SESSION['flash'] = ['message' => 'แก้ไขสินค้าเรียบร้อยแล้ว', 'type' => 'success'];
        } else {
            $pdo->prepare("INSERT INTO products (name,description,price,stock,unit,category_id,image,is_active) VALUES (?,?,?,?,?,?,?,1)")
                ->execute([$name, $description, $price, $stock, $unit, $category_id, $imagePath]);
            $_SESSION['flash'] = ['message' => 'เพิ่มสินค้าเรียบร้อยแล้ว', 'type' => 'success'];
        }
        header('Location: products.php'); exit;
    }
}

// --- FETCH for edit ---
$editProduct = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $editProduct = $pdo->prepare("SELECT * FROM products WHERE id=?");
    $editProduct->execute([(int)$_GET['id']]);
    $editProduct = $editProduct->fetch();
}

// --- LIST ---
$search    = trim($_GET['q'] ?? '');
$page      = max(1, (int)($_GET['page'] ?? 1));
$perPage   = 15;
$offset    = ($page - 1) * $perPage;
$whereSQL  = $search ? "AND (name LIKE ? OR description LIKE ?)" : '';
$countSQL  = "SELECT COUNT(*) FROM products WHERE is_active=1 $whereSQL";
$listSQL   = "SELECT p.*, c.name AS cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.is_active=1 $whereSQL ORDER BY p.id DESC LIMIT $perPage OFFSET $offset";

if ($search) {
    $totalCount = $pdo->prepare($countSQL);
    $totalCount->execute(["%$search%", "%$search%"]);
    $totalCount = $totalCount->fetchColumn();
    $stmt = $pdo->prepare($listSQL);
    $stmt->execute(["%$search%", "%$search%"]);
} else {
    $totalCount = $pdo->query($countSQL)->fetchColumn();
    $stmt = $pdo->query($listSQL);
}
$products   = $stmt->fetchAll();
$totalPages = ceil($totalCount / $perPage);

// Categories for form
$categories = $pdo->query("SELECT id, name FROM categories ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .page-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; padding-bottom:16px; border-bottom:2px solid var(--border-color,#e8f0e9); }
        .page-header h1 { font-size:22px; font-weight:700; color:var(--green-deep,#2d5a27); margin:0; }
        .search-bar { display:flex; gap:10px; margin-bottom:20px; }
        .search-bar input { flex:1; padding:10px 16px; border:1px solid var(--border-color,#ddd); border-radius:10px; font-size:14px; }
        .search-bar button { padding:10px 20px; border-radius:10px; }
        .table-wrapper { background:#fff; border-radius:16px; box-shadow:0 2px 12px rgba(0,0,0,.06); border:1px solid var(--border-color,#e8f0e9); overflow:hidden; }
        .table-header { display:flex; align-items:center; justify-content:space-between; padding:16px 20px; border-bottom:1px solid var(--border-color,#e8f0e9); background:var(--green-light,#f8fdf7); }
        table { width:100%; border-collapse:collapse; }
        th { padding:10px 16px; font-size:12px; font-weight:600; text-transform:uppercase; letter-spacing:.5px; color:var(--text-light,#888); background:var(--green-light,#f8fdf7); border-bottom:1px solid var(--border-color,#e8f0e9); text-align:left; }
        td { padding:12px 16px; font-size:14px; border-bottom:1px solid #f5f5f5; vertical-align:middle; }
        tr:last-child td { border-bottom:none; }
        tr:hover td { background:#fafffe; }
        .product-img { width:44px; height:44px; border-radius:10px; object-fit:cover; border:1px solid #eee; }
        .product-name { font-weight:600; color:var(--text-dark,#1a1a1a); }
        .product-desc { font-size:12px; color:var(--text-light,#888); margin-top:2px; }
        .actions { display:flex; gap:6px; }
        .modal-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:1000; align-items:center; justify-content:center; }
        .modal-overlay.open { display:flex; }
        .modal-box { background:#fff; border-radius:20px; padding:32px; width:540px; max-width:95vw; max-height:90vh; overflow-y:auto; }
        .modal-box h2 { font-size:20px; font-weight:700; margin:0 0 24px; color:var(--green-deep,#2d5a27); }
        .form-group { margin-bottom:16px; }
        .form-group label { display:block; font-size:13px; font-weight:600; color:var(--text-dark,#333); margin-bottom:6px; }
        .form-group input, .form-group textarea, .form-group select { width:100%; padding:10px 14px; border:1px solid var(--border-color,#ddd); border-radius:10px; font-size:14px; box-sizing:border-box; }
        .form-group textarea { resize:vertical; min-height:80px; }
        .form-row { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
        .form-actions { display:flex; gap:10px; margin-top:24px; }
        .pagination { display:flex; gap:6px; align-items:center; justify-content:center; margin-top:24px; flex-wrap:wrap; }
        .pagination a, .pagination span { padding:7px 14px; border-radius:8px; font-size:13px; font-weight:500; border:1px solid var(--border-color,#ddd); text-decoration:none; color:var(--text-dark,#333); }
        .pagination a:hover { background:var(--green-light,#f0f7ee); }
        .pagination .active { background:var(--green-deep,#2d5a27); color:#fff; border-color:var(--green-deep,#2d5a27); }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="admin-layout">
    <?php include '../partials/sidebar.php'; ?>

    <main class="admin-main">

        <?php if ($msg): ?>
        <div class="alert alert-<?= $msgType ?>" style="margin-bottom:16px;padding:12px 18px;border-radius:10px">
            <?= $msg ?>
        </div>
        <?php endif; ?>

        <div class="page-header">
            <h1><i class="fas fa-box-open" style="color:var(--green-sage,#7aa876);margin-right:8px"></i><?= $pageTitle ?></h1>
            <button class="btn btn-primary" onclick="openModal()">
                <i class="fas fa-plus"></i> เพิ่มสินค้าใหม่
            </button>
        </div>

        <!-- Search -->
        <form class="search-bar" method="GET">
            <input type="text" name="q" placeholder="ค้นหาสินค้า..." value="<?= sanitize($search) ?>">
            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            <?php if ($search): ?>
            <a href="products.php" class="btn btn-outline">ล้าง</a>
            <?php endif; ?>
        </form>

        <!-- Table -->
        <div class="table-wrapper">
            <div class="table-header">
                <span style="font-weight:700;font-size:15px">รายการสินค้าทั้งหมด
                    <span style="font-size:13px;color:var(--text-light,#888);font-weight:400;margin-left:8px">(<?= number_format($totalCount) ?> รายการ)</span>
                </span>
            </div>
            <table>
                <thead><tr>
                    <th>สินค้า</th>
                    <th>หมวดหมู่</th>
                    <th>ราคา</th>
                    <th>สต็อก</th>
                    <th>จัดการ</th>
                </tr></thead>
                <tbody>
                <?php foreach ($products as $p): ?>
                <tr>
                    <td>
                        <div style="display:flex;align-items:center;gap:12px">
                            <img src="<?= SITE_URL ?>/<?= $p['image'] ?: 'img/no-image.png' ?>" class="product-img" alt="" onerror="this.src='<?= SITE_URL ?>/img/no-image.png'">
                            <div>
                                <div class="product-name"><?= sanitize($p['name']) ?></div>
                                <div class="product-desc"><?= mb_substr(sanitize($p['description'] ?? ''), 0, 50) ?></div>
                            </div>
                        </div>
                    </td>
                    <td><span style="font-size:13px;color:var(--text-light,#888)"><?= sanitize($p['cat_name'] ?? '-') ?></span></td>
                    <td style="font-weight:700;color:var(--green-deep,#2d5a27)">฿<?= number_format($p['price'], 2) ?></td>
                    <td>
                        <?php if ($p['stock'] <= 5): ?>
                            <span class="badge badge-danger"><?= $p['stock'] ?> <?= $p['unit'] ?></span>
                        <?php elseif ($p['stock'] <= 20): ?>
                            <span class="badge badge-warning"><?= $p['stock'] ?> <?= $p['unit'] ?></span>
                        <?php else: ?>
                            <span class="badge badge-success"><?= $p['stock'] ?> <?= $p['unit'] ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="actions">
                            <button class="btn btn-outline btn-sm" onclick='openModal(<?= json_encode($p) ?>)'>
                                <i class="fas fa-edit"></i>
                            </button>
                            <a href="products.php?action=delete&id=<?= $p['id'] ?>" class="btn btn-sm" style="background:#ffebee;color:#c62828;border:1px solid #ef9a9a"
                               onclick="return confirm('ยืนยันการลบสินค้า: <?= addslashes($p['name']) ?>?')">
                                <i class="fas fa-trash"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($products)): ?>
                <tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-light,#888)">
                    <i class="fas fa-box-open" style="font-size:32px;display:block;margin-bottom:10px;opacity:.4"></i>
                    <?= $search ? 'ไม่พบสินค้าที่ค้นหา' : 'ยังไม่มีสินค้า' ?>
                </td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?= $page-1 ?>&q=<?= urlencode($search) ?>"><i class="fas fa-chevron-left"></i></a>
            <?php endif; ?>
            <?php for ($i = max(1,$page-2); $i <= min($totalPages,$page+2); $i++): ?>
                <?php if ($i === $page): ?>
                    <span class="active"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            <?php if ($page < $totalPages): ?>
                <a href="?page=<?= $page+1 ?>&q=<?= urlencode($search) ?>"><i class="fas fa-chevron-right"></i></a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

    </main>
</div>

<!-- Modal -->
<div class="modal-overlay" id="modalOverlay" onclick="closeModalOutside(event)">
    <div class="modal-box">
        <h2 id="modalTitle">เพิ่มสินค้าใหม่</h2>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" id="field_id">
            <input type="hidden" name="existing_image" id="field_image">

            <div class="form-group">
                <label>ชื่อสินค้า *</label>
                <input type="text" name="name" id="field_name" required placeholder="ชื่อสินค้า">
            </div>
            <div class="form-group">
                <label>รายละเอียด</label>
                <textarea name="description" id="field_description" placeholder="รายละเอียดสินค้า"></textarea>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>ราคา (บาท) *</label>
                    <input type="number" name="price" id="field_price" min="0" step="0.01" required placeholder="0.00">
                </div>
                <div class="form-group">
                    <label>หมวดหมู่</label>
                    <select name="category_id" id="field_category_id">
                        <option value="">-- ไม่ระบุ --</option>
                        <?php foreach ($categories as $c): ?>
                        <option value="<?= $c['id'] ?>"><?= sanitize($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>จำนวนสต็อก</label>
                    <input type="number" name="stock" id="field_stock" min="0" value="0">
                </div>
                <div class="form-group">
                    <label>หน่วย</label>
                    <input type="text" name="unit" id="field_unit" value="ชิ้น" placeholder="เช่น ชิ้น, กก., ขวด">
                </div>
            </div>
            <div class="form-group">
                <label>รูปภาพสินค้า</label>
                <input type="file" name="image" accept="image/*">
                <div id="currentImagePreview" style="margin-top:8px;display:none">
                    <img id="previewImg" style="height:60px;border-radius:8px;border:1px solid #eee">
                    <span style="font-size:12px;color:var(--text-light);margin-left:8px">รูปปัจจุบัน</span>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> บันทึก</button>
                <button type="button" class="btn btn-outline" onclick="closeModal()">ยกเลิก</button>
            </div>
        </form>
    </div>
</div>

<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>
function openModal(product) {
    const overlay = document.getElementById('modalOverlay');
    overlay.classList.add('open');
    if (product) {
        document.getElementById('modalTitle').textContent = 'แก้ไขสินค้า';
        document.getElementById('field_id').value          = product.id;
        document.getElementById('field_name').value        = product.name;
        document.getElementById('field_description').value = product.description || '';
        document.getElementById('field_price').value       = product.price;
        document.getElementById('field_stock').value       = product.stock;
        document.getElementById('field_unit').value        = product.unit;
        document.getElementById('field_category_id').value = product.category_id || '';
        document.getElementById('field_image').value       = product.image || '';
        if (product.image) {
            document.getElementById('previewImg').src = '<?= SITE_URL ?>/' + product.image;
            document.getElementById('currentImagePreview').style.display = 'block';
        }
    } else {
        document.getElementById('modalTitle').textContent = 'เพิ่มสินค้าใหม่';
        document.getElementById('field_id').value          = '';
        document.getElementById('field_name').value        = '';
        document.getElementById('field_description').value = '';
        document.getElementById('field_price').value       = '';
        document.getElementById('field_stock').value       = '0';
        document.getElementById('field_unit').value        = 'ชิ้น';
        document.getElementById('field_category_id').value = '';
        document.getElementById('field_image').value       = '';
        document.getElementById('currentImagePreview').style.display = 'none';
    }
}
function closeModal() { document.getElementById('modalOverlay').classList.remove('open'); }
function closeModalOutside(e) { if (e.target === document.getElementById('modalOverlay')) closeModal(); }
</script>
</body>
</html>
