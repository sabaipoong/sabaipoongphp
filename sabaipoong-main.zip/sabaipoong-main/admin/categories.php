<?php
define('INCLUDED', true);
require_once '../config.php';
requireAdmin();

$pdo = getDB();
$pageTitle = 'จัดการหมวดหมู่';

// --- DELETE ---
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    // Check if category has products
    $productCount = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id=? AND is_active=1");
    $productCount->execute([$id]);
    $productCount = $productCount->fetchColumn();

    if ($productCount > 0) {
        $_SESSION['flash'] = ['message' => "ไม่สามารถลบได้ มีสินค้าอยู่ในหมวดหมู่นี้ {$productCount} รายการ", 'type' => 'danger'];
    } else {
        $pdo->prepare("DELETE FROM categories WHERE id=?")->execute([$id]);
        $_SESSION['flash'] = ['message' => 'ลบหมวดหมู่เรียบร้อยแล้ว', 'type' => 'success'];
    }
    header('Location: categories.php'); exit;
}

// --- SAVE (add / edit) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id          = (int)($_POST['id'] ?? 0);
    $name        = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $slug        = trim($_POST['slug'] ?? '');

    if ($name === '') {
        $_SESSION['flash'] = ['message' => 'กรุณากรอกชื่อหมวดหมู่', 'type' => 'danger'];
        header('Location: categories.php'); exit;
    }

    // Auto-generate slug if empty
    if ($slug === '') {
        $slug = strtolower(preg_replace('/[^a-zA-Z0-9]+/', '-', $name));
        $slug = trim($slug, '-');
    }

    // Handle image upload
    $imagePath = $_POST['existing_image'] ?? '';
    if (!empty($_FILES['image']['name'])) {
        $ext     = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','gif','webp'];
        if (in_array($ext, $allowed)) {
            $newName   = 'img/categories/' . uniqid('cat_') . '.' . $ext;
            $uploadDir = dirname(__DIR__) . '/' . $newName;
            if (!is_dir(dirname($uploadDir))) mkdir(dirname($uploadDir), 0755, true);
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir);
            $imagePath = $newName;
        }
    }

    // Check duplicate slug
    $dupStmt = $pdo->prepare("SELECT id FROM categories WHERE slug=? AND id!=?");
    $dupStmt->execute([$slug, $id]);
    if ($dupStmt->fetch()) {
        $slug .= '-' . time();
    }

    if ($id > 0) {
        $pdo->prepare("UPDATE categories SET name=?, description=?, slug=?, image=? WHERE id=?")
            ->execute([$name, $description, $slug, $imagePath, $id]);
        $_SESSION['flash'] = ['message' => 'แก้ไขหมวดหมู่เรียบร้อยแล้ว', 'type' => 'success'];
    } else {
        $pdo->prepare("INSERT INTO categories (name, description, slug, image) VALUES (?,?,?,?)")
            ->execute([$name, $description, $slug, $imagePath]);
        $_SESSION['flash'] = ['message' => 'เพิ่มหมวดหมู่เรียบร้อยแล้ว', 'type' => 'success'];
    }
    header('Location: categories.php'); exit;
}

// --- LIST with product count ---
$search   = trim($_GET['q'] ?? '');
$where    = $search ? "WHERE c.name LIKE ?" : '';
$params   = $search ? ["%$search%"] : [];

$countSQL = "SELECT COUNT(*) FROM categories c $where";
$listSQL  = "SELECT c.*, COUNT(p.id) AS product_count
             FROM categories c
             LEFT JOIN products p ON p.category_id = c.id AND p.is_active=1
             $where
             GROUP BY c.id
             ORDER BY c.id DESC";

$stmtC = $pdo->prepare($countSQL); $stmtC->execute($params);
$totalCount = $stmtC->fetchColumn();

$stmtL = $pdo->prepare($listSQL); $stmtL->execute($params);
$categories = $stmtL->fetchAll();

// Summary
$totalCats     = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
$catsWithItems = $pdo->query("SELECT COUNT(DISTINCT category_id) FROM products WHERE is_active=1 AND category_id IS NOT NULL")->fetchColumn();
$emptyCats     = $totalCats - $catsWithItems;
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        /* ===== Page Layout ===== */
        .page-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 2px solid var(--border-color, #e8f0e9);
        }
        .page-header h1 {
            font-size: 22px;
            font-weight: 700;
            color: var(--green-deep, #2d5a27);
            margin: 0;
        }

        /* ===== Mini Stats ===== */
        .mini-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }
        .mini-stat {
            background: #fff;
            border-radius: 14px;
            padding: 18px 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,.05);
            border: 1px solid var(--border-color, #e8f0e9);
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .ms-icon {
            width: 46px; height: 46px;
            border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }
        .mini-stat h4 { font-size: 24px; font-weight: 700; margin: 0; }
        .mini-stat p  { font-size: 13px; color: var(--text-light, #888); margin: 0; }

        /* ===== Search Bar ===== */
        .search-bar {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        .search-bar input {
            flex: 1;
            padding: 10px 16px;
            border: 1px solid var(--border-color, #ddd);
            border-radius: 10px;
            font-size: 14px;
        }

        /* ===== Category Grid ===== */
        .cat-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 18px;
        }

        .cat-card {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 2px 10px rgba(0,0,0,.06);
            border: 1px solid var(--border-color, #e8f0e9);
            overflow: hidden;
            transition: transform .2s, box-shadow .2s;
        }
        .cat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 24px rgba(0,0,0,.1);
        }

        .cat-card-img {
            width: 100%;
            height: 120px;
            object-fit: cover;
            background: var(--green-light, #f0f7ee);
            display: block;
        }
        .cat-card-img-placeholder {
            width: 100%;
            height: 120px;
            background: linear-gradient(135deg, #e8f5e9, #c8e6c9);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            color: #81c784;
        }

        .cat-card-body {
            padding: 14px 16px;
        }
        .cat-card-name {
            font-size: 15px;
            font-weight: 700;
            color: var(--text-dark, #1a1a1a);
            margin-bottom: 4px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .cat-card-slug {
            font-size: 11px;
            color: var(--text-light, #aaa);
            font-family: monospace;
            margin-bottom: 8px;
        }
        .cat-card-desc {
            font-size: 12px;
            color: var(--text-light, #888);
            line-height: 1.5;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            min-height: 36px;
            margin-bottom: 12px;
        }
        .cat-card-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-top: 10px;
            border-top: 1px solid #f0f0f0;
        }
        .cat-product-count {
            font-size: 12px;
            color: var(--green-deep, #2d5a27);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .cat-actions {
            display: flex;
            gap: 6px;
        }

        /* ===== Empty State ===== */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-light, #aaa);
            grid-column: 1 / -1;
        }
        .empty-state i {
            font-size: 48px;
            display: block;
            margin-bottom: 12px;
            opacity: .35;
        }
        .empty-state p { font-size: 15px; margin: 0; }

        /* ===== Modal ===== */
        .modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        .modal-overlay.open { display: flex; }
        .modal-box {
            background: #fff;
            border-radius: 20px;
            padding: 32px;
            width: 500px;
            max-width: 95vw;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-box h2 {
            font-size: 20px;
            font-weight: 700;
            margin: 0 0 24px;
            color: var(--green-deep, #2d5a27);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .form-group { margin-bottom: 16px; }
        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: var(--text-dark, #333);
            margin-bottom: 6px;
        }
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid var(--border-color, #ddd);
            border-radius: 10px;
            font-size: 14px;
            box-sizing: border-box;
            transition: border-color .15s;
        }
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--green-sage, #7aa876);
        }
        .form-group textarea { resize: vertical; min-height: 80px; }
        .form-hint { font-size: 11px; color: var(--text-light, #aaa); margin-top: 4px; }
        .form-actions {
            display: flex;
            gap: 10px;
            margin-top: 24px;
        }
        .img-preview {
            margin-top: 10px;
            display: none;
        }
        .img-preview img {
            height: 64px;
            border-radius: 10px;
            border: 1px solid #eee;
            object-fit: cover;
        }
        .img-preview span {
            font-size: 12px;
            color: var(--text-light);
            margin-left: 8px;
            vertical-align: middle;
        }

        @media (max-width: 640px) {
            .mini-stats { grid-template-columns: 1fr; }
            .cat-grid   { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="admin-layout">
    <?php include '../partials/sidebar.php'; ?>

    <main class="admin-main">

        <!-- Page Header -->
        <div class="page-header">
            <h1>
                <i class="fas fa-tags" style="color:var(--green-sage,#7aa876);margin-right:8px"></i>
                <?= $pageTitle ?>
            </h1>
            <button class="btn btn-primary" onclick="openModal()">
                <i class="fas fa-plus"></i> เพิ่มหมวดหมู่
            </button>
        </div>

        <!-- Mini Stats -->
        <div class="mini-stats">
            <div class="mini-stat">
                <div class="ms-icon" style="background:#e8f5e9">
                    <i class="fas fa-tags" style="color:#43a047"></i>
                </div>
                <div>
                    <h4><?= number_format($totalCats) ?></h4>
                    <p>หมวดหมู่ทั้งหมด</p>
                </div>
            </div>
            <div class="mini-stat">
                <div class="ms-icon" style="background:#e3f2fd">
                    <i class="fas fa-box-open" style="color:#1e88e5"></i>
                </div>
                <div>
                    <h4><?= number_format($catsWithItems) ?></h4>
                    <p>มีสินค้าอยู่</p>
                </div>
            </div>
            <div class="mini-stat">
                <div class="ms-icon" style="background:#fff3e0">
                    <i class="fas fa-folder-open" style="color:#fb8c00"></i>
                </div>
                <div>
                    <h4><?= number_format($emptyCats) ?></h4>
                    <p>ยังไม่มีสินค้า</p>
                </div>
            </div>
        </div>

        <!-- Search -->
        <form class="search-bar" method="GET">
            <input type="text" name="q" placeholder="ค้นหาหมวดหมู่..." value="<?= sanitize($search) ?>">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-search"></i>
            </button>
            <?php if ($search): ?>
                <a href="categories.php" class="btn btn-outline">ล้าง</a>
            <?php endif; ?>
        </form>

        <!-- Category Grid -->
        <?php if (empty($categories)): ?>
        <div class="cat-grid">
            <div class="empty-state">
                <i class="fas fa-tags"></i>
                <p><?= $search ? 'ไม่พบหมวดหมู่ที่ค้นหา' : 'ยังไม่มีหมวดหมู่ กดปุ่ม "เพิ่มหมวดหมู่" เพื่อเริ่มต้น' ?></p>
            </div>
        </div>
        <?php else: ?>
        <div class="cat-grid">
            <?php foreach ($categories as $c): ?>
            <div class="cat-card">

                <?php if (!empty($c['image']) && file_exists(dirname(__DIR__).'/'.$c['image'])): ?>
                    <img src="<?= SITE_URL ?>/<?= sanitize($c['image']) ?>"
                         class="cat-card-img"
                         alt="<?= sanitize($c['name']) ?>"
                         onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                    <div class="cat-card-img-placeholder" style="display:none">🏷️</div>
                <?php else: ?>
                    <div class="cat-card-img-placeholder">🏷️</div>
                <?php endif; ?>

                <div class="cat-card-body">
                    <div class="cat-card-name"><?= sanitize($c['name']) ?></div>
                    <div class="cat-card-slug">/<?= sanitize($c['slug'] ?? '') ?></div>
                    <div class="cat-card-desc">
                        <?= $c['description'] ? sanitize($c['description']) : '<span style="color:#bbb;font-style:italic">ไม่มีคำอธิบาย</span>' ?>
                    </div>
                    <div class="cat-card-footer">
                        <span class="cat-product-count">
                            <i class="fas fa-box"></i>
                            <?= number_format($c['product_count']) ?> สินค้า
                        </span>
                        <div class="cat-actions">
                            <button class="btn btn-outline btn-sm"
                                    onclick='openModal(<?= json_encode($c) ?>)'
                                    title="แก้ไข">
                                <i class="fas fa-edit"></i>
                            </button>
                            <a href="categories.php?action=delete&id=<?= $c['id'] ?>"
                               class="btn btn-sm"
                               style="background:#ffebee;color:#c62828;border:1px solid #ef9a9a"
                               title="ลบ"
                               onclick="return confirm('ยืนยันการลบหมวดหมู่: <?= addslashes($c['name']) ?>?')">
                                <i class="fas fa-trash"></i>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

    </main>
</div>

<!-- Add / Edit Modal -->
<div class="modal-overlay" id="modalOverlay" onclick="closeModalOutside(event)">
    <div class="modal-box">
        <h2>
            <span id="modalIcon">➕</span>
            <span id="modalTitle">เพิ่มหมวดหมู่ใหม่</span>
        </h2>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id"             id="field_id">
            <input type="hidden" name="existing_image" id="field_image">

            <div class="form-group">
                <label>ชื่อหมวดหมู่ <span style="color:#e53935">*</span></label>
                <input type="text" name="name" id="field_name"
                       required placeholder="เช่น ผักสด, ผลไม้, สมุนไพร"
                       oninput="autoSlug(this.value)">
            </div>

            <div class="form-group">
                <label>Slug (URL)</label>
                <input type="text" name="slug" id="field_slug"
                       placeholder="เช่น fresh-vegetables (ภาษาอังกฤษ)">
                <div class="form-hint">ระบบจะสร้างอัตโนมัติหากเว้นว่างไว้</div>
            </div>

            <div class="form-group">
                <label>คำอธิบาย</label>
                <textarea name="description" id="field_description"
                          placeholder="อธิบายหมวดหมู่นี้โดยย่อ..."></textarea>
            </div>

            <div class="form-group">
                <label>รูปภาพหมวดหมู่</label>
                <input type="file" name="image" id="field_file" accept="image/*"
                       onchange="previewImage(this)">
                <div class="img-preview" id="imgPreview">
                    <img id="previewImg" src="" alt="preview">
                    <span id="previewLabel">รูปปัจจุบัน</span>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> บันทึก
                </button>
                <button type="button" class="btn btn-outline" onclick="closeModal()">
                    ยกเลิก
                </button>
            </div>
        </form>
    </div>
</div>

<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>
// ===== Modal =====
function openModal(cat) {
    document.getElementById('modalOverlay').classList.add('open');

    if (cat) {
        document.getElementById('modalIcon').textContent     = '✏️';
        document.getElementById('modalTitle').textContent    = 'แก้ไขหมวดหมู่';
        document.getElementById('field_id').value            = cat.id;
        document.getElementById('field_name').value          = cat.name;
        document.getElementById('field_slug').value          = cat.slug || '';
        document.getElementById('field_description').value   = cat.description || '';
        document.getElementById('field_image').value         = cat.image || '';

        if (cat.image) {
            document.getElementById('previewImg').src        = '<?= SITE_URL ?>/' + cat.image;
            document.getElementById('previewLabel').textContent = 'รูปปัจจุบัน';
            document.getElementById('imgPreview').style.display = 'block';
        } else {
            document.getElementById('imgPreview').style.display = 'none';
        }
    } else {
        document.getElementById('modalIcon').textContent     = '➕';
        document.getElementById('modalTitle').textContent    = 'เพิ่มหมวดหมู่ใหม่';
        document.getElementById('field_id').value            = '';
        document.getElementById('field_name').value          = '';
        document.getElementById('field_slug').value          = '';
        document.getElementById('field_description').value   = '';
        document.getElementById('field_image').value         = '';
        document.getElementById('imgPreview').style.display  = 'none';
        document.getElementById('field_file').value          = '';
    }
}

function closeModal() {
    document.getElementById('modalOverlay').classList.remove('open');
}

function closeModalOutside(e) {
    if (e.target === document.getElementById('modalOverlay')) closeModal();
}

// ===== Auto Slug =====
let slugManuallyEdited = false;

document.getElementById('field_slug').addEventListener('input', function () {
    slugManuallyEdited = this.value.trim() !== '';
});

function autoSlug(val) {
    if (slugManuallyEdited) return;
    const slug = val
        .toLowerCase()
        .replace(/[^a-z0-9\u0E00-\u0E7F\s-]/g, '')
        .trim()
        .replace(/\s+/g, '-');
    document.getElementById('field_slug').value = slug;
}

// Reset slug edit flag when modal opens fresh
function resetSlugFlag() { slugManuallyEdited = false; }
document.querySelector('button[onclick="openModal()"]')
    ?.addEventListener('click', resetSlugFlag);

// ===== Image Preview =====
function previewImage(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function (e) {
            document.getElementById('previewImg').src           = e.target.result;
            document.getElementById('previewLabel').textContent = 'รูปใหม่ที่เลือก';
            document.getElementById('imgPreview').style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>
</body>
</html>
