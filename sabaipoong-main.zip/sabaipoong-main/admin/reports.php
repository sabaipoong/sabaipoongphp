<?php
define('INCLUDED', true);
require_once '../config.php';
requireAdmin();

$pdo = getDB();
$pageTitle = 'รายงานยอดขาย';

// --- Date Range Filter ---
$rangePreset = $_GET['range'] ?? '30';
$dateFrom    = $_GET['from'] ?? '';
$dateTo      = $_GET['to']   ?? '';

if ($dateFrom === '' || $dateTo === '') {
    $dateTo   = date('Y-m-d');
    $dateFrom = match($rangePreset) {
        '7'     => date('Y-m-d', strtotime('-7 days')),
        '30'    => date('Y-m-d', strtotime('-30 days')),
        '90'    => date('Y-m-d', strtotime('-90 days')),
        '365'   => date('Y-m-d', strtotime('-365 days')),
        default => date('Y-m-d', strtotime('-30 days')),
    };
}

// ===== KPI Summary =====
$kpi = $pdo->prepare("
    SELECT
        COUNT(*)                                    AS total_orders,
        COALESCE(SUM(final_price), 0)               AS total_revenue,
        COALESCE(AVG(final_price), 0)               AS avg_order,
        COUNT(CASE WHEN status='cancelled' THEN 1 END) AS cancelled,
        COUNT(CASE WHEN payment_status='paid' THEN 1 END) AS paid_orders
    FROM orders
    WHERE DATE(created_at) BETWEEN ? AND ?
");
$kpi->execute([$dateFrom, $dateTo]);
$kpi = $kpi->fetch();

// Previous period for comparison
$daysDiff  = (strtotime($dateTo) - strtotime($dateFrom)) / 86400;
$prevFrom  = date('Y-m-d', strtotime($dateFrom) - ($daysDiff + 1) * 86400);
$prevTo    = date('Y-m-d', strtotime($dateFrom) - 86400);

$prevKpi = $pdo->prepare("
    SELECT COALESCE(SUM(final_price),0) AS total_revenue, COUNT(*) AS total_orders
    FROM orders WHERE DATE(created_at) BETWEEN ? AND ?
");
$prevKpi->execute([$prevFrom, $prevTo]);
$prevKpi = $prevKpi->fetch();

$revenueChange = $prevKpi['total_revenue'] > 0
    ? (($kpi['total_revenue'] - $prevKpi['total_revenue']) / $prevKpi['total_revenue']) * 100
    : 0;
$ordersChange = $prevKpi['total_orders'] > 0
    ? (($kpi['total_orders'] - $prevKpi['total_orders']) / $prevKpi['total_orders']) * 100
    : 0;

// ===== Daily Revenue Chart Data =====
$dailyStmt = $pdo->prepare("
    SELECT DATE(created_at) AS day,
           COALESCE(SUM(final_price),0) AS revenue,
           COUNT(*) AS orders
    FROM orders
    WHERE DATE(created_at) BETWEEN ? AND ?
    GROUP BY DATE(created_at)
    ORDER BY day ASC
");
$dailyStmt->execute([$dateFrom, $dateTo]);
$dailyData = $dailyStmt->fetchAll();

$chartLabels  = [];
$chartRevenue = [];
$chartOrders  = [];

// Fill all days in range (including 0-value days)
$currentDay = strtotime($dateFrom);
$endDay     = strtotime($dateTo);
$dailyMap   = [];
foreach ($dailyData as $d) $dailyMap[$d['day']] = $d;

while ($currentDay <= $endDay) {
    $dayStr          = date('Y-m-d', $currentDay);
    $chartLabels[]   = date('d/m', $currentDay);
    $chartRevenue[]  = (float)($dailyMap[$dayStr]['revenue'] ?? 0);
    $chartOrders[]   = (int)($dailyMap[$dayStr]['orders'] ?? 0);
    $currentDay     += 86400;
}

// ===== Top Products =====
$topProducts = $pdo->prepare("
    SELECT p.name, p.image,
           SUM(oi.quantity) AS total_qty,
           SUM(oi.quantity * oi.price) AS total_revenue
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    JOIN orders o ON oi.order_id = o.id
    WHERE DATE(o.created_at) BETWEEN ? AND ?
      AND o.status != 'cancelled'
    GROUP BY oi.product_id
    ORDER BY total_revenue DESC
    LIMIT 8
");
$topProducts->execute([$dateFrom, $dateTo]);
$topProducts = $topProducts->fetchAll();

// ===== Order Status Breakdown =====
$statusBreakdown = $pdo->prepare("
    SELECT status, COUNT(*) AS cnt
    FROM orders
    WHERE DATE(created_at) BETWEEN ? AND ?
    GROUP BY status
");
$statusBreakdown->execute([$dateFrom, $dateTo]);
$statusData = [];
foreach ($statusBreakdown->fetchAll() as $r) $statusData[$r['status']] = $r['cnt'];

// ===== Recent Paid Orders =====
$recentPaid = $pdo->prepare("
    SELECT o.order_number, o.final_price, o.created_at, u.full_name
    FROM orders o
    JOIN users u ON o.user_id = u.id
    WHERE o.payment_status = 'paid'
      AND DATE(o.created_at) BETWEEN ? AND ?
    ORDER BY o.created_at DESC
    LIMIT 10
");
$recentPaid->execute([$dateFrom, $dateTo]);
$recentPaid = $recentPaid->fetchAll();

// ===== New Members in range =====
$newMembers = $pdo->prepare("SELECT COUNT(*) FROM users WHERE DATE(created_at) BETWEEN ? AND ?");
$newMembers->execute([$dateFrom, $dateTo]);
$newMembers = $newMembers->fetchColumn();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
    <style>
        .page-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; padding-bottom:16px; border-bottom:2px solid var(--border-color,#e8f0e9); flex-wrap:wrap; gap:12px; }
        .page-header h1 { font-size:22px; font-weight:700; color:var(--green-deep,#2d5a27); margin:0; }

        /* Date filter */
        .date-filter { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
        .range-btns  { display:flex; gap:6px; }
        .range-btn   { padding:7px 14px; border-radius:20px; font-size:13px; font-weight:500; text-decoration:none; border:1px solid var(--border-color,#ddd); color:var(--text-dark,#333); white-space:nowrap; transition:.15s; cursor:pointer; background:#fff; }
        .range-btn:hover, .range-btn.active { background:var(--green-deep,#2d5a27); color:#fff; border-color:var(--green-deep,#2d5a27); }
        .date-inputs { display:flex; align-items:center; gap:8px; }
        .date-inputs input { padding:7px 12px; border:1px solid var(--border-color,#ddd); border-radius:8px; font-size:13px; }

        /* KPI Grid */
        .kpi-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:16px; margin-bottom:24px; }
        .kpi-card  { background:#fff; border-radius:16px; padding:20px; box-shadow:0 2px 10px rgba(0,0,0,.06); border:1px solid var(--border-color,#e8f0e9); position:relative; overflow:hidden; }
        .kpi-card::before { content:''; position:absolute; top:0; left:0; right:0; height:3px; border-radius:16px 16px 0 0; }
        .kpi-card.green::before  { background:linear-gradient(90deg,#4caf50,#81c784); }
        .kpi-card.blue::before   { background:linear-gradient(90deg,#2196f3,#64b5f6); }
        .kpi-card.orange::before { background:linear-gradient(90deg,#ff9800,#ffb74d); }
        .kpi-card.purple::before { background:linear-gradient(90deg,#9c27b0,#ce93d8); }
        .kpi-icon { width:44px; height:44px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:18px; margin-bottom:12px; }
        .kpi-num  { font-size:26px; font-weight:700; color:var(--text-dark,#1a1a1a); line-height:1; }
        .kpi-label { font-size:13px; color:var(--text-light,#888); margin-top:4px; }
        .kpi-change { font-size:12px; font-weight:600; margin-top:8px; display:flex; align-items:center; gap:4px; }
        .kpi-change.up   { color:#43a047; }
        .kpi-change.down { color:#e53935; }
        .kpi-change.flat { color:#888; }

        /* Charts */
        .charts-row { display:grid; grid-template-columns:1fr 340px; gap:20px; margin-bottom:24px; }
        .chart-card  { background:#fff; border-radius:16px; padding:22px; box-shadow:0 2px 10px rgba(0,0,0,.06); border:1px solid var(--border-color,#e8f0e9); }
        .chart-title { font-size:15px; font-weight:700; color:var(--text-dark,#1a1a1a); margin-bottom:16px; }

        /* Status Donut Legend */
        .donut-legend { display:flex; flex-direction:column; gap:8px; margin-top:16px; }
        .legend-item  { display:flex; align-items:center; justify-content:space-between; font-size:13px; }
        .legend-dot   { width:10px; height:10px; border-radius:50%; flex-shrink:0; margin-right:8px; display:inline-block; }

        /* Bottom Grid */
        .bottom-grid { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
        .section-card { background:#fff; border-radius:16px; box-shadow:0 2px 10px rgba(0,0,0,.06); border:1px solid var(--border-color,#e8f0e9); overflow:hidden; }
        .section-header { display:flex; align-items:center; justify-content:space-between; padding:16px 20px; border-bottom:1px solid var(--border-color,#e8f0e9); background:var(--green-light,#f8fdf7); }
        .section-title  { font-weight:700; font-size:15px; }

        table { width:100%; border-collapse:collapse; }
        th { padding:10px 16px; font-size:12px; font-weight:600; text-transform:uppercase; letter-spacing:.5px; color:var(--text-light,#888); background:var(--green-light,#f8fdf7); border-bottom:1px solid var(--border-color,#e8f0e9); text-align:left; }
        td { padding:11px 16px; font-size:13px; border-bottom:1px solid #f5f5f5; vertical-align:middle; }
        tr:last-child td { border-bottom:none; }
        tr:hover td { background:#fafffe; }

        .product-row { display:flex; align-items:center; gap:10px; }
        .product-row img { width:36px; height:36px; border-radius:8px; object-fit:cover; border:1px solid #eee; flex-shrink:0; }

        /* Export btn */
        .btn-export { display:flex; align-items:center; gap:8px; }

        @media (max-width:1100px) { .kpi-grid { grid-template-columns:repeat(2,1fr); } .charts-row { grid-template-columns:1fr; } .bottom-grid { grid-template-columns:1fr; } }
        @media (max-width:640px)  { .kpi-grid { grid-template-columns:1fr; } }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="admin-layout">
    <?php include '../partials/sidebar.php'; ?>

    <main class="admin-main">

        <!-- Header -->
        <div class="page-header">
            <h1><i class="fas fa-chart-bar" style="color:var(--green-sage,#7aa876);margin-right:8px"></i><?= $pageTitle ?></h1>

            <!-- Date Filter -->
            <form class="date-filter" method="GET" id="filterForm">
                <div class="range-btns">
                    <?php foreach (['7'=>'7 วัน','30'=>'30 วัน','90'=>'90 วัน','365'=>'1 ปี'] as $val => $label): ?>
                    <button type="submit" name="range" value="<?= $val ?>"
                            class="range-btn <?= $rangePreset === $val && !isset($_GET['from']) ? 'active' : '' ?>">
                        <?= $label ?>
                    </button>
                    <?php endforeach; ?>
                </div>
                <div class="date-inputs">
                    <input type="date" name="from" value="<?= $dateFrom ?>" onchange="this.form.submit()">
                    <span style="color:#aaa">–</span>
                    <input type="date" name="to" value="<?= $dateTo ?>" onchange="this.form.submit()">
                </div>
            </form>
        </div>

        <!-- KPI Cards -->
        <div class="kpi-grid">
            <!-- Revenue -->
            <div class="kpi-card green">
                <div class="kpi-icon" style="background:#e8f5e9"><i class="fas fa-wallet" style="color:#43a047"></i></div>
                <div class="kpi-num">฿<?= number_format($kpi['total_revenue'], 0) ?></div>
                <div class="kpi-label">รายได้รวม (ชำระแล้ว)</div>
                <?php
                    $cls = $revenueChange > 0 ? 'up' : ($revenueChange < 0 ? 'down' : 'flat');
                    $icon = $revenueChange >= 0 ? 'fa-arrow-up' : 'fa-arrow-down';
                ?>
                <div class="kpi-change <?= $cls ?>">
                    <i class="fas <?= $icon ?>"></i>
                    <?= abs(round($revenueChange, 1)) ?>% เทียบช่วงก่อนหน้า
                </div>
            </div>
            <!-- Orders -->
            <div class="kpi-card blue">
                <div class="kpi-icon" style="background:#e3f2fd"><i class="fas fa-receipt" style="color:#1e88e5"></i></div>
                <div class="kpi-num"><?= number_format($kpi['total_orders']) ?></div>
                <div class="kpi-label">คำสั่งซื้อทั้งหมด</div>
                <?php
                    $cls2 = $ordersChange > 0 ? 'up' : ($ordersChange < 0 ? 'down' : 'flat');
                    $icon2 = $ordersChange >= 0 ? 'fa-arrow-up' : 'fa-arrow-down';
                ?>
                <div class="kpi-change <?= $cls2 ?>">
                    <i class="fas <?= $icon2 ?>"></i>
                    <?= abs(round($ordersChange, 1)) ?>% เทียบช่วงก่อนหน้า
                </div>
            </div>
            <!-- Avg Order -->
            <div class="kpi-card orange">
                <div class="kpi-icon" style="background:#fff3e0"><i class="fas fa-shopping-bag" style="color:#fb8c00"></i></div>
                <div class="kpi-num">฿<?= number_format($kpi['avg_order'], 0) ?></div>
                <div class="kpi-label">มูลค่าเฉลี่ยต่อออเดอร์</div>
                <div class="kpi-change flat"><i class="fas fa-minus"></i> ช่วงที่เลือก</div>
            </div>
            <!-- New Members -->
            <div class="kpi-card purple">
                <div class="kpi-icon" style="background:#f3e5f5"><i class="fas fa-user-plus" style="color:#8e24aa"></i></div>
                <div class="kpi-num"><?= number_format($newMembers) ?></div>
                <div class="kpi-label">สมาชิกใหม่</div>
                <div class="kpi-change flat"><i class="fas fa-minus"></i> ช่วงที่เลือก</div>
            </div>
        </div>

        <!-- Charts Row -->
        <div class="charts-row">
            <!-- Line Chart: Revenue -->
            <div class="chart-card">
                <div class="chart-title"><i class="fas fa-chart-line" style="color:#1e88e5;margin-right:6px"></i>ยอดขายรายวัน</div>
                <canvas id="revenueChart" height="90"></canvas>
            </div>

            <!-- Donut: Order Status -->
            <div class="chart-card">
                <div class="chart-title"><i class="fas fa-chart-pie" style="color:#fb8c00;margin-right:6px"></i>สถานะออเดอร์</div>
                <canvas id="statusChart" height="160"></canvas>
                <div class="donut-legend">
                    <?php
                    $statusLabels = ['pending'=>'รอดำเนินการ','confirmed'=>'ยืนยันแล้ว','shipping'=>'กำลังจัดส่ง','delivered'=>'ส่งแล้ว','cancelled'=>'ยกเลิก'];
                    $statusColors = ['pending'=>'#fb8c00','confirmed'=>'#1e88e5','shipping'=>'#00897b','delivered'=>'#43a047','cancelled'=>'#e53935'];
                    $totalStatus  = array_sum($statusData) ?: 1;
                    foreach ($statusLabels as $key => $label):
                        $cnt = $statusData[$key] ?? 0;
                        $pct = round($cnt / $totalStatus * 100, 1);
                    ?>
                    <div class="legend-item">
                        <div style="display:flex;align-items:center">
                            <span class="legend-dot" style="background:<?= $statusColors[$key] ?>"></span>
                            <span><?= $label ?></span>
                        </div>
                        <span style="font-weight:600"><?= $cnt ?> <span style="color:#aaa;font-weight:400">(<?= $pct ?>%)</span></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Bottom Grid -->
        <div class="bottom-grid">

            <!-- Top Products -->
            <div class="section-card">
                <div class="section-header">
                    <span class="section-title"><i class="fas fa-trophy" style="color:#fb8c00;margin-right:6px"></i>สินค้าขายดี</span>
                </div>
                <table>
                    <thead><tr>
                        <th>สินค้า</th><th>จำนวน</th><th>ยอดขาย</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($topProducts as $i => $p): ?>
                    <tr>
                        <td>
                            <div class="product-row">
                                <span style="font-size:12px;color:#aaa;font-weight:700;width:18px"><?= $i+1 ?></span>
                                <img src="<?= SITE_URL ?>/<?= $p['image'] ?: 'img/no-image.png' ?>" alt="" onerror="this.src='<?= SITE_URL ?>/img/no-image.png'">
                                <span style="font-weight:500"><?= sanitize($p['name']) ?></span>
                            </div>
                        </td>
                        <td><?= number_format($p['total_qty']) ?></td>
                        <td style="font-weight:700;color:var(--green-deep,#2d5a27)">฿<?= number_format($p['total_revenue'], 0) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($topProducts)): ?>
                    <tr><td colspan="3" style="text-align:center;padding:30px;color:#aaa">ยังไม่มีข้อมูล</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Recent Paid Orders -->
            <div class="section-card">
                <div class="section-header">
                    <span class="section-title"><i class="fas fa-check-circle" style="color:#43a047;margin-right:6px"></i>ออเดอร์ที่ชำระแล้ว</span>
                    <a href="orders.php?status=delivered" class="btn btn-outline btn-sm">ดูทั้งหมด</a>
                </div>
                <table>
                    <thead><tr>
                        <th>เลขที่</th><th>ลูกค้า</th><th>ยอด</th><th>วันที่</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($recentPaid as $o): ?>
                    <tr>
                        <td style="font-size:12px;font-weight:600;color:var(--green-deep,#2d5a27)"><?= sanitize($o['order_number']) ?></td>
                        <td><?= sanitize($o['full_name']) ?></td>
                        <td style="font-weight:700;color:var(--green-deep,#2d5a27)">฿<?= number_format($o['final_price'], 0) ?></td>
                        <td style="font-size:12px;color:#aaa"><?= date('d/m/y', strtotime($o['created_at'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($recentPaid)): ?>
                    <tr><td colspan="4" style="text-align:center;padding:30px;color:#aaa">ยังไม่มีออเดอร์ที่ชำระแล้ว</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>

    </main>
</div>

<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>
// ===== Revenue Chart =====
const revenueCtx = document.getElementById('revenueChart').getContext('2d');
new Chart(revenueCtx, {
    type: 'line',
    data: {
        labels: <?= json_encode($chartLabels) ?>,
        datasets: [{
            label: 'ยอดขาย (฿)',
            data: <?= json_encode($chartRevenue) ?>,
            borderColor: '#43a047',
            backgroundColor: 'rgba(67,160,71,.08)',
            borderWidth: 2.5,
            pointRadius: <?= count($chartLabels) > 30 ? 0 : 4 ?>,
            pointHoverRadius: 6,
            fill: true,
            tension: 0.4,
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false },
            tooltip: {
                callbacks: {
                    label: ctx => ' ฿' + ctx.raw.toLocaleString()
                }
            }
        },
        scales: {
            x: { grid: { display: false }, ticks: { maxTicksLimit: 10, font: { size: 11 } } },
            y: { grid: { color: '#f0f0f0' }, ticks: { font: { size: 11 }, callback: v => '฿' + v.toLocaleString() } }
        }
    }
});

// ===== Status Donut =====
const statusCtx = document.getElementById('statusChart').getContext('2d');
new Chart(statusCtx, {
    type: 'doughnut',
    data: {
        labels: ['รอดำเนินการ','ยืนยันแล้ว','กำลังจัดส่ง','ส่งแล้ว','ยกเลิก'],
        datasets: [{
            data: [
                <?= $statusData['pending']   ?? 0 ?>,
                <?= $statusData['confirmed'] ?? 0 ?>,
                <?= $statusData['shipping']  ?? 0 ?>,
                <?= $statusData['delivered'] ?? 0 ?>,
                <?= $statusData['cancelled'] ?? 0 ?>,
            ],
            backgroundColor: ['#fb8c00','#1e88e5','#00897b','#43a047','#e53935'],
            borderWidth: 2,
            borderColor: '#fff',
        }]
    },
    options: {
        responsive: true,
        cutout: '65%',
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ' ' + ctx.label + ': ' + ctx.raw + ' ออเดอร์' } } }
    }
});
</script>
</body>
</html>
