<?php
define('INCLUDED', true);
require_once __DIR__ . '/../config.php'; // admin/ → root
requireAdmin(); // ต้องเป็น admin เท่านั้น

$pdo = getDB();
$userId = $_SESSION['user_id'];
$msg = '';

// ดึงข้อมูลผู้ใช้
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $fullName = trim($_POST['full_name'] ?? '');
        $phone    = trim($_POST['phone'] ?? '');

        $imgPath = $user['profile_image'];
        if (!empty($_FILES['profile_image']['name'])) {
            $uploaded = uploadImage($_FILES['profile_image'], 'profiles');
            if ($uploaded) $imgPath = $uploaded;
        }

        $pdo->prepare("UPDATE users SET full_name=?,phone=?,profile_image=? WHERE id=?")
            ->execute([$fullName, $phone, $imgPath, $userId]);

        $_SESSION['username'] = $fullName;
        $_SESSION['profile_image'] = $imgPath;
        $msg = 'อัปเดตโปรไฟล์สำเร็จ';

    } elseif ($action === 'update_address') {
        $provinceId    = (int)($_POST['province_id']    ?? 0);
        $districtId    = (int)($_POST['district_id']    ?? 0);
        $subdistrictId = (int)($_POST['subdistrict_id'] ?? 0);

        // ดึงชื่อจาก DB ตาม ID
        $pName = $pdo->prepare("SELECT name FROM provinces WHERE id=?");
        $pName->execute([$provinceId]);
        $provinceName = $pName->fetchColumn() ?: '';

        $dName = $pdo->prepare("SELECT name FROM districts WHERE id=?");
        $dName->execute([$districtId]);
        $districtName = $dName->fetchColumn() ?: '';

        $sName = $pdo->prepare("SELECT name, zipcode FROM subdistricts WHERE id=?");
        $sName->execute([$subdistrictId]);
        $subRow          = $sName->fetch();
        $subdistrictName = $subRow['name']    ?? '';
        $zipcode         = $subRow['zipcode'] ?? trim($_POST['zipcode'] ?? '');

        $pdo->prepare("UPDATE users SET address=?,province=?,district=?,subdistrict=?,zipcode=? WHERE id=?")
            ->execute([
                trim($_POST['address'] ?? ''),
                $provinceName,
                $districtName,
                $subdistrictName,
                $zipcode,
                $userId
            ]);
        $msg = 'อัปเดตที่อยู่สำเร็จ';
    }

    // โหลดข้อมูลใหม่
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
}

// ประวัติคะแนน
$pointsHistory = $pdo->prepare("SELECT * FROM points_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$pointsHistory->execute([$userId]);
$pointsHistory = $pointsHistory->fetchAll();

$pageTitle = 'โปรไฟล์ของฉัน';
?>
<?php include __DIR__ . '/navbar.php'; // admin/navbar.php ?>

<div class="main-content" style="max-width:900px;margin:0 auto;padding-top:40px">

    <?php if ($msg): ?>
    <div class="alert alert-success" style="margin-bottom:24px"><i class="fas fa-check-circle"></i> <?= sanitize($msg) ?></div>
    <?php endif; ?>

    <!-- Header Card -->
    <div style="background:var(--gradient-main);border-radius:var(--radius-lg);padding:32px;margin-bottom:28px;display:flex;align-items:center;gap:24px;color:white">
        <div style="position:relative">
            <img src="<?= SITE_URL ?>/<?= sanitize($user['profile_image'] ?? 'img/no-image.png') ?>"
                 style="width:80px;height:80px;border-radius:50%;object-fit:cover;border:3px solid rgba(255,255,255,0.5)"
                 id="profilePreview"
                 onerror="this.src='<?= SITE_URL ?>/img/no-image.png'">
            <label for="profileUpload" style="position:absolute;bottom:0;right:0;background:white;border-radius:50%;width:26px;height:26px;display:flex;align-items:center;justify-content:center;cursor:pointer;color:var(--green-deep);font-size:12px">
                <i class="fas fa-camera"></i>
            </label>
        </div>
        <div>
            <h2 style="font-size:1.4rem;font-weight:800;margin-bottom:4px"><?= sanitize($user['full_name'] ?? $user['username']) ?></h2>
            <p style="opacity:0.85;font-size:14px"><?= sanitize($user['email']) ?></p>
            <p style="opacity:0.75;font-size:13px;margin-top:4px">⭐ คะแนนสะสม: <strong><?= $user['points'] ?> คะแนน</strong></p>
        </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px">
        <!-- แก้ไขโปรไฟล์ -->
        <div style="background:white;border-radius:var(--radius-lg);padding:24px;box-shadow:var(--shadow-card);border:1px solid var(--green-pale)">
            <h3 style="font-size:1rem;font-weight:700;margin-bottom:20px;color:var(--text-dark)">
                <i class="fas fa-user" style="color:var(--green-sage)"></i> ข้อมูลส่วนตัว
            </h3>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="update_profile">
                <input type="file" id="profileUpload" name="profile_image" accept="image/*" style="display:none" onchange="previewProfile(this)">
                <div class="form-group">
                    <label class="form-label">ชื่อ-นามสกุล</label>
                    <input type="text" name="full_name" class="form-control" value="<?= sanitize($user['full_name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">อีเมล</label>
                    <input type="email" class="form-control" value="<?= sanitize($user['email']) ?>" disabled style="opacity:0.6">
                </div>
                <div class="form-group">
                    <label class="form-label">เบอร์โทรศัพท์</label>
                    <input type="tel" name="phone" class="form-control" value="<?= sanitize($user['phone'] ?? '') ?>">
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> บันทึก</button>
            </form>
        </div>

        <!-- แก้ไขที่อยู่ -->
        <div style="background:white;border-radius:var(--radius-lg);padding:24px;box-shadow:var(--shadow-card);border:1px solid var(--green-pale)">
            <h3 style="font-size:1rem;font-weight:700;margin-bottom:20px;color:var(--text-dark)">
                <i class="fas fa-map-marker-alt" style="color:var(--green-sage)"></i> ที่อยู่จัดส่ง
            </h3>
            <form method="POST" id="addressForm">
                <input type="hidden" name="action" value="update_address">
                <div class="form-group">
                    <label class="form-label">ที่อยู่ (บ้านเลขที่ ซอย ถนน)</label>
                    <textarea name="address" class="form-control" rows="2" placeholder="เช่น 123/4 ซอยสุขใจ ถนนสุขภาพดี"><?= sanitize($user['address'] ?? '') ?></textarea>
                </div>

                <!-- hidden IDs -->
                <input type="hidden" name="province_id"    id="hidProvinceId">
                <input type="hidden" name="district_id"    id="hidDistrictId">
                <input type="hidden" name="subdistrict_id" id="hidSubdistrictId">

                <!-- จังหวัด -->
                <div class="form-group">
                    <label class="form-label">จังหวัด</label>
                    <select id="selProvince" class="form-control" required onchange="onProvinceChange()">
                        <option value="">-- กำลังโหลด... --</option>
                    </select>
                </div>

                <!-- อำเภอ/เขต -->
                <div class="form-group">
                    <label class="form-label">อำเภอ/เขต</label>
                    <select id="selDistrict" class="form-control" required onchange="onDistrictChange()" disabled>
                        <option value="">-- เลือกจังหวัดก่อน --</option>
                    </select>
                </div>

                <!-- ตำบล/แขวง -->
                <div class="form-group">
                    <label class="form-label">ตำบล/แขวง</label>
                    <select id="selSubdistrict" class="form-control" required onchange="onSubdistrictChange()" disabled>
                        <option value="">-- เลือกอำเภอก่อน --</option>
                    </select>
                </div>

                <!-- รหัสไปรษณีย์ -->
                <div class="form-group">
                    <label class="form-label">รหัสไปรษณีย์</label>
                    <div style="position:relative;">
                        <input type="text" name="zipcode" id="inputZipcode" class="form-control"
                               maxlength="5" placeholder="กรอกอัตโนมัติเมื่อเลือกตำบล"
                               value="<?= sanitize($user['zipcode'] ?? '') ?>"
                               style="background:var(--green-cream);" readonly>
                        <span style="position:absolute;right:12px;top:50%;transform:translateY(-50%);color:var(--green-sage);font-size:13px;">
                            <i class="fas fa-map-pin"></i>
                        </span>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-full"><i class="fas fa-save"></i> บันทึกที่อยู่</button>
            </form>
        </div>
    </div>

    <!-- คะแนนสะสม -->
    <div style="background:white;border-radius:var(--radius-lg);padding:24px;box-shadow:var(--shadow-card);border:1px solid var(--green-pale);margin-top:24px">
        <h3 style="font-size:1rem;font-weight:700;margin-bottom:20px;color:var(--text-dark)">
            ⭐ ประวัติคะแนนสะสม (<?= $user['points'] ?> คะแนน)
        </h3>
        <?php if (empty($pointsHistory)): ?>
        <p style="color:var(--text-light);text-align:center;padding:20px">ยังไม่มีประวัติคะแนน</p>
        <?php else: ?>
        <table style="width:100%;font-size:14px">
            <thead><tr style="background:var(--green-cream)">
                <th style="padding:10px 14px;text-align:left">วันที่</th>
                <th style="padding:10px 14px;text-align:left">รายละเอียด</th>
                <th style="padding:10px 14px;text-align:right">คะแนน</th>
            </tr></thead>
            <tbody>
            <?php foreach ($pointsHistory as $ph): ?>
            <tr style="border-bottom:1px solid var(--green-pale)">
                <td style="padding:10px 14px"><?= formatDate($ph['created_at']) ?></td>
                <td style="padding:10px 14px"><?= sanitize($ph['description'] ?? '') ?></td>
                <td style="padding:10px 14px;text-align:right;font-weight:700;color:<?= $ph['points_change'] >= 0 ? 'var(--green-deep)' : '#e74c3c' ?>">
                    <?= $ph['points_change'] >= 0 ? '+' : '' ?><?= $ph['points_change'] ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<footer class="footer" style="margin-top:60px">
    <div class="footer-bottom">&copy; <?= date('Y') ?> <?= SITE_NAME ?></div>
</footer>

<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>
// ---- Preview Profile Image ----
function previewProfile(input) {
    if (input.files[0]) {
        const reader = new FileReader();
        reader.onload = e => { document.getElementById('profilePreview').src = e.target.result; };
        reader.readAsDataURL(input.files[0]);
    }
}

// ---- ค่าที่บันทึกไว้จาก PHP (ชื่อ) ----
const savedProvince    = "<?= addslashes(sanitize($user['province']    ?? '')) ?>";
const savedDistrict    = "<?= addslashes(sanitize($user['district']    ?? '')) ?>";
const savedSubdistrict = "<?= addslashes(sanitize($user['subdistrict'] ?? '')) ?>";
const API_URL          = "<?= SITE_URL ?>/api/address.php";

const selProvince    = document.getElementById('selProvince');
const selDistrict    = document.getElementById('selDistrict');
const selSubdistrict = document.getElementById('selSubdistrict');
const inputZipcode   = document.getElementById('inputZipcode');
const hidProvinceId    = document.getElementById('hidProvinceId');
const hidDistrictId    = document.getElementById('hidDistrictId');
const hidSubdistrictId = document.getElementById('hidSubdistrictId');

// ---- โหลดจังหวัดจาก DB ----
async function loadProvinces() {
    selProvince.innerHTML = '<option value="">-- กำลังโหลด... --</option>';
    const res  = await fetch(`${API_URL}?action=provinces`);
    const data = await res.json();
    selProvince.innerHTML = '<option value="">-- เลือกจังหวัด --</option>';
    data.forEach(p => {
        const opt = new Option(p.name, p.id);
        opt.dataset.name = p.name;
        selProvince.appendChild(opt);
    });
    // คืนค่าเดิมถ้ามี
    if (savedProvince) {
        const match = [...selProvince.options].find(o => o.dataset.name === savedProvince);
        if (match) {
            selProvince.value = match.value;
            hidProvinceId.value = match.value;
            await loadDistricts(match.value, savedDistrict);
        }
    }
}

// ---- โหลดอำเภอจาก DB ----
async function loadDistricts(provinceId, selectName = '') {
    selDistrict.innerHTML = '<option value="">-- กำลังโหลด... --</option>';
    selDistrict.disabled  = true;
    selSubdistrict.innerHTML = '<option value="">-- เลือกอำเภอก่อน --</option>';
    selSubdistrict.disabled  = true;
    inputZipcode.value = '';

    const res  = await fetch(`${API_URL}?action=districts&province_id=${provinceId}`);
    const data = await res.json();
    selDistrict.innerHTML = '<option value="">-- เลือกอำเภอ/เขต --</option>';
    data.forEach(d => {
        const opt = new Option(d.name, d.id);
        opt.dataset.name = d.name;
        selDistrict.appendChild(opt);
    });
    selDistrict.disabled = false;

    if (selectName) {
        const match = [...selDistrict.options].find(o => o.dataset.name === selectName);
        if (match) {
            selDistrict.value   = match.value;
            hidDistrictId.value = match.value;
            await loadSubdistricts(match.value, savedSubdistrict);
        }
    }
}

// ---- โหลดตำบลจาก DB ----
async function loadSubdistricts(districtId, selectName = '') {
    selSubdistrict.innerHTML = '<option value="">-- กำลังโหลด... --</option>';
    selSubdistrict.disabled  = true;
    inputZipcode.value = '';

    const res  = await fetch(`${API_URL}?action=subdistricts&district_id=${districtId}`);
    const data = await res.json();
    selSubdistrict.innerHTML = '<option value="">-- เลือกตำบล/แขวง --</option>';
    data.forEach(s => {
        const opt = new Option(s.name, s.id);
        opt.dataset.name    = s.name;
        opt.dataset.zipcode = s.zipcode;
        selSubdistrict.appendChild(opt);
    });
    selSubdistrict.disabled = false;

    if (selectName) {
        const match = [...selSubdistrict.options].find(o => o.dataset.name === selectName);
        if (match) {
            selSubdistrict.value   = match.value;
            hidSubdistrictId.value = match.value;
            inputZipcode.value     = match.dataset.zipcode;
        }
    }
}

// ---- Events ----
async function onProvinceChange() {
    const opt = selProvince.options[selProvince.selectedIndex];
    hidProvinceId.value  = opt.value || '';
    hidDistrictId.value    = '';
    hidSubdistrictId.value = '';
    inputZipcode.value   = '';
    if (!opt.value) {
        selDistrict.innerHTML    = '<option value="">-- เลือกจังหวัดก่อน --</option>';
        selDistrict.disabled     = true;
        selSubdistrict.innerHTML = '<option value="">-- เลือกอำเภอก่อน --</option>';
        selSubdistrict.disabled  = true;
        return;
    }
    await loadDistricts(opt.value);
}

async function onDistrictChange() {
    const opt = selDistrict.options[selDistrict.selectedIndex];
    hidDistrictId.value    = opt.value || '';
    hidSubdistrictId.value = '';
    inputZipcode.value     = '';
    if (!opt.value) {
        selSubdistrict.innerHTML = '<option value="">-- เลือกอำเภอก่อน --</option>';
        selSubdistrict.disabled  = true;
        return;
    }
    await loadSubdistricts(opt.value);
}

function onSubdistrictChange() {
    const opt = selSubdistrict.options[selSubdistrict.selectedIndex];
    if (!opt.value) return;
    hidSubdistrictId.value = opt.value;
    inputZipcode.value     = opt.dataset.zipcode || '';
    // Highlight
    inputZipcode.style.borderColor = 'var(--green-sage)';
    inputZipcode.style.background  = 'var(--green-pale)';
    setTimeout(() => {
        inputZipcode.style.borderColor = '';
        inputZipcode.style.background  = 'var(--green-cream)';
    }, 1200);
}

// ---- เริ่มต้น ----
loadProvinces();
</script>
</body>
</html>