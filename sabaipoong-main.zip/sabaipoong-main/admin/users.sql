

CREATE TABLE `users` (
  `id`            int(11)                          NOT NULL,
  `username`      varchar(100)                     NOT NULL,
  `email`         varchar(150)                     NOT NULL,
  `password`      varchar(255)                     NOT NULL,
  `full_name`     varchar(200)                     DEFAULT NULL,
  `phone`         varchar(20)                      DEFAULT NULL,
  `address`       text                             DEFAULT NULL,
  `province`      varchar(100)                     DEFAULT NULL,
  `district`      varchar(100)                     DEFAULT NULL,
  `subdistrict`   varchar(100)                     DEFAULT NULL,
  `zipcode`       varchar(10)                      DEFAULT NULL,
  `profile_image` varchar(255)                     DEFAULT 'uploads/profiles/default.png',
  `role`          enum('admin','user')             DEFAULT 'user',
  `login_type`    enum('email','google','line')    DEFAULT 'email',
  `social_id`     varchar(255)                     DEFAULT NULL,
  `points`        int(11)                          DEFAULT 0,
  `is_active`     tinyint(1)                       DEFAULT 1,
  `is_banned`     tinyint(1)                       DEFAULT 0,
  `created_at`    datetime                         DEFAULT current_timestamp(),
  `updated_at`    datetime                         DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
-- หมายเหตุ: password ทุก account ถูก hash ด้วย bcrypt ($2y$10$...)
-- password ของ admin@sabaipung.com คือ  Admin@1234  (ควรเปลี่ยนทันทีหลัง deploy)
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `full_name`, `phone`, `address`, `province`, `district`, `subdistrict`, `zipcode`, `profile_image`, `role`, `login_type`, `social_id`, `points`, `is_active`, `is_banned`, `created_at`, `updated_at`) VALUES
(1, 'superadmin',      'admin@sabaipung.com',      '$2y$10$Rk3z1yQwLmN8vXpT6oJdKuA2sF5gHcYe0bEiOlVnMwPqDrZjSaUt2', 'ผู้ดูแลระบบ',   NULL,         NULL,   NULL,       NULL,             NULL,            NULL,    'uploads/profiles/default.png', 'admin', 'email', NULL, 0, 1, 0, '2026-02-26 18:45:48', '2026-02-26 19:07:35'),
(2, 'sabaipoong369',   'sabaipoong369@gmail.com',  '$2y$10$bk5LCANf42bXx0690nUgNu9Vc6Of5ht4h7cT3JNXBuo/53s0svApC', 'รัน สบายพุง',   '0968684493', '280/21', 'เชียงราย', 'เมืองเชียงราย', 'ป่าอ้อดอนชัย', '57000', 'uploads/profiles/69a03dff57bf9_1772109311.png', 'user', 'email', NULL, 0, 1, 0, '2026-02-26 19:31:25', '2026-02-26 20:01:44'),
(3, 'admin2',          'admin@email.com',           '$2y$10$1CRT2YA46ctZM2V1WI56nuNNSocXrGsVOmdoDx/u9CALPQF7iNaWq', 'ผู้ดูแลระบบ 2', '0965876982', NULL,   NULL,       NULL,             NULL,            NULL,    'uploads/profiles/default.png', 'admin', 'email', NULL, 0, 1, 0, '2026-02-26 20:04:29', '2026-02-26 20:12:42');

--
-- Indexes for table `users`
--

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email`    (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for table `users`
--

ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

COMMIT;

