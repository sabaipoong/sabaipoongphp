<?php
define('INCLUDED', true);
require_once '../config.php';
requireAdmin();

$pdo = getDB();
$pageTitle = 'แผงควบคุม Admin';

// Stats
$totalProducts = $pdo->query("SELECT COUNT(*) FROM products WHERE is_active=1")->fetchColumn();
$totalUsers    = $pdo->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
$totalOrders   = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$totalRevenue  = $pdo->query("SELECT COALESCE(SUM(final_price),0) FROM orders WHERE payment_status='paid'")->fetchColumn();
$pendingOrders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status='pending'")->fetchColumn();
$todayOrders   = $pdo->query("SELECT COUNT(*) FROM orders WHERE DATE(created_at)=CURDATE()")->fetchColumn();
$lowStock      = $pdo->query("SELECT * FROM products WHERE stock <= 5 AND is_active=1 ORDER BY stock ASC LIMIT 5")->fetchAll();
$recentOrders  = $pdo->query("SELECT o.*, u.full_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 8")->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="<?= SITE_URL ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        /* ===== Dashboard Enhanced Styles ===== */
        .admin-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 28px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--border-color, #e8f0e9);
        }
        .admin-header h1 {
            font-size: 24px;
            font-weight: 700;
            color: var(--green-deep, #2d5a27);
            margin: 0;
        }
        .admin-header .header-right {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .date-badge {
            background: var(--green-light, #f0f7ee);
            color: var(--green-deep, #2d5a27);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 500;
            border: 1px solid var(--green-border, #c8e0c4);
        }

        /* ===== Stats Grid ===== */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 28px;
        }
        .stat-card {
            background: #fff;
            border-radius: 16px;
            padding: 22px 20px;
            display: flex;
            align-items: center;
            gap: 16px;
            box-shadow: 0 2px 12px rgba(0,0,0,.06);
            border: 1px solid var(--border-color, #e8f0e9);
            transition: transform .2s, box-shadow .2s;
            text-decoration: none !important;
            color: inherit !important;
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 3px;
            border-radius: 16px 16px 0 0;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 24px rgba(0,0,0,.1);
        }
        .stat-card.green::before  { background: linear-gradient(90deg,#4caf50,#81c784); }
        .stat-card.blue::before   { background: linear-gradient(90deg,#2196f3,#64b5f6); }
        .stat-card.orange::before { background: linear-gradient(90deg,#ff9800,#ffb74d); }
        .stat-card.purple::before { background: linear-gradient(90deg,#9c27b0,#ce93d8); }
        .stat-card.red::before    { background: linear-gradient(90deg,#f44336,#ef9a9a); }
        .stat-card.teal::before   { background: linear-gradient(90deg,#009688,#4db6ac); }

        .stat-icon-box {
            width: 52px;
            height: 52px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            flex-shrink: 0;
        }
        .stat-icon-box.green  { background: #e8f5e9; }
        .stat-icon-box.blue   { background: #e3f2fd; }
        .stat-icon-box.orange { background: #fff3e0; }
        .stat-icon-box.purple { background: #f3e5f5; }
        .stat-icon-box.red    { background: #ffebee; }
        .stat-icon-box.teal   { background: #e0f2f1; }

        .stat-info h3 {
            font-size: 26px;
            font-weight: 700;
            margin: 0 0 2px;
            line-height: 1;
            color: var(--text-dark, #1a1a1a);
        }
        .stat-info p {
            font-size: 13px;
            color: var(--text-light, #888);
            margin: 0;
        }

        /* ===== Quick Stats Row ===== */
        .quick-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 18px;
            margin-bottom: 28px;
        }
        .quick-stat-item {
            background: #fff;
            border-radius: 14px;
            padding: 16px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 8px rgba(0,0,0,.05);
            border: 1px solid var(--border-color, #e8f0e9);
        }
        .quick-stat-item .qs-label {
            font-size: 13px;
            color: var(--text-light, #888);
        }
        .quick-stat-item .qs-value {
            font-size: 20px;
            font-weight: 700;
            color: var(--green-deep, #2d5a27);
        }
        .quick-stat-item .qs-icon {
            width: 40px; height: 40px;
            border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 16px;
        }

        /* ===== Table Sections ===== */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr 1.4fr;
            gap: 22px;
        }
        .table-wrapper {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(0,0,0,.06);
            border: 1px solid var(--border-color, #e8f0e9);
            overflow: hidden;
        }
        .table-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 18px 20px;
            border-bottom: 1px solid var(--border-color, #e8f0e9);
            background: var(--green-light, #f8fdf7);
        }
        .table-title {
            font-weight: 700;
            font-size: 15px;
            color: var(--text-dark, #1a1a1a);
        }
        .table-wrapper table {
            width: 100%;
            border-collapse: collapse;
        }
        .table-wrapper th {
            padding: 10px 16px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: .5px;
            color: var(--text-light, #888);
            background: var(--green-light, #f8fdf7);
            border-bottom: 1px solid var(--border-color, #e8f0e9);
            text-align: left;
        }
        .table-wrapper td {
            padding: 12px 16px;
            font-size: 14px;
            border-bottom: 1px solid #f5f5f5;
            vertical-align: middle;
        }
        .table-wrapper tr:last-child td { border-bottom: none; }
        .table-wrapper tr:hover td { background: #fafffe; }

        .td-product {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .td-product img {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            object-fit: cover;
            border: 1px solid #eee;
        }

        /* ===== Responsive ===== */
        @media (max-width: 1100px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .dashboard-grid { grid-template-columns: 1fr; }
        }
        @media (max-width: 640px) {
            .stats-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="admin-layout">
    <!-- Sidebar -->
    <?php include '../partials/sidebar.php'; ?>

    <!-- Main -->
    <main class="admin-main">

        <!-- Header -->
        <div class="admin-header">
            <div>
                <h1><i class="fas fa-tachometer-alt" style="color:var(--green-sage,#7aa876);margin-right:8px;font-size:22px"></i>แผงควบคุม</h1>
                <p style="margin:4px 0 0;font-size:13px;color:var(--text-light,#888)">ยินดีต้อนรับกลับ, <?= sanitize($_SESSION['username'] ?? 'Admin') ?> 👋</p>
            </div>
            <div class="header-right">
                <span class="date-badge">
                    <i class="fas fa-calendar-alt" style="margin-right:6px"></i>
                    <?= formatDate(date('Y-m-d H:i:s')) ?>
                </span>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <a href="<?= SITE_URL ?>/admin/products.php" class="stat-card green">
                <div class="stat-icon-box green"><i class="fas fa-box-open" style="color:#43a047"></i></div>
                <div class="stat-info">
                    <h3><?= number_format($totalProducts) ?></h3>
                    <p>สินค้าทั้งหมด</p>
                </div>
            </a>
            <a href="<?= SITE_URL ?>/admin/users.php" class="stat-card blue">
                <div class="stat-icon-box blue"><i class="fas fa-users" style="color:#1e88e5"></i></div>
                <div class="stat-info">
                    <h3><?= number_format($totalUsers) ?></h3>
                    <p>สมาชิกทั้งหมด</p>
                </div>
            </a>
            <a href="<?= SITE_URL ?>/admin/orders.php" class="stat-card orange">
                <div class="stat-icon-box orange"><i class="fas fa-receipt" style="color:#fb8c00"></i></div>
                <div class="stat-info">
                    <h3><?= number_format($totalOrders) ?></h3>
                    <p>คำสั่งซื้อทั้งหมด</p>
                </div>
            </a>
            <a href="#" class="stat-card purple">
                <div class="stat-icon-box purple"><i class="fas fa-wallet" style="color:#8e24aa"></i></div>
                <div class="stat-info">
                    <h3>฿<?= number_format($totalRevenue, 0) ?></h3>
                    <p>รายได้รวม</p>
                </div>
            </a>
        </div>

        <!-- Quick Stats -->
        <div class="quick-stats">
            <div class="quick-stat-item">
                <div>
                    <div class="qs-label">รอดำเนินการวันนี้</div>
                    <div class="qs-value"><?= number_format($pendingOrders) ?> ออเดอร์</div>
                </div>
                <div class="qs-icon" style="background:#fff3e0"><i class="fas fa-hourglass-half" style="color:#fb8c00"></i></div>
            </div>
            <div class="quick-stat-item">
                <div>
                    <div class="qs-label">ออเดอร์วันนี้</div>
                    <div class="qs-value"><?= number_format($todayOrders) ?> รายการ</div>
                </div>
                <div class="qs-icon" style="background:#e8f5e9"><i class="fas fa-shopping-bag" style="color:#43a047"></i></div>
            </div>
        </div>

        <!-- Table Grid -->
        <div class="dashboard-grid">

            <!-- สินค้าสต็อกต่ำ -->
            <div class="table-wrapper">
                <div class="table-header">
                    <span class="table-title"><i class="fas fa-exclamation-triangle" style="color:#fb8c00;margin-right:6px"></i>สต็อกใกล้หมด</span>
                    <a href="<?= SITE_URL ?>/admin/products.php" class="btn btn-outline btn-sm">จัดการ</a>
                </div>
                <table>
                    <thead><tr>
                        <th>สินค้า</th><th>คงเหลือ</th><th></th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($lowStock as $p): ?>
                    <tr>
                        <td>
                            <div class="td-product">
                                <img src="<?= SITE_URL ?>/<?= $p['image'] ?: 'img/no-image.png' ?>" alt="" onerror="this.src='<?= SITE_URL ?>/img/no-image.png'">
                                <span style="font-weight:500"><?= sanitize($p['name']) ?></span>
                            </div>
                        </td>
                        <td>
                            <span class="badge badge-danger" style="font-size:12px">
                                <i class="fas fa-exclamation-circle" style="margin-right:3px"></i>
                                <?= $p['stock'] ?> <?= $p['unit'] ?>
                            </span>
                        </td>
                        <td>
                            <a href="<?= SITE_URL ?>/admin/products.php?action=edit&id=<?= $p['id'] ?>" class="btn btn-outline btn-sm">
                                <i class="fas fa-plus"></i> เพิ่ม
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($lowStock)): ?>
                    <tr>
                        <td colspan="3" style="text-align:center;color:var(--text-light,#888);padding:32px">
                            <i class="fas fa-check-circle" style="color:#43a047;font-size:24px;display:block;margin-bottom:8px"></i>
                            สต็อกปกติทั้งหมด
                        </td>
                    </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- คำสั่งซื้อล่าสุด -->
            <div class="table-wrapper">
                <div class="table-header">
                    <span class="table-title"><i class="fas fa-clock" style="color:#1e88e5;margin-right:6px"></i>คำสั่งซื้อล่าสุด</span>
                    <a href="<?= SITE_URL ?>/admin/orders.php" class="btn btn-outline btn-sm">ดูทั้งหมด</a>
                </div>
                <table>
                    <thead><tr>
                        <th>เลขที่</th><th>ลูกค้า</th><th>ยอด</th><th>สถานะ</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($recentOrders as $o):
                        $statusMap = [
                            'pending'   => ['class'=>'badge-warning', 'label'=>'รอดำเนินการ', 'icon'=>'fa-hourglass-half'],
                            'confirmed' => ['class'=>'badge-info',    'label'=>'ยืนยันแล้ว',  'icon'=>'fa-check'],
                            'shipping'  => ['class'=>'badge-info',    'label'=>'กำลังจัดส่ง','icon'=>'fa-truck'],
                            'delivered' => ['class'=>'badge-success', 'label'=>'ส่งแล้ว',     'icon'=>'fa-check-double'],
                            'cancelled' => ['class'=>'badge-danger',  'label'=>'ยกเลิก',      'icon'=>'fa-times'],
                        ];
                        $s = $statusMap[$o['status']] ?? ['class'=>'badge-info','label'=>$o['status'],'icon'=>'fa-circle'];
                    ?>
                    <tr>
                        <td>
                            <a href="<?= SITE_URL ?>/admin/orders.php?action=view&id=<?= $o['id'] ?>" style="font-size:12px;color:var(--green-deep,#2d5a27);font-weight:600;text-decoration:none">
                                <?= sanitize($o['order_number']) ?>
                            </a>
                        </td>
                        <td>
                            <div style="display:flex;align-items:center;gap:8px">
                                <div style="width:28px;height:28px;border-radius:50%;background:var(--green-light,#e8f5e9);display:flex;align-items:center;justify-content:center;font-size:11px;color:var(--green-deep,#2d5a27);font-weight:700;flex-shrink:0">
                                    <?= mb_substr($o['full_name'], 0, 1) ?>
                                </div>
                                <?= sanitize($o['full_name']) ?>
                            </div>
                        </td>
                        <td style="font-weight:700;color:var(--green-deep,#2d5a27)">฿<?= number_format($o['final_price'], 0) ?></td>
                        <td>
                            <span class="badge <?= $s['class'] ?>">
                                <i class="fas <?= $s['icon'] ?>" style="margin-right:4px"></i>
                                <?= $s['label'] ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($recentOrders)): ?>
                    <tr><td colspan="4" style="text-align:center;color:var(--text-light,#888);padding:32px">ยังไม่มีคำสั่งซื้อ</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </main>
</div>

<script src="<?= SITE_URL ?>/js/main.js"></script>
</body>
</html>
