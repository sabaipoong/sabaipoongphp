<?php
define('INCLUDED', true);
require_once 'config.php';
requireLogin();

$pdo    = getDB();
$userId = $_SESSION['user_id'];
$msg    = '';
$error  = '';
$pageTitle = 'เปลี่ยนรหัสผ่าน';

// ดึงข้อมูลผู้ใช้
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

// ถ้า login ผ่าน social ไม่มีรหัสผ่าน
$isSocialLogin = $user['login_type'] !== 'email';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$isSocialLogin) {
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword     = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (!$currentPassword || !$newPassword || !$confirmPassword) {
        $error = 'กรุณากรอกข้อมูลให้ครบถ้วน';
    } elseif (!password_verify($currentPassword, $user['password'])) {
        $error = 'รหัสผ่านปัจจุบันไม่ถูกต้อง';
    } elseif (strlen($newPassword) < 6) {
        $error = 'รหัสผ่านใหม่ต้องมีอย่างน้อย 6 ตัวอักษร';
    } elseif ($newPassword !== $confirmPassword) {
        $error = 'รหัสผ่านใหม่ไม่ตรงกัน';
    } elseif (password_verify($newPassword, $user['password'])) {
        $error = 'รหัสผ่านใหม่ต้องไม่ซ้ำกับรหัสผ่านเดิม';
    } else {
        $hash = password_hash($newPassword, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?")
            ->execute([$hash, $userId]);
        $msg = 'เปลี่ยนรหัสผ่านสำเร็จ! 🎉';
    }
}
?>
<?php include 'navbar.php'; ?>

<div class="main-content" style="max-width:520px;margin:0 auto;padding-top:48px;padding-bottom:60px;">

    <!-- Breadcrumb -->
    <div style="font-size:13px;color:var(--text-light);margin-bottom:24px;">
        <a href="index.php" style="color:var(--green-deep);">หน้าแรก</a>
        <span style="margin:0 8px;">›</span>
        <a href="profile.php" style="color:var(--green-deep);">โปรไฟล์</a>
        <span style="margin:0 8px;">›</span>
        <span>เปลี่ยนรหัสผ่าน</span>
    </div>

    <div style="background:white;border-radius:var(--radius-lg);box-shadow:var(--shadow-card);border:1px solid var(--green-pale);overflow:hidden;">

        <!-- Header -->
        <div style="background:var(--gradient-main);padding:28px 32px;color:white;">
            <div style="font-size:32px;margin-bottom:8px;">🔐</div>
            <h1 style="font-size:1.2rem;font-weight:800;margin-bottom:4px;">เปลี่ยนรหัสผ่าน</h1>
            <p style="font-size:13px;opacity:.85;">
                <?= sanitize($user['full_name'] ?? $user['username'] ?? '') ?> · <?= sanitize($user['email']) ?>
            </p>
        </div>

        <div style="padding:32px;">

            <?php if ($isSocialLogin): ?>
            <!-- Social Login - ไม่มีรหัสผ่าน -->
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i>
                บัญชีของคุณเข้าสู่ระบบผ่าน
                <strong><?= $user['login_type'] === 'google' ? 'Google' : 'LINE' ?></strong>
                จึงไม่สามารถเปลี่ยนรหัสผ่านได้ในระบบนี้
            </div>
            <p style="font-size:14px;color:var(--text-light);margin-bottom:20px;">
                หากต้องการเปลี่ยนรหัสผ่าน กรุณาไปที่การตั้งค่าของ
                <?= $user['login_type'] === 'google' ? 'Google Account' : 'LINE Account' ?> โดยตรง
            </p>
            <a href="profile.php" class="btn btn-primary">
                <i class="fas fa-arrow-left"></i> กลับหน้าโปรไฟล์
            </a>

            <?php else: ?>

            <?php if ($error): ?>
            <div class="alert alert-error" style="margin-bottom:20px;">
                <i class="fas fa-exclamation-circle"></i> <?= sanitize($error) ?>
            </div>
            <?php endif; ?>

            <?php if ($msg): ?>
            <div class="alert alert-success" style="margin-bottom:20px;">
                <i class="fas fa-check-circle"></i> <?= sanitize($msg) ?>
            </div>
            <?php endif; ?>

            <form method="POST" id="changePasswordForm">

                <!-- รหัสผ่านปัจจุบัน -->
                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-lock" style="color:var(--green-sage)"></i> รหัสผ่านปัจจุบัน
                    </label>
                    <div style="position:relative;">
                        <input type="password" name="current_password" id="currentPw"
                               class="form-control" placeholder="••••••••" required
                               style="padding-right:44px;">
                        <button type="button" onclick="togglePw('currentPw','icon1')"
                                style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text-light);cursor:pointer;">
                            <i class="fas fa-eye" id="icon1"></i>
                        </button>
                    </div>
                </div>

                <!-- รหัสผ่านใหม่ -->
                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-key" style="color:var(--green-sage)"></i> รหัสผ่านใหม่
                    </label>
                    <div style="position:relative;">
                        <input type="password" name="new_password" id="newPw"
                               class="form-control" placeholder="อย่างน้อย 6 ตัวอักษร" required minlength="6"
                               oninput="checkStrength(this.value)"
                               style="padding-right:44px;">
                        <button type="button" onclick="togglePw('newPw','icon2')"
                                style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text-light);cursor:pointer;">
                            <i class="fas fa-eye" id="icon2"></i>
                        </button>
                    </div>
                    <!-- Password Strength -->
                    <div id="strengthWrap" style="margin-top:8px;display:none;">
                        <div style="height:5px;background:var(--green-pale);border-radius:4px;overflow:hidden;">
                            <div id="strengthBar" style="height:100%;width:0;border-radius:4px;transition:all .3s;"></div>
                        </div>
                        <div style="display:flex;justify-content:space-between;margin-top:5px;">
                            <span id="strengthLabel" style="font-size:12px;font-weight:600;"></span>
                            <span id="strengthTips" style="font-size:11px;color:var(--text-light);"></span>
                        </div>
                    </div>
                </div>

                <!-- ยืนยันรหัสผ่านใหม่ -->
                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-lock" style="color:var(--green-sage)"></i> ยืนยันรหัสผ่านใหม่
                    </label>
                    <div style="position:relative;">
                        <input type="password" name="confirm_password" id="confirmPw"
                               class="form-control" placeholder="••••••••" required
                               oninput="checkMatch()"
                               style="padding-right:44px;">
                        <button type="button" onclick="togglePw('confirmPw','icon3')"
                                style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text-light);cursor:pointer;">
                            <i class="fas fa-eye" id="icon3"></i>
                        </button>
                    </div>
                    <div id="matchMsg" style="font-size:12px;margin-top:5px;display:none;"></div>
                </div>

                <!-- Tips -->
                <div style="background:var(--green-cream);border-radius:var(--radius-md);padding:14px 16px;margin-bottom:24px;font-size:13px;color:var(--text-mid);">
                    <div style="font-weight:600;margin-bottom:6px;color:var(--green-deep);">
                        <i class="fas fa-shield-alt"></i> เคล็ดลับรหัสผ่านที่ดี
                    </div>
                    <ul style="list-style:none;display:flex;flex-direction:column;gap:4px;">
                        <li id="tip_len"  style="color:#ccc;"><i class="fas fa-circle" style="font-size:6px;margin-right:6px;"></i> อย่างน้อย 6 ตัวอักษร</li>
                        <li id="tip_upper" style="color:#ccc;"><i class="fas fa-circle" style="font-size:6px;margin-right:6px;"></i> มีตัวพิมพ์ใหญ่ (A-Z)</li>
                        <li id="tip_num"  style="color:#ccc;"><i class="fas fa-circle" style="font-size:6px;margin-right:6px;"></i> มีตัวเลข (0-9)</li>
                        <li id="tip_sym"  style="color:#ccc;"><i class="fas fa-circle" style="font-size:6px;margin-right:6px;"></i> มีอักขระพิเศษ (!@#$)</li>
                    </ul>
                </div>

                <div style="display:flex;gap:12px;">
                    <button type="submit" class="btn btn-primary btn-lg" style="flex:1;">
                        <i class="fas fa-save"></i> บันทึกรหัสผ่านใหม่
                    </button>
                    <a href="profile.php" class="btn btn-outline btn-lg">
                        ยกเลิก
                    </a>
                </div>

            </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- Link กลับโปรไฟล์ -->
    <?php if (!$isSocialLogin): ?>
    <div style="text-align:center;margin-top:16px;font-size:14px;color:var(--text-light);">
        <a href="profile.php" style="color:var(--green-deep);">
            <i class="fas fa-arrow-left"></i> กลับหน้าโปรไฟล์
        </a>
    </div>
    <?php endif; ?>

</div>

<footer class="footer">
    <div class="footer-bottom">&copy; <?= date('Y') ?> <?= SITE_NAME ?></div>
</footer>

<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>
// Toggle show/hide password
function togglePw(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon  = document.getElementById(iconId);
    input.type  = input.type === 'password' ? 'text' : 'password';
    icon.className = input.type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
}

// Password strength checker
function checkStrength(val) {
    const wrap  = document.getElementById('strengthWrap');
    const bar   = document.getElementById('strengthBar');
    const label = document.getElementById('strengthLabel');
    const tips  = document.getElementById('strengthTips');

    wrap.style.display = val ? 'block' : 'none';
    if (!val) return;

    let score = 0;
    const checks = {
        tip_len:   val.length >= 6,
        tip_upper: /[A-Z]/.test(val),
        tip_num:   /[0-9]/.test(val),
        tip_sym:   /[^a-zA-Z0-9]/.test(val),
    };

    Object.entries(checks).forEach(([id, pass]) => {
        const el = document.getElementById(id);
        el.style.color = pass ? 'var(--green-deep)' : '#ccc';
        el.querySelector('i').className = pass
            ? 'fas fa-check-circle' : 'fas fa-circle';
        el.querySelector('i').style.fontSize = pass ? '10px' : '6px';
        if (pass) score++;
    });

    const levels = [
        { pct: '25%', color: '#e74c3c', text: 'อ่อนมาก',  tip: 'ควรเพิ่มความซับซ้อน' },
        { pct: '50%', color: '#e67e22', text: 'อ่อน',     tip: 'ลองเพิ่มตัวเลขหรืออักษรใหญ่' },
        { pct: '75%', color: '#f1c40f', text: 'ปานกลาง',  tip: 'เกือบดีแล้ว!' },
        { pct: '100%',color: 'var(--green-deep)', text: 'แข็งแรง 💪', tip: 'ยอดเยี่ยม!' },
    ];

    const lvl = levels[score - 1] || levels[0];
    bar.style.width    = lvl.pct;
    bar.style.background = lvl.color;
    label.textContent  = lvl.text;
    label.style.color  = lvl.color;
    tips.textContent   = lvl.tip;
}

// Check password match
function checkMatch() {
    const newPw    = document.getElementById('newPw').value;
    const confirmPw = document.getElementById('confirmPw').value;
    const msg      = document.getElementById('matchMsg');

    if (!confirmPw) { msg.style.display = 'none'; return; }

    msg.style.display = 'block';
    if (newPw === confirmPw) {
        msg.innerHTML = '<i class="fas fa-check-circle" style="color:var(--green-deep)"></i> <span style="color:var(--green-deep)">รหัสผ่านตรงกัน</span>';
        document.getElementById('confirmPw').style.borderColor = 'var(--green-sage)';
    } else {
        msg.innerHTML = '<i class="fas fa-times-circle" style="color:#e74c3c"></i> <span style="color:#e74c3c">รหัสผ่านไม่ตรงกัน</span>';
        document.getElementById('confirmPw').style.borderColor = '#e74c3c';
    }
}

// Prevent submit if passwords don't match
document.getElementById('changePasswordForm')?.addEventListener('submit', function(e) {
    const newPw     = document.getElementById('newPw').value;
    const confirmPw = document.getElementById('confirmPw').value;
    if (newPw !== confirmPw) {
        e.preventDefault();
        showToast('รหัสผ่านใหม่ไม่ตรงกัน กรุณาตรวจสอบอีกครั้ง', 'error');
    }
});
</script>
</body>
</html>
