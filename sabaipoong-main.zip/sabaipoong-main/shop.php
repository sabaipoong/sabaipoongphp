<?php
define('INCLUDED', true);
require_once 'config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$isLoggedIn = isset($_SESSION['user_id']);

$pageTitle = 'สินค้าทั้งหมด';
$pdo = getDB();

// --- รับค่า Filter ---
$search    = trim($_GET['q'] ?? '');
$catId     = (int)($_GET['cat'] ?? 0);
$sort      = $_GET['sort'] ?? 'newest';
$minPrice  = (float)($_GET['min_price'] ?? 0);
$maxPrice  = (float)($_GET['max_price'] ?? 99999);
$page      = max(1, (int)($_GET['page'] ?? 1));
$perPage   = 12;
$offset    = ($page - 1) * $perPage;

// --- Query สินค้า ---
$where  = ["p.is_active = 1"];
$params = [];

if ($search) {
    $where[]  = "(p.name LIKE ? OR p.description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($catId) {
    $where[]  = "p.category_id = ?";
    $params[] = $catId;
}
if ($minPrice > 0) {
    $where[]  = "p.price >= ?";
    $params[] = $minPrice;
}
if ($maxPrice < 99999) {
    $where[]  = "p.price <= ?";
    $params[] = $maxPrice;
}

$orderBy = match($sort) {
    'price_asc'  => "p.price ASC",
    'price_desc' => "p.price DESC",
    'popular'    => "p.sold_count DESC",
    'rating'     => "p.sold_count DESC",
    default      => "p.created_at DESC",
};

$whereSQL = implode(' AND ', $where);

// นับทั้งหมด
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM products p WHERE $whereSQL");
$countStmt->execute($params);
$totalItems = (int)$countStmt->fetchColumn();
$totalPages = max(1, ceil($totalItems / $perPage));

// ดึงสินค้า
$stmt = $pdo->prepare("
    SELECT p.*, c.name AS cat_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE $whereSQL
    ORDER BY $orderBy
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$products = $stmt->fetchAll();

// หมวดหมู่
$cats = $pdo->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY name")->fetchAll();

// ราคา min/max สำหรับ slider
$priceRange = $pdo->query("SELECT MIN(price) AS min_p, MAX(price) AS max_p FROM products WHERE is_active = 1")->fetch();
?>
<?php include 'navbar.php'; ?>

<!-- Shop Header -->
<div style="background:var(--gradient-main);padding:36px 24px 28px;text-align:center;color:white;">
    <h1 style="font-size:1.8rem;font-weight:900;margin-bottom:8px;">🛍️ สินค้าทั้งหมด</h1>
    <p style="opacity:.85;font-size:15px;">คัดสรรสินค้าคุณภาพเพื่อสุขภาพที่ดีของคุณ</p>

    <!-- Search Bar -->
    <form method="GET" style="max-width:500px;margin:20px auto 0;display:flex;gap:0;">
        <input type="text" name="q" value="<?= sanitize($search) ?>"
               placeholder="ค้นหาสินค้า..."
               style="flex:1;padding:13px 20px;border:none;border-radius:50px 0 0 50px;font-size:15px;font-family:inherit;outline:none;">
        <?php if ($catId): ?>
        <input type="hidden" name="cat" value="<?= $catId ?>">
        <?php endif; ?>
        <button type="submit"
                style="padding:13px 24px;background:var(--text-dark);color:white;border:none;border-radius:0 50px 50px 0;font-size:15px;cursor:pointer;font-family:inherit;font-weight:600;">
            <i class="fas fa-search"></i>
        </button>
    </form>
</div>

<div class="main-content" style="padding-top:32px;">
    <div style="display:grid;grid-template-columns:240px 1fr;gap:28px;align-items:start;">

        <!-- ===== SIDEBAR FILTER ===== -->
        <aside style="background:white;border-radius:var(--radius-lg);box-shadow:var(--shadow-card);border:1px solid var(--green-pale);padding:24px;position:sticky;top:90px;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
                <h3 style="font-size:15px;font-weight:700;"><i class="fas fa-filter" style="color:var(--green-sage)"></i> กรองสินค้า</h3>
                <?php if ($catId || $search || $minPrice > 0 || $sort !== 'newest'): ?>
                <a href="shop.php" style="font-size:12px;color:#e74c3c;"><i class="fas fa-times"></i> ล้างทั้งหมด</a>
                <?php endif; ?>
            </div>

            <!-- หมวดหมู่ -->
            <div style="margin-bottom:24px;">
                <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--text-light);margin-bottom:10px;">หมวดหมู่</div>
                <a href="shop.php?<?= http_build_query(array_merge($_GET, ['cat' => 0, 'page' => 1])) ?>"
                   style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-radius:var(--radius-sm);font-size:14px;color:<?= !$catId ? 'var(--green-deep)' : 'var(--text-mid)' ?>;background:<?= !$catId ? 'var(--green-pale)' : 'transparent' ?>;font-weight:<?= !$catId ? '700' : '400' ?>;margin-bottom:4px;text-decoration:none;transition:all .2s;">
                    <span>ทั้งหมด</span>
                    <span style="font-size:12px;color:var(--text-light)"><?= $totalItems ?></span>
                </a>
                <?php foreach ($cats as $cat):
                    $catCount = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id = ? AND is_active = 1");
                    $catCount->execute([$cat['id']]);
                    $catCount = $catCount->fetchColumn();
                ?>
                <a href="shop.php?<?= http_build_query(array_merge($_GET, ['cat' => $cat['id'], 'page' => 1])) ?>"
                   style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-radius:var(--radius-sm);font-size:14px;color:<?= $catId == $cat['id'] ? 'var(--green-deep)' : 'var(--text-mid)' ?>;background:<?= $catId == $cat['id'] ? 'var(--green-pale)' : 'transparent' ?>;font-weight:<?= $catId == $cat['id'] ? '700' : '400' ?>;margin-bottom:4px;text-decoration:none;transition:all .2s;">
                    <span><?= sanitize($cat['name']) ?></span>
                    <span style="font-size:12px;color:var(--text-light)"><?= $catCount ?></span>
                </a>
                <?php endforeach; ?>
            </div>

            <!-- ราคา -->
            <div style="margin-bottom:24px;">
                <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--text-light);margin-bottom:10px;">ช่วงราคา</div>
                <form method="GET" id="priceForm">
                    <?php if ($catId): ?><input type="hidden" name="cat" value="<?= $catId ?>"><?php endif; ?>
                    <?php if ($search): ?><input type="hidden" name="q" value="<?= sanitize($search) ?>"><?php endif; ?>
                    <input type="hidden" name="sort" value="<?= sanitize($sort) ?>">
                    <div style="display:flex;gap:8px;align-items:center;margin-bottom:12px;">
                        <input type="number" name="min_price" id="minPrice" value="<?= $minPrice ?: '' ?>"
                               placeholder="ต่ำสุด" min="0"
                               style="width:50%;padding:8px 10px;border:2px solid var(--green-pale);border-radius:var(--radius-sm);font-size:13px;font-family:inherit;outline:none;">
                        <span style="color:var(--text-light)">-</span>
                        <input type="number" name="max_price" id="maxPrice" value="<?= $maxPrice < 99999 ? $maxPrice : '' ?>"
                               placeholder="สูงสุด" min="0"
                               style="width:50%;padding:8px 10px;border:2px solid var(--green-pale);border-radius:var(--radius-sm);font-size:13px;font-family:inherit;outline:none;">
                    </div>
                    <button type="submit" style="width:100%;padding:9px;background:var(--gradient-main);color:white;border:none;border-radius:var(--radius-sm);font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;">
                        กรองราคา
                    </button>
                </form>
            </div>

            <!-- เรียงลำดับ (mobile hidden, shown in sidebar) -->
            <div>
                <div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--text-light);margin-bottom:10px;">เรียงตาม</div>
                <?php
                $sortOptions = [
                    'newest'     => 'ใหม่ล่าสุด',
                    'popular'    => 'ขายดีที่สุด',
                    'price_asc'  => 'ราคาต่ำ → สูง',
                    'price_desc' => 'ราคาสูง → ต่ำ',
                ];
                foreach ($sortOptions as $val => $label): ?>
                <a href="shop.php?<?= http_build_query(array_merge($_GET, ['sort' => $val, 'page' => 1])) ?>"
                   style="display:block;padding:8px 12px;border-radius:var(--radius-sm);font-size:14px;color:<?= $sort === $val ? 'var(--green-deep)' : 'var(--text-mid)' ?>;background:<?= $sort === $val ? 'var(--green-pale)' : 'transparent' ?>;font-weight:<?= $sort === $val ? '700' : '400' ?>;margin-bottom:4px;text-decoration:none;transition:all .2s;">
                    <?= $label ?>
                </a>
                <?php endforeach; ?>
            </div>
        </aside>

        <!-- ===== PRODUCTS AREA ===== -->
        <div>
            <!-- Toolbar -->
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:12px;">
                <div style="font-size:14px;color:var(--text-light);">
                    <?php if ($search): ?>
                    ผลการค้นหา "<strong style="color:var(--text-dark)"><?= sanitize($search) ?></strong>" —
                    <?php endif; ?>
                    พบ <strong style="color:var(--green-deep)"><?= $totalItems ?></strong> รายการ
                </div>

                <!-- Active Filters -->
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    <?php if ($search): ?>
                    <span style="background:var(--green-pale);color:var(--green-deep);padding:4px 12px;border-radius:50px;font-size:12px;font-weight:600;">
                        🔍 <?= sanitize($search) ?>
                        <a href="shop.php?<?= http_build_query(array_merge($_GET, ['q' => '', 'page' => 1])) ?>" style="color:var(--green-deep);margin-left:4px;">×</a>
                    </span>
                    <?php endif; ?>
                    <?php if ($catId): ?>
                    <?php $activeCat = array_filter($cats, fn($c) => $c['id'] == $catId); $activeCat = reset($activeCat); ?>
                    <span style="background:var(--green-pale);color:var(--green-deep);padding:4px 12px;border-radius:50px;font-size:12px;font-weight:600;">
                        📦 <?= sanitize($activeCat['name'] ?? '') ?>
                        <a href="shop.php?<?= http_build_query(array_merge($_GET, ['cat' => 0, 'page' => 1])) ?>" style="color:var(--green-deep);margin-left:4px;">×</a>
                    </span>
                    <?php endif; ?>
                </div>

                <!-- Sort (desktop quick) -->
                <select onchange="location.href=this.value"
                        style="padding:8px 14px;border:2px solid var(--green-pale);border-radius:var(--radius-sm);font-size:13px;font-family:inherit;color:var(--text-mid);outline:none;cursor:pointer;">
                    <?php foreach ($sortOptions as $val => $label): ?>
                    <option value="shop.php?<?= http_build_query(array_merge($_GET, ['sort' => $val, 'page' => 1])) ?>"
                            <?= $sort === $val ? 'selected' : '' ?>><?= $label ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Products Grid -->
            <?php if (empty($products)): ?>
            <div style="text-align:center;padding:80px 20px;background:white;border-radius:var(--radius-lg);box-shadow:var(--shadow-card);">
                <div style="font-size:56px;margin-bottom:16px;">🔍</div>
                <h3 style="color:var(--text-light);margin-bottom:12px;">ไม่พบสินค้าที่ค้นหา</h3>
                <p style="font-size:14px;color:var(--text-light);margin-bottom:20px;">ลองเปลี่ยนคำค้นหาหรือปรับตัวกรองใหม่</p>
                <a href="shop.php" class="btn btn-primary">ดูสินค้าทั้งหมด</a>
            </div>
            <?php else: ?>
            <div class="products-grid">
                <?php foreach ($products as $p): ?>
                <?php include 'partials/product_card.php'; ?>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
            <div style="display:flex;justify-content:center;align-items:center;gap:8px;margin-top:40px;flex-wrap:wrap;">
                <?php if ($page > 1): ?>
                <a href="shop.php?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>"
                   style="padding:10px 16px;border:2px solid var(--green-pale);border-radius:var(--radius-sm);font-size:14px;color:var(--text-mid);text-decoration:none;transition:all .2s;"
                   onmouseover="this.style.borderColor='var(--green-deep)'" onmouseout="this.style.borderColor='var(--green-pale)'">
                    <i class="fas fa-chevron-left"></i>
                </a>
                <?php endif; ?>

                <?php
                $start = max(1, $page - 2);
                $end   = min($totalPages, $page + 2);
                for ($i = $start; $i <= $end; $i++):
                ?>
                <a href="shop.php?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"
                   style="padding:10px 16px;border:2px solid <?= $i === $page ? 'var(--green-deep)' : 'var(--green-pale)' ?>;border-radius:var(--radius-sm);font-size:14px;font-weight:<?= $i === $page ? '700' : '400' ?>;color:<?= $i === $page ? 'white' : 'var(--text-mid)' ?>;background:<?= $i === $page ? 'var(--green-deep)' : 'white' ?>;text-decoration:none;transition:all .2s;">
                    <?= $i ?>
                </a>
                <?php endfor; ?>

                <?php if ($page < $totalPages): ?>
                <a href="shop.php?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>"
                   style="padding:10px 16px;border:2px solid var(--green-pale);border-radius:var(--radius-sm);font-size:14px;color:var(--text-mid);text-decoration:none;transition:all .2s;"
                   onmouseover="this.style.borderColor='var(--green-deep)'" onmouseout="this.style.borderColor='var(--green-pale)'">
                    <i class="fas fa-chevron-right"></i>
                </a>
                <?php endif; ?>

                <span style="font-size:13px;color:var(--text-light);margin-left:8px;">
                    หน้า <?= $page ?> / <?= $totalPages ?>
                </span>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>
    var isLoggedIn = <?= $isLoggedIn ? 'true' : 'false' ?>;

    // ดักคลิกปุ่มเพิ่มตะกร้า — ถ้ายังไม่ล็อกอินให้ redirect ไป login
    document.addEventListener('click', function(e) {
        var btn = e.target.closest('[data-action="add-to-cart"], .btn-add-cart, button[onclick*="addToCart"], button[onclick*="cart"]');
        if (btn && !isLoggedIn) {
            e.preventDefault();
            e.stopImmediatePropagation();
            window.location.href = 'login.php';
        }
    }, true);

    // wrap addToCart หลังจาก main.js โหลดแล้ว เพื่อให้ original มีค่าถูกต้อง
    var _originalAddToCart = window.addToCart;
    window.addToCart = function() {
        if (!isLoggedIn) {
            window.location.href = 'login.php';
            return;
        }
        if (typeof _originalAddToCart === 'function') {
            return _originalAddToCart.apply(this, arguments);
        }
    };
</script>
</body>
</html>
