<?php
// auth/google_callback.php
require_once '../config.php';

$code = $_GET['code'] ?? '';
if (!$code) { header('Location: ' . SITE_URL . '/login.php?error=no_code'); exit; }

// Exchange code for token
$tokenResponse = file_get_contents('https://oauth2.googleapis.com/token', false, stream_context_create([
    'http' => [
        'method' => 'POST',
        'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content' => http_build_query([
            'code'          => $code,
            'client_id'     => GOOGLE_CLIENT_ID,
            'client_secret' => GOOGLE_CLIENT_SECRET,
            'redirect_uri'  => GOOGLE_REDIRECT_URI,
            'grant_type'    => 'authorization_code',
        ]),
    ],
]));

$tokenData = json_decode($tokenResponse, true);
if (empty($tokenData['access_token'])) { header('Location: ' . SITE_URL . '/login.php?error=token_failed'); exit; }

// Get user info
$userInfo = json_decode(file_get_contents('https://www.googleapis.com/oauth2/v2/userinfo?access_token=' . $tokenData['access_token']), true);
if (empty($userInfo['email'])) { header('Location: ' . SITE_URL . '/login.php?error=no_email'); exit; }

$pdo = getDB();
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$userInfo['email']]);
$user = $stmt->fetch();

if (!$user) {
    // สร้างบัญชีใหม่
    $pdo->prepare("INSERT INTO users (username, email, full_name, profile_image, role, login_type, social_id) VALUES (?,?,?,?,'user','google',?)")
        ->execute([
            explode('@', $userInfo['email'])[0],
            $userInfo['email'],
            $userInfo['name'] ?? '',
            $userInfo['picture'] ?? '',
            $userInfo['id'] ?? ''
        ]);
    $stmt->execute([$userInfo['email']]);
    $user = $stmt->fetch();
}

$_SESSION['user_id']       = $user['id'];
$_SESSION['username']      = $user['full_name'] ?? $user['username'];
$_SESSION['email']         = $user['email'];
$_SESSION['role']          = $user['role'];
$_SESSION['profile_image'] = $user['profile_image'];
$_SESSION['points']        = $user['points'];
$_SESSION['flash']         = ['message' => 'ยินดีต้อนรับ ' . ($user['full_name'] ?? ''), 'type' => 'success'];

header('Location: ' . SITE_URL . '/index.php');
exit;
