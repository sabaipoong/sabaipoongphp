<?php
// auth/line_callback.php
require_once '../config.php';

$code = $_GET['code'] ?? '';
if (!$code) { header('Location: ' . SITE_URL . '/login.php?error=no_code'); exit; }

// Exchange token
$ch = curl_init('https://api.line.me/oauth2/v2.1/token');
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => http_build_query([
        'grant_type'    => 'authorization_code',
        'code'          => $code,
        'redirect_uri'  => LINE_REDIRECT_URI,
        'client_id'     => LINE_CHANNEL_ID,
        'client_secret' => LINE_CHANNEL_SECRET,
    ]),
    CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
]);
$tokenData = json_decode(curl_exec($ch), true);
curl_close($ch);

if (empty($tokenData['access_token'])) { header('Location: ' . SITE_URL . '/login.php?error=token_failed'); exit; }

// Get profile
$ch = curl_init('https://api.line.me/v2/profile');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $tokenData['access_token']],
]);
$profile = json_decode(curl_exec($ch), true);
curl_close($ch);

if (empty($profile['userId'])) { header('Location: ' . SITE_URL . '/login.php?error=no_profile'); exit; }

// Get email from ID token if available
$email = null;
if (!empty($tokenData['id_token'])) {
    $parts = explode('.', $tokenData['id_token']);
    if (count($parts) === 3) {
        $payload = json_decode(base64_decode(str_pad(strtr($parts[1], '-_', '+/'), strlen($parts[1]) % 4, '=', STR_PAD_RIGHT)), true);
        $email = $payload['email'] ?? null;
    }
}

$pdo = getDB();

if ($email) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR (social_id = ? AND login_type = 'line')");
    $stmt->execute([$email, $profile['userId']]);
} else {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE social_id = ? AND login_type = 'line'");
    $stmt->execute([$profile['userId']]);
}

$user = $stmt->fetch();

if (!$user) {
    $newEmail = $email ?? ('line_' . $profile['userId'] . '@line.local');
    $pdo->prepare("INSERT INTO users (username, email, full_name, profile_image, role, login_type, social_id) VALUES (?,?,?,?,'user','line',?)")
        ->execute([$profile['displayName'] ?? 'LINE User', $newEmail, $profile['displayName'] ?? '', $profile['pictureUrl'] ?? '', $profile['userId']]);

    if ($email) { $stmt->execute([$email, $profile['userId']]); }
    else { $stmt->execute([$profile['userId']]); }
    $user = $stmt->fetch();
}

$_SESSION['user_id']       = $user['id'];
$_SESSION['username']      = $user['full_name'] ?? $user['username'];
$_SESSION['email']         = $user['email'];
$_SESSION['role']          = $user['role'];
$_SESSION['profile_image'] = $user['profile_image'];
$_SESSION['points']        = $user['points'];
$_SESSION['flash']         = ['message' => 'ยินดีต้อนรับ ' . ($user['full_name'] ?? ''), 'type' => 'success'];

header('Location: ' . SITE_URL . '/index.php');
exit;
