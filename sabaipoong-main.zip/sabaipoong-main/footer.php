<?php
if (!defined('INCLUDED')) {
    http_response_code(403);
    exit('Access denied');
}
?>

<!-- Footer -->
<footer class="footer">
    <div class="footer-inner">
        <div class="footer-brand">
            <h3>🌿 <?= SITE_NAME ?></h3>
            <p>อาหารเพื่อสุขภาพคุณภาพดี<br>ส่งตรงถึงมือคุณทุกวัน</p>
        </div>
        <div class="footer-col">
            <h4>เมนู</h4>
            <a href="index.php">หน้าแรก</a>
            <a href="shop.php">สินค้า</a>
        </div>
        <div class="footer-col">
            <h4>บัญชี</h4>
            <a href="login.php">เข้าสู่ระบบ</a>
            <a href="register.php">สมัครสมาชิก</a>
            <a href="orders.php">คำสั่งซื้อ</a>
        </div>
        <div class="footer-col">
            <h4>ติดต่อ</h4>
            <a href="https://lin.ee/7X2cT0X" target="_blank" rel="noopener noreferrer"><i class="fab fa-line"></i> LINE</a>
            <a href="#"><i class="fab fa-facebook"></i> Facebook</a>
            <a href="#"><i class="fas fa-envelope"></i> Email</a>
        </div>
    </div>
    <div class="footer-bottom">
        &copy; <?= date('Y') ?> <?= SITE_NAME ?> — All rights reserved.
    </div>
</footer>
