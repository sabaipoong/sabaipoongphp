<?php
define('INCLUDED', true);
require_once 'config.php';
requireLogin();

$pdo = getDB();
$userId = $_SESSION['user_id'];
$pageTitle = 'คำสั่งซื้อของฉัน';

$orders = $pdo->prepare("
    SELECT o.*,
           (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) AS item_count
    FROM orders o
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
");
$orders->execute([$userId]);
$orders = $orders->fetchAll();
?>
<?php include 'navbar.php'; ?>

<div class="main-content" style="max-width:860px;margin:0 auto;padding-top:40px;">
    <h1 style="font-size:1.4rem;font-weight:800;margin-bottom:24px;">🛍️ คำสั่งซื้อของฉัน</h1>

    <?php if (empty($orders)): ?>
    <div style="text-align:center;padding:80px;background:white;border-radius:var(--radius-lg);box-shadow:var(--shadow-card)">
        <div style="font-size:56px;margin-bottom:16px">📦</div>
        <h2 style="color:var(--text-light);margin-bottom:16px">ยังไม่มีคำสั่งซื้อ</h2>
        <a href="shop.php" class="btn btn-primary btn-lg">เริ่มช้อปปิ้ง</a>
    </div>
    <?php else: ?>

    <?php foreach ($orders as $order):
        $statusLabel = ['pending'=>'รอดำเนินการ','confirmed'=>'ยืนยันแล้ว','shipping'=>'กำลังจัดส่ง','delivered'=>'ส่งสำเร็จ','cancelled'=>'ยกเลิก'][$order['status']] ?? $order['status'];
        $badgeClass  = ['pending'=>'badge-warning','confirmed'=>'badge-info','shipping'=>'badge-info','delivered'=>'badge-success','cancelled'=>'badge-danger'][$order['status']] ?? 'badge-info';

        // ดึงรายการสินค้า
        $items = $pdo->prepare("SELECT oi.*, p.image FROM order_items oi LEFT JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
        $items->execute([$order['id']]);
        $items = $items->fetchAll();
    ?>
    <div style="background:white;border-radius:var(--radius-lg);box-shadow:var(--shadow-card);border:1px solid var(--green-pale);margin-bottom:20px;overflow:hidden">
        <!-- Order Header -->
        <div style="display:flex;justify-content:space-between;align-items:center;padding:16px 22px;border-bottom:1px solid var(--green-pale);flex-wrap:wrap;gap:10px">
            <div>
                <div style="font-size:13px;color:var(--text-light)">เลขที่คำสั่งซื้อ</div>
                <div style="font-weight:700;font-size:15px"><?= sanitize($order['order_number']) ?></div>
            </div>
            <div style="text-align:center">
                <div style="font-size:13px;color:var(--text-light)">วันที่สั่ง</div>
                <div style="font-weight:600"><?= formatDate($order['created_at']) ?></div>
            </div>
            <div style="text-align:center">
                <div style="font-size:13px;color:var(--text-light)">ยอดรวม</div>
                <div style="font-weight:700;color:var(--green-deep)">฿<?= number_format($order['final_price'],2) ?></div>
            </div>
            <span class="badge <?= $badgeClass ?>" style="font-size:13px;padding:6px 14px"><?= $statusLabel ?></span>
        </div>

        <!-- Order Items -->
        <div style="padding:16px 22px">
            <?php foreach ($items as $item): ?>
            <div style="display:flex;align-items:center;gap:14px;padding:10px 0;border-bottom:1px solid var(--green-pale)">
                <img src="<?= $item['image'] ? SITE_URL . '/' . sanitize($item['image']) : SITE_URL . '/img/no-image.png' ?>"
                     style="width:54px;height:54px;border-radius:var(--radius-sm);object-fit:cover;border:1px solid var(--green-pale)"
                     onerror="this.src='<?= SITE_URL ?>/img/no-image.png'">
                <div style="flex:1">
                    <div style="font-weight:600;font-size:14px"><?= sanitize($item['product_name']) ?></div>
                    <div style="font-size:13px;color:var(--text-light)">
                        <?= $item['quantity'] ?> x ฿<?= number_format($item['price'],2) ?>
                    </div>
                </div>
                <div style="font-weight:700;color:var(--green-deep)">฿<?= number_format($item['subtotal'],2) ?></div>

                <?php if ($order['status'] === 'delivered'): ?>
                <a href="review.php?product_id=<?= $item['product_id'] ?>&order_id=<?= $order['id'] ?>"
                   class="btn btn-outline btn-sm">
                    <i class="fas fa-star"></i> รีวิว
                </a>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Tracking -->
        <?php if ($order['tracking_number']): ?>
        <div style="background:var(--green-cream);padding:12px 22px;font-size:13px;color:var(--green-deep)">
            <i class="fas fa-truck"></i> เลขพัสดุ: <strong><?= sanitize($order['tracking_number']) ?></strong>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
</div>

<footer class="footer" style="margin-top:40px"><div class="footer-bottom">&copy; <?= date('Y') ?> <?= SITE_NAME ?></div></footer>
<script src="<?= SITE_URL ?>/js/main.js"></script>
</body>
</html>
