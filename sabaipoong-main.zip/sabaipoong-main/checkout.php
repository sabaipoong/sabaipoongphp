<?php
define('INCLUDED', true);
require_once 'config.php';
requireLogin();

$pdo = getDB();
$userId = $_SESSION['user_id'];
$pageTitle = 'ชำระเงิน';

// ดึงข้อมูลตะกร้า
$stmt = $pdo->prepare("
    SELECT c.id AS cart_id, c.quantity, p.id AS product_id, p.name, p.price, p.stock, p.unit, p.image
    FROM cart c JOIN products p ON c.product_id = p.id
    WHERE c.user_id = ? AND p.is_active = 1
");
$stmt->execute([$userId]);
$items = $stmt->fetchAll();

if (empty($items)) { header('Location: cart.php'); exit; }

$user = $pdo->prepare("SELECT * FROM users WHERE id=?");
$user->execute([$userId]);
$user = $user->fetch();

$subtotal = array_sum(array_map(fn($i) => $i['price'] * $i['quantity'], $items));
$shipping = $subtotal >= 500 ? 0 : 50;
$final = $subtotal + $shipping;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction();

        // ตรวจสต็อก
        foreach ($items as $item) {
            $stock = $pdo->prepare("SELECT stock FROM products WHERE id = ? FOR UPDATE");
            $stock->execute([$item['product_id']]);
            $currentStock = (int)$stock->fetchColumn();
            if ($currentStock < $item['quantity']) {
                throw new Exception("สินค้า '{$item['name']}' มีสต็อกไม่เพียงพอ (เหลือ {$currentStock} {$item['unit']})");
            }
        }

        // สร้างออเดอร์
        $orderNum = generateOrderNumber();
        $address = implode(' ', array_filter([
            $user['address'], $user['subdistrict'], $user['district'], $user['province'], $user['zipcode']
        ]));
        $pdo->prepare("INSERT INTO orders (order_number, user_id, total_price, shipping_fee, final_price, points_earned, shipping_address, payment_method) VALUES (?,?,?,?,?,?,?,?)")
            ->execute([$orderNum, $userId, $subtotal, $shipping, $final, array_sum(array_column($items, 'quantity')), $address, $_POST['payment_method'] ?? 'cod']);

        $orderId = $pdo->lastInsertId();

        // เพิ่ม order_items + ตัดสต็อก
        $totalPoints = 0;
        foreach ($items as $item) {
            $sub = $item['price'] * $item['quantity'];
            $pdo->prepare("INSERT INTO order_items (order_id, product_id, product_name, price, quantity, subtotal) VALUES (?,?,?,?,?,?)")
                ->execute([$orderId, $item['product_id'], $item['name'], $item['price'], $item['quantity'], $sub]);

            // ตัดสต็อกอัตโนมัติ ✅
            $pdo->prepare("UPDATE products SET stock = stock - ?, sold_count = sold_count + ? WHERE id = ?")
                ->execute([$item['quantity'], $item['quantity'], $item['product_id']]);

            $totalPoints += $item['quantity'] * POINTS_PER_ITEM;
        }

        // ให้คะแนน
        $pdo->prepare("UPDATE users SET points = points + ? WHERE id=?")->execute([$totalPoints, $userId]);
        $pdo->prepare("UPDATE orders SET points_earned = ? WHERE id=?")->execute([$totalPoints, $orderId]);
        $pdo->prepare("INSERT INTO points_history (user_id, order_id, points_change, type, description) VALUES (?,?,?,'earn',?)")
            ->execute([$userId, $orderId, $totalPoints, 'ซื้อสินค้าคำสั่ง ' . $orderNum]);
        $_SESSION['points'] = ($_SESSION['points'] ?? 0) + $totalPoints;

        // ล้างตะกร้า
        $pdo->prepare("DELETE FROM cart WHERE user_id=?")->execute([$userId]);

        $pdo->commit();
        $_SESSION['flash'] = ['message' => "สั่งซื้อสำเร็จ! ได้รับ {$totalPoints} คะแนน 🎉", 'type' => 'success'];
        header("Location: orders.php");
        exit;

    } catch (Exception $e) {
        $pdo->rollBack();
        $checkoutError = $e->getMessage();
    }
}
?>
<?php include 'navbar.php'; ?>

<div class="main-content" style="max-width:900px;margin:0 auto;padding-top:40px;">
    <h1 style="font-size:1.4rem;font-weight:800;margin-bottom:28px">💳 ยืนยันการสั่งซื้อ</h1>

    <?php if (isset($checkoutError)): ?>
    <div class="alert alert-error" style="margin-bottom:20px"><i class="fas fa-exclamation-circle"></i> <?= sanitize($checkoutError) ?></div>
    <?php endif; ?>

    <form method="POST">
    <div style="display:grid;grid-template-columns:1fr 340px;gap:24px;align-items:start">
        <div>
            <!-- ที่อยู่จัดส่ง -->
            <div style="background:white;border-radius:var(--radius-lg);padding:24px;box-shadow:var(--shadow-card);border:1px solid var(--green-pale);margin-bottom:20px">
                <h3 style="font-size:1rem;font-weight:700;margin-bottom:16px"><i class="fas fa-map-marker-alt" style="color:var(--green-sage)"></i> ที่อยู่จัดส่ง</h3>
                <p style="font-size:14px;margin-bottom:4px"><strong><?= sanitize($user['full_name'] ?? '') ?></strong> <?= sanitize($user['phone'] ?? '') ?></p>
                <p style="font-size:14px;color:var(--text-light)">
                    <?= sanitize(implode(' ', array_filter([$user['address'],$user['subdistrict'],$user['district'],$user['province'],$user['zipcode']]))) ?: 'ยังไม่ได้กรอกที่อยู่' ?>
                </p>
                <a href="profile.php" style="font-size:13px;color:var(--green-deep)"><i class="fas fa-edit"></i> แก้ไขที่อยู่</a>
            </div>

            <!-- รายการสินค้า -->
            <div style="background:white;border-radius:var(--radius-lg);padding:24px;box-shadow:var(--shadow-card);border:1px solid var(--green-pale);margin-bottom:20px">
                <h3 style="font-size:1rem;font-weight:700;margin-bottom:16px"><i class="fas fa-box" style="color:var(--green-sage)"></i> รายการสินค้า</h3>
                <?php foreach ($items as $item): ?>
                <div style="display:flex;align-items:center;gap:14px;padding:12px 0;border-bottom:1px solid var(--green-pale)">
                    <img src="<?= $item['image'] ? SITE_URL . '/' . sanitize($item['image']) : SITE_URL . '/img/no-image.png' ?>"
                         style="width:56px;height:56px;border-radius:var(--radius-sm);object-fit:cover;border:1px solid var(--green-pale)"
                         onerror="this.src='<?= SITE_URL ?>/img/no-image.png'">
                    <div style="flex:1">
                        <div style="font-weight:600;font-size:14px"><?= sanitize($item['name']) ?></div>
                        <div style="font-size:13px;color:var(--text-light)"><?= $item['quantity'] ?> <?= sanitize($item['unit']) ?> x ฿<?= number_format($item['price'],2) ?></div>
                    </div>
                    <div style="font-weight:700;color:var(--green-deep)">฿<?= number_format($item['price']*$item['quantity'],2) ?></div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- วิธีชำระเงิน -->
            <div style="background:white;border-radius:var(--radius-lg);padding:24px;box-shadow:var(--shadow-card);border:1px solid var(--green-pale)">
                <h3 style="font-size:1rem;font-weight:700;margin-bottom:16px"><i class="fas fa-credit-card" style="color:var(--green-sage)"></i> วิธีชำระเงิน</h3>
                <?php
                $methods = [
                    'cod'       => ['icon'=>'💵','label'=>'เก็บเงินปลายทาง'],
                    'transfer'  => ['icon'=>'🏦','label'=>'โอนเงินผ่านธนาคาร'],
                    'promptpay' => ['icon'=>'📱','label'=>'พร้อมเพย์'],
                ];
                foreach ($methods as $val => $m): ?>
                <label style="display:flex;align-items:center;gap:12px;padding:14px;border:2px solid var(--green-pale);border-radius:var(--radius-md);cursor:pointer;margin-bottom:10px;transition:all .2s" class="payment-option">
                    <input type="radio" name="payment_method" value="<?= $val ?>" <?= $val==='cod'?'checked':'' ?> style="accent-color:var(--green-deep);width:18px;height:18px">
                    <span style="font-size:20px"><?= $m['icon'] ?></span>
                    <span style="font-weight:600"><?= $m['label'] ?></span>
                </label>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Summary -->
        <div class="cart-summary">
            <h3 style="font-size:1rem;font-weight:700;margin-bottom:20px;padding-bottom:14px;border-bottom:2px solid var(--green-pale)">สรุปยอด</h3>
            <div class="summary-row"><span>ราคาสินค้า</span><span>฿<?= number_format($subtotal,2) ?></span></div>
            <div class="summary-row"><span>ค่าจัดส่ง</span><span><?= $shipping > 0 ? '฿'.$shipping : '<span style="color:var(--green-deep);font-weight:700">ฟรี! 🎉</span>' ?></span></div>
            <div class="summary-row" style="color:var(--green-deep);font-size:13px">
                <span>⭐ คะแนนที่จะได้รับ</span>
                <span>+<?= array_sum(array_column($items,'quantity')) ?> คะแนน</span>
            </div>
            <div class="summary-row summary-total"><span>ยอดรวม</span><span>฿<?= number_format($final,2) ?></span></div>
            <button type="submit" class="btn btn-primary btn-full btn-lg" style="margin-top:8px">
                <i class="fas fa-check-circle"></i> ยืนยันสั่งซื้อ
            </button>
            <a href="cart.php" class="btn btn-outline btn-full" style="margin-top:8px">ย้อนกลับ</a>
        </div>
    </div>
    </form>
</div>

<footer class="footer" style="margin-top:60px"><div class="footer-bottom">&copy; <?= date('Y') ?> <?= SITE_NAME ?></div></footer>
<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>
document.querySelectorAll('.payment-option').forEach(opt => {
    opt.querySelector('input').addEventListener('change', () => {
        document.querySelectorAll('.payment-option').forEach(o => o.style.borderColor = 'var(--green-pale)');
        opt.style.borderColor = 'var(--green-deep)';
        opt.style.background = 'var(--green-cream)';
    });
    if (opt.querySelector('input').checked) {
        opt.style.borderColor = 'var(--green-deep)';
        opt.style.background = 'var(--green-cream)';
    }
});
</script>
</body>
</html>
