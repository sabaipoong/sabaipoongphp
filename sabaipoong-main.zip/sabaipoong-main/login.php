<?php
define('INCLUDED', true);
require_once 'config.php';

if (isLoggedIn()) {
    header('Location: ' . SITE_URL . '/index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        $error = 'กรุณากรอกอีเมลและรหัสผ่าน';
    } else {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1 AND login_type = 'email'");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id']      = $user['id'];
            $_SESSION['username']     = $user['username'] ?? $user['full_name'];
            $_SESSION['email']        = $user['email'];
            $_SESSION['role']         = $user['role'];
            $_SESSION['profile_image']= $user['profile_image'];
            $_SESSION['points']       = $user['points'];
            $_SESSION['flash']        = ['message' => 'ยินดีต้อนรับ ' . ($user['full_name'] ?? $user['username']), 'type' => 'success'];

            header('Location: ' . SITE_URL . '/index.php');
            exit;
        } else {
            $error = 'อีเมลหรือรหัสผ่านไม่ถูกต้อง';
        }
    }
}

$googleAuthUrl = "https://accounts.google.com/o/oauth2/v2/auth?response_type=code&client_id=" . GOOGLE_CLIENT_ID
    . "&redirect_uri=" . urlencode(GOOGLE_REDIRECT_URI)
    . "&scope=openid%20email%20profile&state=" . bin2hex(random_bytes(8));

$lineAuthUrl = "https://access.line.me/oauth2/v2.1/authorize?response_type=code&client_id=" . LINE_CHANNEL_ID
    . "&redirect_uri=" . urlencode(LINE_REDIRECT_URI)
    . "&state=" . bin2hex(random_bytes(8))
    . "&scope=profile%20openid%20email";
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เข้าสู่ระบบ - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="auth-logo">
            <a href="<?= SITE_URL ?>">
            <img src="img/Logo.png" alt="<?= SITE_NAME ?>" onerror="this.style.display='none'">
            <h2>🌿 <?= SITE_NAME ?></h2></a>
            <p>เข้าสู่ระบบเพื่อสั่งซื้อสินค้า</p>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?= sanitize($error) ?></div>
        <?php endif; ?>
        <?php if (isset($_GET['registered'])): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> สมัครสมาชิกสำเร็จ! กรุณาเข้าสู่ระบบ</div>
        <?php endif; ?>

        <!-- Social Login -->
        <div class="social-login">
            <a href="<?= $googleAuthUrl ?>" class="btn-social btn-social-google">
                <svg width="22" height="22" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.35-8.16 2.35-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
                เข้าสู่ระบบด้วย Google
            </a>
            <a href="<?= $lineAuthUrl ?>" class="btn-social btn-social-line">
                <svg width="22" height="22" viewBox="0 0 48 48" fill="none"><rect width="48" height="48" rx="10" fill="#00C300"/><path d="M40 22.5C40 16.1 33.7 10.9 26 10.9C18.3 10.9 12 16.1 12 22.5C12 28.2 17.2 33 24.3 34.1L25.2 37.9L28.9 34.8C29.9 34.9 30.9 35 32 35C33.5 35 34.9 34.8 36.2 34.4" fill="none"/><path fill-rule="evenodd" clip-rule="evenodd" d="M40 22.5C40 16.1 33.7 10.9 26 10.9C18.3 10.9 12 16.1 12 22.5C12 28.2 17.2 33 24.3 34.1L25.2 37.9L28.9 34.8C32.7 34.5 36.2 32.9 38.5 30.4C39.5 29.1 40 25.8 40 22.5ZM20 25H18V20H20V25ZM21 20H23V23.5L25.5 20H28L25.5 23L28 25H25.5L23 22V25H21V20ZM30 25H28V20H30V25ZM35 22H33V20H35V22ZM35 25H31V20H33V23H35V25Z" fill="white"/></svg>
                เข้าสู่ระบบด้วย LINE
            </a>
        </div>

        <div class="divider">หรือเข้าสู่ระบบด้วยอีเมล</div>

        <!-- Email Login -->
        <form method="POST">
            <div class="form-group">
                <label class="form-label"><i class="fas fa-envelope"></i> อีเมล</label>
                <input type="email" name="email" class="form-control" placeholder="your@email.com" required value="<?= sanitize($_POST['email'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label class="form-label"><i class="fas fa-lock"></i> รหัสผ่าน</label>
                <div style="position:relative">
                    <input type="password" name="password" class="form-control" placeholder="••••••••" required id="pwInput" style="padding-right:44px">
                    <button type="button" onclick="togglePw()" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text-light);cursor:pointer;" id="pwToggle">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>
            <div style="text-align:right;margin-bottom:18px;font-size:13px;">
                <a href="forgot_password.php" style="color:var(--green-deep);">ลืมรหัสผ่าน?</a>
            </div>
            <button type="submit" class="btn btn-primary btn-full btn-lg">
                <i class="fas fa-sign-in-alt"></i> เข้าสู่ระบบ
            </button>
        </form>

        <div class="auth-footer">
            ยังไม่มีบัญชี? <a href="register.php">สมัครสมาชิกฟรี</a>
        </div>
    </div>
</div>
<script>
function togglePw() {
    const pw = document.getElementById('pwInput');
    const icon = document.getElementById('pwToggle').querySelector('i');
    pw.type = pw.type === 'password' ? 'text' : 'password';
    icon.className = pw.type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
}
</script>
</body>
</html>
