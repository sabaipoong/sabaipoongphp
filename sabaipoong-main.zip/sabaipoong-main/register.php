<?php
define('INCLUDED', true);
require_once 'config.php';

if (isLoggedIn()) {
    header('Location: ' . SITE_URL . '/index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = trim($_POST['full_name'] ?? '');
    $email    = strtolower(trim($_POST['email'] ?? ''));
    $phone    = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (!$fullName || !$email || !$password) {
        $error = 'กรุณากรอกข้อมูลให้ครบถ้วน';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'รูปแบบอีเมลไม่ถูกต้อง';
    } elseif (strlen($password) < 6) {
        $error = 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร';
    } elseif ($password !== $confirm) {
        $error = 'รหัสผ่านไม่ตรงกัน';
    } else {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'อีเมลนี้ถูกใช้งานแล้ว';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $username = explode('@', $email)[0];
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, full_name, phone, role, login_type) VALUES (?,?,?,?,?,'user','email')");
            $stmt->execute([$username, $email, $hash, $fullName, $phone]);
            header('Location: ' . SITE_URL . '/login.php?registered=1');
            exit;
        }
    }
}

$googleAuthUrl = "https://accounts.google.com/o/oauth2/v2/auth?response_type=code&client_id=" . GOOGLE_CLIENT_ID
    . "&redirect_uri=" . urlencode(GOOGLE_REDIRECT_URI)
    . "&scope=openid%20email%20profile&state=register_" . bin2hex(random_bytes(8));

$lineAuthUrl = "https://access.line.me/oauth2/v2.1/authorize?response_type=code&client_id=" . LINE_CHANNEL_ID
    . "&redirect_uri=" . urlencode(LINE_REDIRECT_URI)
    . "&state=register_" . bin2hex(random_bytes(8))
    . "&scope=profile%20openid%20email";
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>สมัครสมาชิก - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card" style="max-width:520px;">
        <div class="auth-logo">
        <a href="<?= SITE_URL ?>">
            <img src="img/Logo.png" alt="<?= SITE_NAME ?>" onerror="this.style.display='none'">
        </a>
            <h2>🌿 <?= SITE_NAME ?></h2>
            <p>สมัครสมาชิกเพื่อรับสิทธิพิเศษ</p>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?= sanitize($error) ?></div>
        <?php endif; ?>

        <!-- Social Register -->
        <div class="social-login">
            <a href="<?= $googleAuthUrl ?>" class="btn-social">
                <svg width="22" height="22" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.35-8.16 2.35-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
                สมัครด้วย Google
            </a>
            <a href="<?= $lineAuthUrl ?>" class="btn-social">
                <svg width="22" height="22" viewBox="0 0 48 48" fill="none"><rect width="48" height="48" rx="10" fill="#00C300"/><path fill-rule="evenodd" clip-rule="evenodd" d="M40 22.5C40 16.1 33.7 10.9 26 10.9C18.3 10.9 12 16.1 12 22.5C12 28.2 17.2 33 24.3 34.1L25.2 37.9L28.9 34.8C32.7 34.5 36.2 32.9 38.5 30.4C39.5 29.1 40 25.8 40 22.5ZM20 25H18V20H20V25ZM21 20H23V23.5L25.5 20H28L25.5 23L28 25H25.5L23 22V25H21V20ZM30 25H28V20H30V25ZM35 22H33V20H35V22ZM35 25H31V20H33V23H35V25Z" fill="white"/></svg>
                สมัครด้วย LINE
            </a>
        </div>

        <div class="divider">หรือสมัครด้วยอีเมล</div>

        <!-- Email Register Form -->
        <form method="POST">
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-user"></i> ชื่อ-นามสกุล *</label>
                    <input type="text" name="full_name" class="form-control" placeholder="ชื่อ นามสกุล" required value="<?= sanitize($_POST['full_name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-phone"></i> เบอร์โทร</label>
                    <input type="tel" name="phone" class="form-control" placeholder="08X-XXX-XXXX" value="<?= sanitize($_POST['phone'] ?? '') ?>">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label"><i class="fas fa-envelope"></i> อีเมล *</label>
                <input type="email" name="email" class="form-control" placeholder="your@email.com" required value="<?= sanitize($_POST['email'] ?? '') ?>">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-lock"></i> รหัสผ่าน *</label>
                    <input type="password" name="password" class="form-control" placeholder="อย่างน้อย 6 ตัว" required minlength="6" id="pw1">
                </div>
                <div class="form-group">
                    <label class="form-label"><i class="fas fa-lock"></i> ยืนยันรหัสผ่าน *</label>
                    <input type="password" name="confirm_password" class="form-control" placeholder="••••••" required id="pw2">
                </div>
            </div>

            <div id="pwStrength" style="margin-bottom:12px;display:none">
                <div style="height:4px;border-radius:4px;background:var(--green-pale);overflow:hidden">
                    <div id="strengthBar" style="height:100%;width:0;transition:all .3s;border-radius:4px;background:var(--green-deep)"></div>
                </div>
                <div style="font-size:12px;color:var(--text-light);margin-top:4px;" id="strengthText"></div>
            </div>

            <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:18px;font-size:13px;color:var(--text-light)">
                <input type="checkbox" id="agree" name="agree" required style="margin-top:2px;accent-color:var(--green-deep)">
                <label for="agree">ฉันยอมรับ <a href="#" style="color:var(--green-deep)">ข้อกำหนดการใช้งาน</a> และ <a href="#" style="color:var(--green-deep)">นโยบายความเป็นส่วนตัว</a></label>
            </div>

            <button type="submit" class="btn btn-primary btn-full btn-lg">
                <i class="fas fa-user-plus"></i> สมัครสมาชิก
            </button>
        </form>

        <div class="auth-footer">
            มีบัญชีอยู่แล้ว? <a href="login.php">เข้าสู่ระบบ</a>
        </div>
    </div>
</div>

<script>
const pw1 = document.getElementById('pw1');
const strengthBar = document.getElementById('strengthBar');
const strengthText = document.getElementById('strengthText');
const pwStrength = document.getElementById('pwStrength');

pw1.addEventListener('input', () => {
    const val = pw1.value;
    pwStrength.style.display = val ? 'block' : 'none';
    let score = 0;
    if (val.length >= 6) score++;
    if (val.length >= 10) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^a-zA-Z0-9]/.test(val)) score++;
    const levels = ['', 'อ่อนมาก', 'อ่อน', 'ปานกลาง', 'แข็งแรง', 'แข็งแรงมาก'];
    const colors = ['', '#e74c3c', '#e74c3c', '#f39c12', '#8A9A5B', '#4F7942'];
    strengthBar.style.width = (score * 20) + '%';
    strengthBar.style.background = colors[score] || '#ddd';
    strengthText.textContent = levels[score] || '';
});
</script>
</body>
</html>
