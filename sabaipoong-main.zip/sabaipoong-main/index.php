<?php
define('INCLUDED', true);
require_once 'config.php';

$pageTitle = 'ยินดีต้อนรับ';
$pdo = getDB();

// ดึงสินค้า
$stmt = $pdo->query("SELECT p.*, c.name AS cat_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.is_active = 1 ORDER BY p.created_at DESC LIMIT 12");
$products = $stmt->fetchAll();

// สินค้าขายดี
$stmt2 = $pdo->query("SELECT p.*, c.name AS cat_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.is_active = 1 ORDER BY p.sold_count DESC LIMIT 8");
$bestSellers = $stmt2->fetchAll();

// หมวดหมู่
$cats = $pdo->query("SELECT * FROM categories WHERE is_active = 1")->fetchAll();
?>
<?php include 'navbar.php'; ?>

<!-- HERO -->
<section class="hero">
    <div class="hero-inner">
        <div class="hero-content">
            <h1>อิ่มอร่อย<br>สุขภาพดี<br>ส่งตรงถึงบ้าน</h1>
            <p>อาหารเพื่อสุขภาพคัดพิเศษ สด ใหม่ ทุกวัน<br>เพราะสุขภาพที่ดีเริ่มต้นจากอาหารที่ดี 🌱</p>
            <div class="hero-actions">
                <a href="shop.php" class="btn-hero btn-hero-primary">
                    <i class="fas fa-store"></i> ดูสินค้าทั้งหมด
                </a>
                <?php if (!isLoggedIn()): ?>
                <a href="register.php" class="btn-hero btn-hero-outline">
                    <i class="fas fa-user-plus"></i> สมัครสมาชิก
                </a>
                <?php endif; ?>
            </div>

            <div class="hero-stats">
                <div class="hero-stat">
                    <span class="hero-stat-num">500+</span>
                    <span class="hero-stat-label">สมาชิก</span>
                </div>
                <div class="hero-stat">
                    <span class="hero-stat-num">50+</span>
                    <span class="hero-stat-label">สินค้า</span>
                </div>
                <div class="hero-stat">
                    <span class="hero-stat-num">4.9★</span>
                    <span class="hero-stat-label">รีวิว</span>
                </div>
            </div>
        </div>

        <div>
            <div class="hero-badges">
                <span class="hero-badge"><i class="fas fa-leaf"></i> ออแกนิก 100%</span>
                <span class="hero-badge"><i class="fas fa-truck"></i> ส่งถึงบ้าน</span>
                <span class="hero-badge"><i class="fas fa-award"></i> คุณภาพมาตรฐาน</span>
                <span class="hero-badge"><i class="fas fa-star"></i> ลูกค้าพึงพอใจ</span>
            </div>
        </div>
    </div>
</section>

<!-- MAIN CONTENT -->
<div class="main-content">

    <!-- หมวดหมู่ -->
    <div class="section-header">
        <h2 class="section-title">หมวดหมู่สินค้า</h2>
    </div>
    <div class="categories-grid" id="categoriesGrid">
        <button class="category-chip active" onclick="filterCategory('all', this)">
            <i class="fas fa-border-all"></i> ทั้งหมด
        </button>
        <?php foreach ($cats as $cat): ?>
        <button class="category-chip" onclick="filterCategory('<?= $cat['id'] ?>', this)" data-id="<?= $cat['id'] ?>">
            <?= sanitize($cat['name']) ?>
        </button>
        <?php endforeach; ?>
    </div>

    <!-- สินค้าใหม่ -->
    <div class="section-header">
        <h2 class="section-title">สินค้าล่าสุด</h2>
        <a href="shop.php" class="section-link">ดูทั้งหมด <i class="fas fa-arrow-right"></i></a>
    </div>

    <div class="products-grid" id="productsGrid">
        <?php foreach ($products as $p): ?>
        <?php include 'partials/product_card.php'; ?>
        <?php endforeach; ?>

        <?php if (empty($products)): ?>
        <div style="grid-column:1/-1;text-align:center;padding:60px;color:var(--text-light);">
            <div style="font-size:48px;margin-bottom:16px;">📦</div>
            <p style="font-size:16px;">ยังไม่มีสินค้าในขณะนี้</p>
        </div>
        <?php endif; ?>
    </div>

    <!-- สินค้าขายดี -->
    <?php if (!empty($bestSellers)): ?>
    <div class="section-header">
        <h2 class="section-title">🔥 สินค้าขายดี</h2>
        <a href="shop.php?sort=popular" class="section-link">ดูทั้งหมด <i class="fas fa-arrow-right"></i></a>
    </div>
    <div class="products-grid">
        <?php foreach ($bestSellers as $p): ?>
        <?php include 'partials/product_card.php'; ?>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Feature Boxes -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-top:52px;">
        <?php
        $features = [
            ['icon'=>'fas fa-leaf','title'=>'ออแกนิกแท้','desc'=>'ผลิตภัณฑ์ผ่านการรับรองมาตรฐาน'],
            ['icon'=>'fas fa-truck','title'=>'จัดส่งเร็ว','desc'=>'ส่งภายใน 1-3 วันทำการ'],
            ['icon'=>'fas fa-shield-alt','title'=>'ปลอดภัย 100%','desc'=>'ไม่มีสารเคมีอันตราย'],
            ['icon'=>'fas fa-undo','title'=>'คืนสินค้าได้','desc'=>'ถ้าไม่พอใจ คืนได้ภายใน 7 วัน'],
        ];
        foreach ($features as $f): ?>
        <div style="background:white;border-radius:var(--radius-lg);padding:28px 22px;text-align:center;box-shadow:var(--shadow-card);border:1px solid var(--green-pale);">
            <div style="font-size:32px;color:var(--green-deep);margin-bottom:12px;"><i class="<?= $f['icon'] ?>"></i></div>
            <h3 style="font-size:15px;font-weight:700;margin-bottom:6px;"><?= $f['title'] ?></h3>
            <p style="font-size:13px;color:var(--text-light);"><?= $f['desc'] ?></p>
        </div>
        <?php endforeach; ?>
    </div>

</div>

<?php include 'footer.php'; ?>

<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>
function filterCategory(id, el) {
    document.querySelectorAll('.category-chip').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
    if (id === 'all') { location.href = 'shop.php'; }
    else { location.href = 'shop.php?cat=' + id; }
}
</script>
</body>
</html>
