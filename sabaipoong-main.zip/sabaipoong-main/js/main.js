// main.js - สบายพุง

const SITE_URL = document.querySelector('meta[name="site-url"]')?.content || '';

// ============= TOAST =============
function showToast(message, type = 'info', duration = 3500) {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
    toast.innerHTML = `<span>${icons[type] || ''}</span> ${message}`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(40px)';
        toast.style.transition = 'all 0.4s';
        setTimeout(() => toast.remove(), 400);
    }, duration);
}

// ============= ADD TO CART =============
async function addToCart(productId, productName) {
    try {
        const res = await fetch('/sabaipung/api/cart.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'add', product_id: productId, quantity: 1 })
        });
        const data = await res.json();

        if (data.success) {
            showToast(`เพิ่ม "${productName}" ในตะกร้าแล้ว 🛒`, 'success');
            // อัปเดต badge
            const badge = document.querySelector('.cart-badge');
            if (badge) {
                badge.textContent = data.cart_count;
                badge.style.display = 'flex';
            } else {
                const cartBtn = document.querySelector('.cart-btn');
                if (cartBtn) {
                    const b = document.createElement('span');
                    b.className = 'cart-badge';
                    b.textContent = data.cart_count;
                    cartBtn.appendChild(b);
                }
            }
        } else if (data.error === 'not_logged_in') {
            showToast('กรุณาเข้าสู่ระบบก่อนเพิ่มสินค้า', 'error');
            setTimeout(() => { window.location.href = '/sabaipung/login.php'; }, 1500);
        } else {
            showToast(data.message || 'เกิดข้อผิดพลาด', 'error');
        }
    } catch (e) {
        showToast('ไม่สามารถเชื่อมต่อได้', 'error');
    }
}

// ============= TOGGLE WISHLIST =============
function toggleWishlist(productId, btn) {
    const icon = btn.querySelector('i');
    const isActive = icon.classList.contains('fas');
    icon.className = isActive ? 'far fa-heart' : 'fas fa-heart';
    showToast(isActive ? 'ลบออกจากรายการโปรดแล้ว' : 'เพิ่มในรายการโปรดแล้ว ❤️', isActive ? 'info' : 'success', 2000);
}

// ============= CART QTY =============
function updateCartQty(cartId, delta) {
    const input = document.querySelector(`[data-cart-id="${cartId}"]`);
    if (!input) return;
    const newQty = Math.max(1, parseInt(input.value) + delta);
    input.value = newQty;

    fetch('/sabaipung/api/cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update', cart_id: cartId, quantity: newQty })
    }).then(r => r.json()).then(data => {
        if (data.success) {
            // อัปเดต subtotal
            const subtotalEl = document.querySelector(`[data-subtotal="${cartId}"]`);
            if (subtotalEl) subtotalEl.textContent = data.subtotal + ' บาท';
            // อัปเดต total
            const totalEl = document.getElementById('cartTotal');
            if (totalEl) totalEl.textContent = data.total + ' บาท';
        }
    });
}

function removeCartItem(cartId) {
    if (!confirm('ต้องการลบสินค้านี้ออกจากตะกร้า?')) return;
    fetch('/sabaipung/api/cart.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'remove', cart_id: cartId })
    }).then(r => r.json()).then(data => {
        if (data.success) {
            document.querySelector(`[data-cart-item="${cartId}"]`)?.remove();
            showToast('ลบสินค้าออกจากตะกร้าแล้ว', 'info');
        }
    });
}

// ============= MODAL =============
function openModal(id) {
    document.getElementById(id)?.classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeModal(id) {
    document.getElementById(id)?.classList.remove('open');
    document.body.style.overflow = '';
}

document.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('open');
        document.body.style.overflow = '';
    }
});

// ============= STAR RATING =============
function initStarRating(container) {
    const stars = container?.querySelectorAll('.star-rating span');
    if (!stars) return;
    stars.forEach((star, i) => {
        star.addEventListener('mouseenter', () => {
            stars.forEach((s, j) => s.classList.toggle('active', j <= i));
        });
        star.addEventListener('click', () => {
            stars.forEach((s, j) => s.classList.toggle('active', j <= i));
            container.querySelector('input[name="rating"]').value = i + 1;
        });
    });
    container.querySelector('.star-rating')?.addEventListener('mouseleave', () => {
        const val = parseInt(container.querySelector('input[name="rating"]')?.value || 0);
        stars.forEach((s, j) => s.classList.toggle('active', j < val));
    });
}

document.querySelectorAll('[data-star-rating]').forEach(initStarRating);

// ============= IMAGE PREVIEW =============
function setupImageUpload(inputId, previewId) {
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    if (!input || !preview) return;

    input.addEventListener('change', () => {
        preview.innerHTML = '';
        [...input.files].forEach(file => {
            const reader = new FileReader();
            reader.onload = e => {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.className = 'preview-img';
                preview.appendChild(img);
            };
            reader.readAsDataURL(file);
        });
    });
}

// ============= ADMIN DELETE CONFIRM =============
function confirmDelete(url, name) {
    if (confirm(`ต้องการลบ "${name}" ?`)) {
        window.location.href = url;
    }
}

// ============= SMOOTH SCROLL TO TOP =============
const scrollBtn = document.createElement('button');
scrollBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
scrollBtn.style.cssText = `
    position:fixed;bottom:80px;right:24px;z-index:999;
    width:44px;height:44px;border-radius:50%;
    background:var(--green-deep);color:white;border:none;
    font-size:16px;cursor:pointer;display:none;
    box-shadow:0 4px 16px rgba(79,121,66,0.35);
    transition:all .3s;
`;
document.body.appendChild(scrollBtn);

window.addEventListener('scroll', () => {
    scrollBtn.style.display = window.scrollY > 300 ? 'block' : 'none';
});

scrollBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});
