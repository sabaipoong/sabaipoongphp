<?php
// partials/product_card.php
// ต้องมีตัวแปร $p = product array
$avgRating = 4.5; // placeholder
$reviewCount = rand(5, 120);
$isNew = strtotime($p['created_at']) > strtotime('-7 days');
?>
<div class="product-card" data-cat="<?= $p['category_id'] ?>">
    <div class="product-img-wrap">
        <a href="<?= SITE_URL ?>/product.php?id=<?= $p['id'] ?>">
            <img src="<?= $p['image'] ? SITE_URL . '/' . sanitize($p['image']) : SITE_URL . '/img/no-image.png' ?>"
                 alt="<?= sanitize($p['name']) ?>"
                 loading="lazy"
                 onerror="this.src='<?= SITE_URL ?>/img/no-image.png'">
        </a>
        <?php if ($isNew): ?>
            <span class="product-badge">ใหม่</span>
        <?php elseif ($p['sold_count'] > 50): ?>
            <span class="product-badge" style="background:var(--brown-warm)">ขายดี 🔥</span>
        <?php endif; ?>
        <button class="product-wishlist" onclick="toggleWishlist(<?= $p['id'] ?>, this)" title="บันทึก">
            <i class="far fa-heart" style="color:#e74c3c"></i>
        </button>
    </div>
    <div class="product-body">
        <div class="product-category"><?= sanitize($p['cat_name'] ?? '') ?></div>
        <a href="<?= SITE_URL ?>/product.php?id=<?= $p['id'] ?>" class="product-name">
            <?= sanitize($p['name']) ?>
        </a>
        <div class="product-rating">
            <span class="stars">
                <?php for ($i=1; $i<=5; $i++) echo $i <= round($avgRating) ? '★' : '☆'; ?>
            </span>
            <span class="rating-count">(<?= $reviewCount ?>)</span>
        </div>
        <?php if ($p['stock'] > 0 && $p['stock'] <= 5): ?>
        <div class="stock-low">⚠️ เหลือ <?= $p['stock'] ?> <?= sanitize($p['unit'] ?? 'ชิ้น') ?></div>
        <?php endif; ?>
        <div class="product-footer">
            <div class="product-price">
                <?= number_format($p['price'], 0) ?> <span class="unit">บาท/<?= sanitize($p['unit'] ?? 'ชิ้น') ?></span>
            </div>
            <?php if ($p['stock'] > 0): ?>
            <button class="btn-add-cart" onclick="addToCart(<?= $p['id'] ?>, '<?= addslashes(sanitize($p['name'])) ?>')">
                <i class="fas fa-cart-plus"></i> ใส่ตะกร้า
            </button>
            <?php else: ?>
            <span style="font-size:12px;color:#e74c3c;font-weight:600;">สินค้าหมด</span>
            <?php endif; ?>
        </div>
    </div>
</div>
