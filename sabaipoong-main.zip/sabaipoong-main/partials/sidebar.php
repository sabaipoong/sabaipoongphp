<?php
// partials/sidebar.php
$currentPage = basename($_SERVER['PHP_SELF']);
$currentPath = $_SERVER['PHP_SELF'];

$menuItems = [
    [
        'label' => 'ภาพรวม',
        'items' => [
            ['icon' => 'fa-tachometer-alt', 'label' => 'แผงควบคุม',   'file' => 'index.php',    'link' => ''],
        ]
    ],
    [
        'label' => 'จัดการระบบ',
        'items' => [
            ['icon' => 'fa-box-open',       'label' => 'สินค้า',       'file' => 'products.php', 'link' => 'products.php'],
            ['icon' => 'fa-tags',           'label' => 'หมวดหมู่',     'file' => 'categories.php','link' => 'categories.php'],
            ['icon' => 'fa-receipt',        'label' => 'ออเดอร์',      'file' => 'orders.php',   'link' => 'orders.php'],
            ['icon' => 'fa-users',          'label' => 'สมาชิก',       'file' => 'users.php',    'link' => 'users.php'],
        ]
    ],
    [
        'label' => 'การเงิน',
        'items' => [
            ['icon' => 'fa-chart-bar',      'label' => 'รายงานยอดขาย', 'file' => 'reports.php',  'link' => 'reports.php'],
            ['icon' => 'fa-star',           'label' => 'คะแนนสะสม',    'file' => 'points.php',   'link' => 'points.php'],
        ]
    ],
    [
        'label' => 'ตั้งค่า',
        'items' => [
            ['icon' => 'fa-cog',            'label' => 'ตั้งค่าเว็บไซต์','file' => 'settings.php','link' => 'settings.php'],
            ['icon' => 'fa-user-circle',    'label' => 'โปรไฟล์ของฉัน', 'file' => 'profile.php', 'link' => 'profile.php'],
        ]
    ],
];
?>

<aside class="admin-sidebar" id="adminSidebar">

    <!-- Sidebar Header -->
    <div class="sidebar-header">
        <div class="sidebar-brand">
            <div class="sidebar-brand-icon">
                <i class="fas fa-leaf"></i>
            </div>
            <div class="sidebar-brand-text">
                <span class="sidebar-brand-name"><?= defined('SITE_NAME') ? SITE_NAME : 'Admin' ?></span>
                <span class="sidebar-brand-role">ผู้ดูแลระบบ</span>
            </div>
        </div>
        <button class="sidebar-toggle-btn" id="sidebarToggle" title="ย่อ/ขยาย Sidebar">
            <i class="fas fa-bars"></i>
        </button>
    </div>

    <!-- Admin Profile -->
    <div class="sidebar-profile">
        <div class="sidebar-avatar">
            <?php
            $profileImg = $_SESSION['profile_image'] ?? '';
            $siteUrl    = defined('SITE_URL') ? SITE_URL : '';
            ?>
            <img src="<?= $siteUrl ?>/<?= sanitize($profileImg ?: 'uploads/profiles/default.png') ?>"
     alt="Profile"
     style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover;"
     onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <div class="sidebar-avatar-fallback">
                <?= mb_strtoupper(mb_substr($_SESSION['username'] ?? 'A', 0, 1)) ?>
            </div>
        </div>
        <div class="sidebar-profile-info">
            <span class="sidebar-username"><?= sanitize($_SESSION['username'] ?? 'Admin') ?></span>
            <span class="sidebar-email"><?= sanitize($_SESSION['email'] ?? '') ?></span>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="sidebar-nav">
        <?php foreach ($menuItems as $group): ?>
        <div class="sidebar-group">
            <span class="sidebar-group-label"><?= $group['label'] ?></span>
            <?php foreach ($group['items'] as $item):
                $isActive = $currentPage === $item['file'];
                $href     = $item['link'] ? (defined('SITE_URL') ? SITE_URL : '') . '/admin/' . $item['link'] : (defined('SITE_URL') ? SITE_URL : '') . '/admin';
            ?>
            <a href="<?= $href ?>" class="sidebar-item <?= $isActive ? 'active' : '' ?>">
                <span class="sidebar-item-icon">
                    <i class="fas <?= $item['icon'] ?>"></i>
                </span>
                <span class="sidebar-item-label"><?= $item['label'] ?></span>
                <?php if ($isActive): ?>
                <span class="sidebar-active-dot"></span>
                <?php endif; ?>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </nav>

    <!-- Bottom: Back to shop + Logout -->
    <div class="sidebar-footer">
        <a href="<?= defined('SITE_URL') ? SITE_URL : '' ?>/" class="sidebar-item sidebar-item-muted">
            <span class="sidebar-item-icon"><i class="fas fa-store"></i></span>
            <span class="sidebar-item-label">ไปที่หน้าร้าน</span>
        </a>
        <a href="<?= defined('SITE_URL') ? SITE_URL : '' ?>/admin/logout.php" class="sidebar-item sidebar-item-danger">
            <span class="sidebar-item-icon"><i class="fas fa-sign-out-alt"></i></span>
            <span class="sidebar-item-label">ออกจากระบบ</span>
        </a>
    </div>

</aside>

<style>
/* ===================================================
   ADMIN SIDEBAR STYLES
=================================================== */

/* Layout wrapper (ต้องมีใน admin layout) */
.admin-layout {
    display: flex;
    min-height: calc(100vh - 60px); /* ปรับตาม navbar height */
}

.admin-main {
    flex: 1;
    padding: 28px 32px;
    background: var(--bg-page, #f4f7f4);
    min-width: 0;
    transition: margin-left .3s ease;
}

/* ===== Sidebar Base ===== */
.admin-sidebar {
    width: 240px;
    min-height: calc(100vh - 60px);
    background: #fff;
    border-right: 1px solid var(--border-color, #e4ede4);
    display: flex;
    flex-direction: column;
    flex-shrink: 0;
    transition: width .3s ease;
    overflow: hidden;
    position: sticky;
    top: 60px; /* ปรับตาม navbar height */
    align-self: flex-start;
    max-height: calc(100vh - 60px);
    overflow-y: auto;
}

.admin-sidebar.collapsed {
    width: 68px;
}

/* Scrollbar */
.admin-sidebar::-webkit-scrollbar { width: 4px; }
.admin-sidebar::-webkit-scrollbar-track { background: transparent; }
.admin-sidebar::-webkit-scrollbar-thumb { background: #d0e4d0; border-radius: 4px; }

/* ===== Header ===== */
.sidebar-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 18px 16px 14px;
    border-bottom: 1px solid var(--border-color, #e4ede4);
    gap: 10px;
}

.sidebar-brand {
    display: flex;
    align-items: center;
    gap: 10px;
    overflow: hidden;
}

.sidebar-brand-icon {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    background: linear-gradient(135deg, #4caf50, #2d5a27);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 15px;
    flex-shrink: 0;
}

.sidebar-brand-text {
    display: flex;
    flex-direction: column;
    overflow: hidden;
    transition: opacity .2s, width .2s;
}

.sidebar-brand-name {
    font-size: 14px;
    font-weight: 700;
    color: var(--green-deep, #2d5a27);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.sidebar-brand-role {
    font-size: 11px;
    color: var(--text-light, #888);
}

.sidebar-toggle-btn {
    background: none;
    border: none;
    cursor: pointer;
    width: 30px;
    height: 30px;
    border-radius: 8px;
    color: var(--text-light, #888);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    flex-shrink: 0;
    transition: background .15s, color .15s;
}

.sidebar-toggle-btn:hover {
    background: var(--green-light, #f0f7ee);
    color: var(--green-deep, #2d5a27);
}

/* ===== Profile ===== */
.sidebar-profile {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 14px 16px;
    border-bottom: 1px solid var(--border-color, #e4ede4);
    background: var(--green-light, #f8fdf7);
    overflow: hidden;
}

.sidebar-avatar {
    position: relative;
    width: 38px;
    height: 38px;
    flex-shrink: 0;
}

.sidebar-avatar img {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #c8e0c4;
    display: block;
}

.sidebar-avatar-fallback {
    display: none;
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: linear-gradient(135deg, #4caf50, #2d5a27);
    color: #fff;
    font-weight: 700;
    font-size: 15px;
    align-items: center;
    justify-content: center;
    border: 2px solid #c8e0c4;
}

.sidebar-profile-info {
    display: flex;
    flex-direction: column;
    overflow: hidden;
    transition: opacity .2s;
}

.sidebar-username {
    font-size: 13px;
    font-weight: 700;
    color: var(--text-dark, #1a1a1a);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.sidebar-email {
    font-size: 11px;
    color: var(--text-light, #888);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

/* ===== Navigation ===== */
.sidebar-nav {
    flex: 1;
    padding: 10px 10px 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.sidebar-group {
    margin-bottom: 8px;
}

.sidebar-group-label {
    display: block;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--text-light, #aaa);
    padding: 6px 10px 4px;
    white-space: nowrap;
    overflow: hidden;
    transition: opacity .2s;
}

.sidebar-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 9px 10px;
    border-radius: 10px;
    text-decoration: none;
    color: var(--text-dark, #444);
    font-size: 14px;
    font-weight: 500;
    transition: background .15s, color .15s, padding .2s;
    position: relative;
    white-space: nowrap;
    overflow: hidden;
}

.sidebar-item:hover {
    background: var(--green-light, #f0f7ee);
    color: var(--green-deep, #2d5a27);
}

.sidebar-item.active {
    background: linear-gradient(90deg, #e8f5e9, #f0f7ee);
    color: var(--green-deep, #2d5a27);
    font-weight: 700;
    box-shadow: inset 3px 0 0 var(--green-deep, #2d5a27);
}

.sidebar-item-icon {
    width: 28px;
    height: 28px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    flex-shrink: 0;
    background: transparent;
    transition: background .15s;
}

.sidebar-item:hover .sidebar-item-icon,
.sidebar-item.active .sidebar-item-icon {
    background: var(--green-light, #e8f5e9);
    color: var(--green-deep, #2d5a27);
}

.sidebar-item-label {
    flex: 1;
    transition: opacity .2s, width .2s;
}

.sidebar-active-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--green-deep, #2d5a27);
    flex-shrink: 0;
}

.sidebar-item-muted {
    color: var(--text-light, #888);
}

.sidebar-item-danger {
    color: #c62828;
}

.sidebar-item-danger:hover {
    background: #ffebee;
    color: #c62828;
}

/* ===== Footer ===== */
.sidebar-footer {
    padding: 10px;
    border-top: 1px solid var(--border-color, #e4ede4);
    display: flex;
    flex-direction: column;
    gap: 2px;
}

/* ===== Collapsed State ===== */
.admin-sidebar.collapsed .sidebar-brand-text,
.admin-sidebar.collapsed .sidebar-profile-info,
.admin-sidebar.collapsed .sidebar-group-label,
.admin-sidebar.collapsed .sidebar-item-label,
.admin-sidebar.collapsed .sidebar-active-dot {
    opacity: 0;
    width: 0;
    pointer-events: none;
}

.admin-sidebar.collapsed .sidebar-item {
    justify-content: center;
    padding: 9px 0;
}

.admin-sidebar.collapsed .sidebar-profile {
    justify-content: center;
}

.admin-sidebar.collapsed .sidebar-header {
    justify-content: center;
}

.admin-sidebar.collapsed .sidebar-toggle-btn {
    margin: 0;
}

/* Tooltip for collapsed state */
.admin-sidebar.collapsed .sidebar-item {
    position: relative;
}

.admin-sidebar.collapsed .sidebar-item::after {
    content: attr(data-tooltip);
    position: absolute;
    left: calc(100% + 8px);
    top: 50%;
    transform: translateY(-50%);
    background: #333;
    color: #fff;
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 12px;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: opacity .15s;
    z-index: 999;
}

.admin-sidebar.collapsed .sidebar-item:hover::after {
    opacity: 1;
}

/* ===== Mobile Overlay ===== */
.sidebar-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,.4);
    z-index: 99;
}

@media (max-width: 900px) {
    .admin-sidebar {
        position: fixed;
        top: 0;
        left: -240px;
        height: 100vh;
        z-index: 100;
        transition: left .3s ease;
        max-height: 100vh;
    }

    .admin-sidebar.mobile-open {
        left: 0;
    }

    .sidebar-overlay.visible {
        display: block;
    }

    .admin-main {
        padding: 20px 16px;
    }
}
</style>

<?php
// Set tooltip data on each item (for collapsed sidebar UX)
?>
<script>
(function () {
    // Add data-tooltip to each sidebar item
    document.querySelectorAll('.sidebar-item').forEach(function (el) {
        const label = el.querySelector('.sidebar-item-label');
        if (label) el.setAttribute('data-tooltip', label.textContent.trim());
    });

    const sidebar  = document.getElementById('adminSidebar');
    const toggleBtn = document.getElementById('sidebarToggle');
    const STORAGE_KEY = 'admin_sidebar_collapsed';

    // Restore state
    if (localStorage.getItem(STORAGE_KEY) === '1') {
        sidebar.classList.add('collapsed');
    }

    // Toggle on button click
    if (toggleBtn) {
        toggleBtn.addEventListener('click', function () {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem(STORAGE_KEY, sidebar.classList.contains('collapsed') ? '1' : '0');
        });
    }

    // Mobile: create overlay
    const overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    document.body.appendChild(overlay);

    overlay.addEventListener('click', function () {
        sidebar.classList.remove('mobile-open');
        overlay.classList.remove('visible');
    });

    // Mobile: open via hamburger in navbar (ถ้ามีปุ่ม #mobileMenuBtn)
    const mobileBtn = document.getElementById('mobileMenuBtn');
    if (mobileBtn) {
        mobileBtn.addEventListener('click', function () {
            sidebar.classList.toggle('mobile-open');
            overlay.classList.toggle('visible');
        });
    }
})();
</script>
