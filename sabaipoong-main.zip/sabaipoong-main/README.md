# 🌿 สบายพุง - ระบบร้านค้าออนไลน์

## โครงสร้างไฟล์
```
sabaipung/
├── config.php              ← ตั้งค่าฐานข้อมูล + helpers
├── index.php               ← หน้าแรก + สินค้า
├── navbar.php              ← แถบนำทาง (include ในทุกหน้า)
├── login.php               ← เข้าสู่ระบบ (Email/Google/LINE)
├── register.php            ← สมัครสมาชิก
├── logout.php              ← ออกจากระบบ
├── shop.php                ← หน้าร้านค้า
├── product.php             ← รายละเอียดสินค้า
├── cart.php                ← ตะกร้าสินค้า
├── checkout.php            ← ยืนยันสั่งซื้อ (ตัดสต็อกอัตโนมัติ)
├── orders.php              ← ประวัติคำสั่งซื้อ
├── profile.php             ← โปรไฟล์ผู้ใช้ (แก้รูป + ที่อยู่)
├── review.php              ← เขียนรีวิว (อัปรูป + ถ่ายรูป)
├── database.sql            ← ฐานข้อมูล
├── css/style.css           ← สไตล์หลัก
├── js/main.js              ← JavaScript
├── img/Logo.png            ← โลโก้ร้าน (ใส่ไฟล์เอง)
├── uploads/                ← ไฟล์อัปโหลด
│   ├── products/
│   ├── profiles/
│   └── reviews/
├── api/
│   └── cart.php            ← API ตะกร้า (AJAX)
├── admin/
│   ├── index.php           ← Dashboard
│   ├── products.php        ← เพิ่ม/แก้ไข/ลบสินค้า
│   ├── orders.php          ← จัดการคำสั่งซื้อ
│   ├── users.php           ← ผู้ใช้ + จัดการคะแนน
│   ├── categories.php      ← จัดการหมวดหมู่
│   └── partials/sidebar.php
├── auth/
│   ├── google_callback.php ← Google OAuth callback
│   └── line_callback.php   ← LINE Login callback
└── partials/
    └── product_card.php    ← การ์ดสินค้า
```

## วิธีติดตั้ง

### 1. ฐานข้อมูล
```sql
-- นำเข้าไฟล์ database.sql ใน phpMyAdmin หรือ MySQL CLI:
mysql -u root -p < database.sql
```

### 2. ตั้งค่า config.php
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');      // username MySQL ของคุณ
define('DB_PASS', '');          // password MySQL
define('SITE_URL', 'http://localhost/sabaipung');
```

### 3. Social Login

#### Google Login
1. ไปที่ https://console.cloud.google.com
2. สร้าง OAuth 2.0 Client ID
3. ตั้ง Redirect URI: `http://localhost/sabaipung/auth/google_callback.php`
4. ใส่ค่าใน config.php: `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`

#### LINE Login
1. ไปที่ https://developers.line.biz
2. สร้าง LINE Login channel
3. ตั้ง Redirect URI: `http://localhost/sabaipung/auth/line_callback.php`
4. ใส่ค่าใน config.php: `LINE_CHANNEL_ID`, `LINE_CHANNEL_SECRET`

### 4. สิทธิ์โฟลเดอร์
```bash
chmod 755 uploads/
chmod 755 uploads/products/
chmod 755 uploads/profiles/
chmod 755 uploads/reviews/
```

### 5. Admin เริ่มต้น
- Email: admin@sabaipung.com
- Password: admin1234

> ⚠️ เปลี่ยนรหัสผ่าน admin ทันทีหลังติดตั้ง!

---

## ฟีเจอร์หลัก

### Admin
- ✅ Dashboard ภาพรวม
- ✅ เพิ่ม/แก้ไข/ลบสินค้า (พร้อมอัปโหลดรูป)
- ✅ จัดการคำสั่งซื้อ + อัปเดตสถานะ
- ✅ ดูรายชื่อสมาชิก + จัดการคะแนน
- ✅ จัดการหมวดหมู่

### User  
- ✅ สมัคร/ล็อกอิน Email/Google/LINE
- ✅ เลือกซื้อสินค้า → ตะกร้า → Checkout
- ✅ ตัดสต็อกอัตโนมัติเมื่อสั่งซื้อ
- ✅ ได้รับคะแนน 1 ชิ้น = 1 คะแนน
- ✅ แก้ไขโปรไฟล์ + รูปโปรไฟล์
- ✅ แก้ไขที่อยู่จัดส่ง
- ✅ เขียนรีวิว + อัปโหลดรูป + ถ่ายรูปจากกล้อง

## Database Schema
- `users` - ผู้ใช้งาน
- `categories` - หมวดหมู่สินค้า
- `products` - สินค้า
- `cart` - ตะกร้า
- `orders` - คำสั่งซื้อ
- `order_items` - รายการสินค้าในคำสั่งซื้อ
- `reviews` - รีวิว
- `points_history` - ประวัติคะแนน
