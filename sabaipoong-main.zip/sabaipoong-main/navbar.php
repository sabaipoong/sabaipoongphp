<?php
// navbar.php - Navbar ที่ใช้ร่วมกันทุกหน้า
if (!defined('INCLUDED')) {
    require_once __DIR__ . '/config.php';
}
$cartCount = getCartCount();
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? sanitize($pageTitle) . ' - ' : '' ?><?= SITE_NAME ?></title>
    <meta name="description" content="<?= SITE_DESC ?>">
    <link rel="icon" href="img/Logo.png" type="image/png">
    <link rel="stylesheet" href="css/style.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <?= isset($extraHead) ? $extraHead : '' ?>
</head>
<body>

<nav class="navbar">
    <div class="navbar-inner">
        <!-- Brand -->
        <a href="<?= SITE_URL ?>" class="navbar-brand">
            <img src="<?= SITE_URL ?>/img/Logo.png" alt="<?= SITE_NAME ?>" onerror="this.style.display='none'">
            <span><?= SITE_NAME ?> <em>🌿</em></span>
        </a>

        <!-- Search -->
        <div class="navbar-search">
            <form action="<?= SITE_URL ?>/shop.php" method="GET">
                <input type="text" name="q" placeholder="ค้นหาสินค้า..." value="<?= sanitize($_GET['q'] ?? '') ?>">
                <span class="navbar-search-icon"><i class="fas fa-search"></i></span>
            </form>
        </div>

        <!-- Actions -->
        <div class="navbar-actions">
            <a href="<?= SITE_URL ?>" class="nav-link <?= $currentPage === 'index.php' ? 'active' : '' ?>">
                <i class="fas fa-home"></i><span>หน้าแรก</span>
            </a>
            <a href="<?= SITE_URL ?>/shop.php" class="nav-link <?= $currentPage === 'shop.php' ? 'active' : '' ?>">
                <i class="fas fa-store"></i><span>สินค้า</span>
            </a>

            <?php if (isLoggedIn()): ?>
                <!-- Cart -->
                <a href="<?= SITE_URL ?>/cart.php" class="nav-link cart-btn">
                    <i class="fas fa-shopping-cart"></i>
                    <span>ตะกร้า</span>
                    <?php if ($cartCount > 0): ?>
                        <span class="cart-badge"><?= $cartCount > 99 ? '99+' : $cartCount ?></span>
                    <?php endif; ?>
                </a>

                <!-- User Menu -->
                <div class="dropdown">
                    <button class="nav-link" style="background:none;border:none;">
                        <img src="<?= SITE_URL ?>/<?= sanitize($_SESSION['profile_image'] ?? 'uploads/profiles/default.png') ?>"
                             class="user-avatar" alt="โปรไฟล์"
                             onerror="this.src='<?= SITE_URL ?>/uploads/profiles/default.png'">
                        <span><?= sanitize($_SESSION['username'] ?? 'ผู้ใช้') ?></span>
                        <i class="fas fa-chevron-down" style="font-size:10px;"></i>
                    </button>
                    <div class="dropdown-menu">
                        <div style="padding:10px 16px 6px; font-size:13px; color:var(--text-light);">
                            <?= sanitize($_SESSION['email'] ?? '') ?>
                        </div>
                        <?php if (isAdmin()): ?>
                            <a href="<?= SITE_URL ?>/admin/index.php" class="dropdown-item">
                                <i class="fas fa-cog" style="color:var(--green-sage)"></i> จัดการระบบ
                            </a>
                        <?php endif; ?>
                        <a href="<?= SITE_URL ?>/profile.php" class="dropdown-item">
                            <i class="fas fa-user" style="color:var(--green-sage)"></i> โปรไฟล์ของฉัน
                        </a>
                        <a href="<?= SITE_URL ?>/orders.php" class="dropdown-item">
                            <i class="fas fa-box" style="color:var(--green-sage)"></i> คำสั่งซื้อของฉัน
                        </a>
                        <a href="<?= SITE_URL ?>/points.php" class="dropdown-item">
                            <i class="fas fa-star" style="color:#f39c12"></i> คะแนนสะสม
                            <?php if (isset($_SESSION['points']) && $_SESSION['points'] > 0): ?>
                                <span class="badge badge-info" style="margin-left:auto"><?= $_SESSION['points'] ?></span>
                            <?php endif; ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="<?= SITE_URL ?>/logout.php" class="dropdown-item danger">
                            <i class="fas fa-sign-out-alt"></i> ออกจากระบบ
                        </a>
                    </div>
                </div>

            <?php else: ?>
                <a href="<?= SITE_URL ?>/login.php" class="nav-link">
                    <i class="fas fa-sign-in-alt"></i><span>เข้าสู่ระบบ</span>
                </a>
                <a href="<?= SITE_URL ?>/register.php" class="btn btn-primary btn-sm">
                    <i class="fas fa-user-plus"></i> สมัครสมาชิก
                </a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Toast Container -->
<div class="toast-container" id="toastContainer"></div>

<?php if (isset($_SESSION['flash'])): ?>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        showToast('<?= addslashes($_SESSION['flash']['message']) ?>', '<?= $_SESSION['flash']['type'] ?? 'info' ?>');
    });
</script>
<?php unset($_SESSION['flash']); endif; ?>
