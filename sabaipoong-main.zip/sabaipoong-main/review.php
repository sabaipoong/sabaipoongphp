<?php
define('INCLUDED', true);
require_once 'config.php';
requireLogin();

$pdo = getDB();
$productId = (int)($_GET['product_id'] ?? 0);
$orderId   = (int)($_GET['order_id'] ?? 0);
$userId    = $_SESSION['user_id'];
$pageTitle = 'เขียนรีวิว';

if (!$productId) { header('Location: orders.php'); exit; }

$product = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$product->execute([$productId]);
$product = $product->fetch();

if (!$product) { header('Location: orders.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating  = (int)($_POST['rating'] ?? 5);
    $comment = trim($_POST['comment'] ?? '');
    $images  = [];

    // อัปโหลดรูปรีวิว (หลายรูป)
    if (!empty($_FILES['review_images']['name'][0])) {
        foreach ($_FILES['review_images']['name'] as $i => $name) {
            if ($name && $_FILES['review_images']['error'][$i] === 0) {
                $file = [
                    'name'     => $name,
                    'type'     => $_FILES['review_images']['type'][$i],
                    'tmp_name' => $_FILES['review_images']['tmp_name'][$i],
                    'error'    => $_FILES['review_images']['error'][$i],
                    'size'     => $_FILES['review_images']['size'][$i],
                ];
                $path = uploadImage($file, 'reviews');
                if ($path) $images[] = $path;
            }
        }
    }

    $pdo->prepare("INSERT INTO reviews (product_id, user_id, order_id, rating, comment, images) VALUES (?,?,?,?,?,?)")
        ->execute([$productId, $userId, $orderId ?: null, $rating, $comment, json_encode($images)]);

    $_SESSION['flash'] = ['message' => 'รีวิวสำเร็จ ขอบคุณ! 🎉', 'type' => 'success'];
    header('Location: orders.php');
    exit;
}
?>
<?php include 'navbar.php'; ?>

<div class="main-content" style="max-width:640px;margin:0 auto;padding-top:40px;">
    <div style="background:white;border-radius:var(--radius-lg);padding:32px;box-shadow:var(--shadow-card);border:1px solid var(--green-pale)">
        <div style="display:flex;align-items:center;gap:16px;margin-bottom:24px;padding-bottom:18px;border-bottom:2px solid var(--green-pale)">
            <img src="<?= $product['image'] ? SITE_URL . '/' . sanitize($product['image']) : SITE_URL . '/img/no-image.png' ?>"
                 style="width:64px;height:64px;border-radius:var(--radius-md);object-fit:cover;border:2px solid var(--green-pale)"
                 onerror="this.src='<?= SITE_URL ?>/img/no-image.png'">
            <div>
                <h2 style="font-size:1.1rem;font-weight:700">เขียนรีวิวสินค้า</h2>
                <p style="font-size:14px;color:var(--text-light)"><?= sanitize($product['name']) ?></p>
            </div>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <!-- Star Rating -->
            <div class="form-group" data-star-rating>
                <label class="form-label">คะแนนความพึงพอใจ *</label>
                <input type="hidden" name="rating" id="ratingVal" value="5">
                <div class="star-rating" id="starRating">
                    <?php for ($i=1; $i<=5; $i++): ?>
                    <span class="active" data-val="<?= $i ?>" onclick="setRating(<?= $i ?>)">★</span>
                    <?php endfor; ?>
                </div>
                <div style="font-size:13px;color:var(--text-light);margin-top:6px" id="ratingLabel">ยอดเยี่ยมมาก!</div>
            </div>

            <!-- Comment -->
            <div class="form-group">
                <label class="form-label">ความคิดเห็น</label>
                <textarea name="comment" class="form-control" rows="4" placeholder="บอกเล่าประสบการณ์การใช้สินค้า..."></textarea>
            </div>

            <!-- รูปภาพ -->
            <div class="form-group">
                <label class="form-label">รูปภาพประกอบรีวิว</label>
                <div style="display:flex;gap:10px;margin-bottom:12px;flex-wrap:wrap">
                    <label class="btn btn-outline" for="reviewImages" style="cursor:pointer">
                        <i class="fas fa-image"></i> เลือกรูปจากเครื่อง
                        <input type="file" id="reviewImages" name="review_images[]" accept="image/*" multiple style="display:none" onchange="previewReviewImages(this)">
                    </label>
                    <button type="button" class="btn btn-outline" onclick="openCamera()">
                        <i class="fas fa-camera"></i> ถ่ายรูป
                    </button>
                </div>
                <div id="reviewPreview" class="preview-grid"></div>

                <!-- Camera Stream -->
                <div id="cameraSection" style="display:none;margin-top:12px">
                    <video id="cameraStream" autoplay playsinline style="width:100%;border-radius:var(--radius-md);max-height:300px;background:#000;"></video>
                    <canvas id="cameraCanvas" style="display:none"></canvas>
                    <div style="display:flex;gap:10px;margin-top:10px">
                        <button type="button" class="btn btn-primary" onclick="takePhoto()"><i class="fas fa-circle"></i> ถ่ายรูป</button>
                        <button type="button" class="btn btn-outline" onclick="closeCamera()">ปิดกล้อง</button>
                    </div>
                    <div id="capturedPhotos" class="preview-grid" style="margin-top:10px"></div>
                </div>
                <input type="hidden" name="captured_photos" id="capturedPhotosData">
            </div>

            <div style="display:flex;gap:12px;margin-top:8px">
                <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-paper-plane"></i> ส่งรีวิว</button>
                <a href="orders.php" class="btn btn-outline btn-lg">ยกเลิก</a>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>
<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>
const ratingLabels = ['', 'แย่มาก 😞', 'พอใช้ 😐', 'ปานกลาง 😊', 'ดีมาก 😄', 'ยอดเยี่ยมมาก! 🤩'];

function setRating(val) {
    document.getElementById('ratingVal').value = val;
    document.getElementById('ratingLabel').textContent = ratingLabels[val];
    document.querySelectorAll('#starRating span').forEach((s, i) => {
        s.classList.toggle('active', i < val);
        s.style.color = i < val ? '#f39c12' : '#ddd';
    });
}

// init stars
document.querySelectorAll('#starRating span').forEach(s => {
    s.style.color = '#f39c12';
    s.addEventListener('mouseenter', () => {
        const val = parseInt(s.dataset.val);
        document.querySelectorAll('#starRating span').forEach((x, i) => {
            x.style.color = i < val ? '#f39c12' : '#ddd';
        });
    });
});

document.getElementById('starRating').addEventListener('mouseleave', () => {
    const val = parseInt(document.getElementById('ratingVal').value);
    document.querySelectorAll('#starRating span').forEach((x, i) => {
        x.style.color = i < val ? '#f39c12' : '#ddd';
    });
});

function previewReviewImages(input) {
    const preview = document.getElementById('reviewPreview');
    [...input.files].forEach(file => {
        const reader = new FileReader();
        reader.onload = e => {
            const img = document.createElement('img');
            img.src = e.target.result;
            img.className = 'preview-img';
            preview.appendChild(img);
        };
        reader.readAsDataURL(file);
    });
}

let stream = null;
let capturedDataURLs = [];

async function openCamera() {
    try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        document.getElementById('cameraStream').srcObject = stream;
        document.getElementById('cameraSection').style.display = 'block';
    } catch (e) {
        showToast('ไม่สามารถเข้าถึงกล้องได้', 'error');
    }
}

function closeCamera() {
    if (stream) { stream.getTracks().forEach(t => t.stop()); stream = null; }
    document.getElementById('cameraSection').style.display = 'none';
}

function takePhoto() {
    const video = document.getElementById('cameraStream');
    const canvas = document.getElementById('cameraCanvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
    capturedDataURLs.push(dataUrl);
    document.getElementById('capturedPhotosData').value = JSON.stringify(capturedDataURLs);

    const img = document.createElement('img');
    img.src = dataUrl;
    img.className = 'preview-img';
    document.getElementById('capturedPhotos').appendChild(img);
    showToast('ถ่ายรูปสำเร็จ 📸', 'success', 2000);
}
</script>
</body>
</html>
