<?php
define('INCLUDED', true);
require_once 'config.php';
requireLogin();

$pdo = getDB();
$userId = $_SESSION['user_id'];
$pageTitle = 'ตะกร้าสินค้า';

// ดึงสินค้าในตะกร้า
$stmt = $pdo->prepare("
    SELECT c.id AS cart_id, c.quantity, p.id AS product_id, p.name, p.price, p.stock, p.unit, p.image
    FROM cart c JOIN products p ON c.product_id = p.id
    WHERE c.user_id = ? AND p.is_active = 1
");
$stmt->execute([$userId]);
$items = $stmt->fetchAll();

$total = 0;
foreach ($items as $item) {
    $total += $item['price'] * $item['quantity'];
}
?>
<?php include 'navbar.php'; ?>

<div class="cart-page">
    <h1 style="font-size:1.5rem;font-weight:800;margin-bottom:28px;color:var(--text-dark)">
        🛒 ตะกร้าสินค้า <span style="font-size:1rem;font-weight:500;color:var(--text-light)">(<?= count($items) ?> รายการ)</span>
    </h1>

    <?php if (empty($items)): ?>
    <div style="text-align:center;padding:80px 20px;background:white;border-radius:var(--radius-lg);box-shadow:var(--shadow-card)">
        <div style="font-size:64px;margin-bottom:16px">🛒</div>
        <h2 style="color:var(--text-light);margin-bottom:16px">ตะกร้าสินค้าว่างเปล่า</h2>
        <a href="shop.php" class="btn btn-primary btn-lg">เลือกซื้อสินค้า</a>
    </div>
    <?php else: ?>

    <div class="cart-layout">
        <!-- Items -->
        <div>
            <div class="cart-items">
                <?php foreach ($items as $item): ?>
                <div class="cart-item" data-cart-item="<?= $item['cart_id'] ?>">
                    <img src="<?= $item['image'] ? SITE_URL . '/' . sanitize($item['image']) : SITE_URL . '/img/no-image.png' ?>"
                         class="cart-item-img" alt="<?= sanitize($item['name']) ?>"
                         onerror="this.src='<?= SITE_URL ?>/img/no-image.png'">
                    <div class="cart-item-info">
                        <div class="cart-item-name"><?= sanitize($item['name']) ?></div>
                        <div class="cart-item-price">฿<?= number_format($item['price'], 2) ?> / <?= sanitize($item['unit']) ?></div>
                    </div>
                    <div class="qty-control">
                        <button class="qty-btn" onclick="updateCartQty(<?= $item['cart_id'] ?>, -1)">−</button>
                        <input class="qty-input" type="number" value="<?= $item['quantity'] ?>" min="1" max="<?= $item['stock'] ?>" data-cart-id="<?= $item['cart_id'] ?>">
                        <button class="qty-btn" onclick="updateCartQty(<?= $item['cart_id'] ?>, 1)">+</button>
                    </div>
                    <div class="cart-item-total" data-subtotal="<?= $item['cart_id'] ?>">
                        ฿<?= number_format($item['price'] * $item['quantity'], 2) ?>
                    </div>
                    <button onclick="removeCartItem(<?= $item['cart_id'] ?>)" style="background:none;border:none;color:#e74c3c;font-size:18px;cursor:pointer;padding:4px" title="ลบ">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <?php endforeach; ?>
            </div>

            <div style="margin-top:16px;display:flex;justify-content:space-between">
                <a href="shop.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> ซื้อต่อ</a>
                <a href="javascript:void(0)" onclick="clearCart()" class="btn btn-outline" style="color:#e74c3c;border-color:#e74c3c">
                    <i class="fas fa-trash"></i> ล้างตะกร้า
                </a>
            </div>
        </div>

        <!-- Summary -->
        <div class="cart-summary">
            <h3 style="font-size:1rem;font-weight:700;margin-bottom:20px;padding-bottom:14px;border-bottom:2px solid var(--green-pale)">
                สรุปคำสั่งซื้อ
            </h3>
            <div class="summary-row">
                <span>ยอดรวมสินค้า</span>
                <span>฿<?= number_format($total, 2) ?></span>
            </div>
            <div class="summary-row">
                <span>ค่าจัดส่ง</span>
                <span style="color:var(--green-deep);font-weight:600"><?= $total >= 500 ? 'ฟรี! 🎉' : '฿50.00' ?></span>
            </div>
            <?php
            $shipping = $total >= 500 ? 0 : 50;
            $finalTotal = $total + $shipping;
            if (isset($_SESSION['points']) && $_SESSION['points'] > 0):
            ?>
            <div class="summary-row" style="font-size:13px;color:var(--text-light)">
                <span>⭐ คะแนนของคุณ</span>
                <span><?= $_SESSION['points'] ?> คะแนน (= ฿<?= $_SESSION['points'] ?>)</span>
            </div>
            <?php endif; ?>

            <div class="summary-row summary-total">
                <span>ยอดรวมทั้งสิ้น</span>
                <span id="cartTotal">฿<?= number_format($finalTotal, 2) ?></span>
            </div>

            <?php if ($total < 500): ?>
            <div style="background:var(--green-cream);border-radius:var(--radius-sm);padding:10px 14px;font-size:13px;color:var(--green-deep);margin-bottom:16px;text-align:center">
                <i class="fas fa-truck"></i> ซื้อเพิ่ม ฿<?= number_format(500 - $total, 0) ?> รับฟรีค่าจัดส่ง!
            </div>
            <?php endif; ?>

            <a href="checkout.php" class="btn btn-primary btn-full btn-lg" style="margin-top:8px">
                <i class="fas fa-lock"></i> ดำเนินการสั่งซื้อ
            </a>
            <div style="text-align:center;font-size:12px;color:var(--text-light);margin-top:10px">
                🔒 ชำระเงินปลอดภัย
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<footer class="footer"><div class="footer-bottom">&copy; <?= date('Y') ?> <?= SITE_NAME ?></div></footer>
<script src="<?= SITE_URL ?>/js/main.js"></script>
<script>
const CART_API = '<?= SITE_URL ?>/api/cart.php';

// ── เรียก API ────────────────────────────────────────────────
async function cartRequest(payload) {
    const res = await fetch(CART_API, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    });
    return res.json();
}

// ── อัปเดตจำนวน (+1 / -1 หรือพิมพ์ตรงๆ) ────────────────────
async function updateCartQty(cartId, delta) {
    const input = document.querySelector(`.qty-input[data-cart-id="${cartId}"]`);
    if (!input) return;

    let qty = parseInt(input.value) + delta;
    const max = parseInt(input.max) || 999;
    qty = Math.max(1, Math.min(qty, max));
    input.value = qty;

    const data = await cartRequest({action: 'update', cart_id: cartId, quantity: qty});

    if (data.success) {
        if (data.removed) {
            removeRow(cartId);
            return;
        }
        // อัปเดต subtotal ของแถวนี้
        const subtotalEl = document.querySelector(`[data-subtotal="${cartId}"]`);
        if (subtotalEl) subtotalEl.textContent = '฿' + data.subtotal;
        recalcTotal();
    } else {
        alert(data.message || 'เกิดข้อผิดพลาด');
        location.reload();
    }
}

// ── ลบรายการ ─────────────────────────────────────────────────
async function removeCartItem(cartId) {
    if (!confirm('ต้องการลบสินค้านี้ออกจากตะกร้า?')) return;
    const data = await cartRequest({action: 'remove', cart_id: cartId});
    if (data.success) {
        removeRow(cartId);
    } else {
        alert(data.message || 'เกิดข้อผิดพลาด');
    }
}

// ── ล้างตะกร้าทั้งหมด ────────────────────────────────────────
async function clearCart() {
    if (!confirm('ต้องการล้างตะกร้าสินค้าทั้งหมด?')) return;
    const data = await cartRequest({action: 'clear'});
    if (data.success) location.reload();
}

// ── ลบ row ออกจาก DOM + อัปเดตยอดรวม ────────────────────────
function removeRow(cartId) {
    const row = document.querySelector(`[data-cart-item="${cartId}"]`);
    if (row) row.remove();
    recalcTotal();
    updateItemCount();
}

// ── คำนวณยอดรวมใหม่จาก DOM ───────────────────────────────────
function recalcTotal() {
    let total = 0;
    document.querySelectorAll('[data-subtotal]').forEach(el => {
        const val = parseFloat(el.textContent.replace(/[^0-9.]/g, '')) || 0;
        total += val;
    });

    const shipping  = total >= 500 ? 0 : (total > 0 ? 50 : 0);
    const finalTotal = total + shipping;

    const totalEl = document.getElementById('cartTotal');
    if (totalEl) totalEl.textContent = '฿' + finalTotal.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// ── อัปเดตตัวนับรายการ ────────────────────────────────────────
function updateItemCount() {
    const rows  = document.querySelectorAll('[data-cart-item]').length;
    const badge = document.querySelector('.cart-item-count');
    if (badge) badge.textContent = rows;

    if (rows === 0) location.reload(); // โหลดใหม่เพื่อแสดง empty state
}

// ── กรอกจำนวนโดยตรงใน input ──────────────────────────────────
document.addEventListener('change', function(e) {
    if (!e.target.classList.contains('qty-input')) return;
    const cartId = parseInt(e.target.dataset.cartId);
    const qty    = parseInt(e.target.value) || 1;
    const delta  = qty - parseInt(e.target.defaultValue || 1);
    e.target.defaultValue = qty;
    updateCartQty(cartId, delta - (parseInt(e.target.value) - qty)); // sync ตรงๆ
    // เรียกแบบตรงกว่า:
    e.target.value = qty;
    cartRequest({action: 'update', cart_id: cartId, quantity: qty}).then(data => {
        if (data.success) {
            const subtotalEl = document.querySelector(`[data-subtotal="${cartId}"]`);
            if (subtotalEl && data.subtotal) subtotalEl.textContent = '฿' + data.subtotal;
            recalcTotal();
        } else {
            alert(data.message || 'เกิดข้อผิดพลาด');
            location.reload();
        }
    });
});
</script>
</body>
</html>
