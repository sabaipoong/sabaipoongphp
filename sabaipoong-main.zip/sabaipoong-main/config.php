<?php
// =============================================
// config.php - การตั้งค่าระบบ สบายพุง
// =============================================

session_start();

// ---- ฐานข้อมูล ----
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db');
define('DB_CHARSET', 'utf8mb4');

// ---- Site Config ----
define('SITE_NAME', 'สบายพุง');
define('SITE_URL', 'http://localhost/sabaipoong');
define('SITE_DESC', 'ร้านอาหารเพื่อสุขภาพ อร่อย สะอาด ส่งตรงถึงบ้าน');

// ---- Upload Path ----
define('UPLOAD_PATH', __DIR__ . '/uploads/');
define('UPLOAD_URL', SITE_URL . '/uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB

// ---- Points Config ----
define('POINTS_PER_ITEM', 1);     // 1 ชิ้น = 1 คะแนน
define('POINTS_VALUE', 1);        // 1 คะแนน = 1 บาท

// ---- Social Login ----
define('GOOGLE_CLIENT_ID', 'YOUR_GOOGLE_CLIENT_ID');
define('GOOGLE_CLIENT_SECRET', 'YOUR_GOOGLE_CLIENT_SECRET');
define('GOOGLE_REDIRECT_URI', SITE_URL . '/auth/google_callback.php');

define('LINE_CHANNEL_ID', 'YOUR_LINE_CHANNEL_ID');
define('LINE_CHANNEL_SECRET', 'YOUR_LINE_CHANNEL_SECRET');
define('LINE_REDIRECT_URI', SITE_URL . '/auth/line_callback.php');

// =============================================
// Database Connection (PDO)
// =============================================
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// =============================================
// Helper Functions
// =============================================

function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

function isAdmin(): bool {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: ' . SITE_URL . '/login.php');
        exit;
    }
}

function requireAdmin(): void {
    requireLogin();
    if (!isAdmin()) {
        header('Location: ' . SITE_URL . '/index.php?error=no_permission');
        exit;
    }
}

function sanitize(string $str): string {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

function formatPrice(float $price): string {
    return number_format($price, 2) . ' บาท';
}

function formatDate(string $datetime): string {
    $ts = strtotime($datetime);
    $months = ['','ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
    return date('j', $ts) . ' ' . $months[(int)date('n', $ts)] . ' ' . (date('Y', $ts) + 543);
}

function uploadImage(array $file, string $dir = 'products'): string|false {
    $allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (!in_array($file['type'], $allowedTypes)) return false;
    if ($file['size'] > MAX_FILE_SIZE) return false;

    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '_' . time() . '.' . strtolower($ext);
    $uploadDir = UPLOAD_PATH . $dir . '/';

    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    if (move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
        return 'uploads/' . $dir . '/' . $filename;
    }
    return false;
}

function getCartCount(): int {
    if (!isLoggedIn()) return 0;
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT COALESCE(SUM(quantity),0) FROM cart WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}

function generateOrderNumber(): string {
    return 'SP' . date('Ymd') . strtoupper(substr(uniqid(), -6));
}
?>
